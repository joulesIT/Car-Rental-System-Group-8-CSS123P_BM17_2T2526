//package declaration
package PROJECTGUI;

//swing imports for GUI components
import javax.swing.*;
import javax.swing.border.*;
//awt imports for graphics, layout, and events
import java.awt.*;
import java.awt.event.*;
//utility imports for lists
import java.util.ArrayList;
import java.util.List;

//main class for the user-facing dashboard, extends JFrame to create a window
public class UserDashboard extends JFrame {

    //brand color constants used throughout the UI
    private static final Color RED      = new Color(204, 41,  34);
    private static final Color DARK_RED = new Color(160, 28,  22);
    private static final Color CARD_BG  = new Color(195, 207, 215);
    private static final Color SIDEBAR  = new Color(210, 221, 229);
    private static final Color WHITE    = Color.WHITE;
    private static final Color DARK_TXT = new Color(30,  30,  30);

    //stores the logged-in username to display on the dashboard
    private final String     userName;
    //cardLayout allows switching between Home and Browse pages without opening new windows
    private final CardLayout cards = new CardLayout();
    //root panel that holds all pages managed by cardLayout
    private final JPanel     root  = new JPanel(cards);

    //inner class representing a single car entry with brand, model, and rating
    static final class Car {
        final String brand, model;
        final double rating;
        //constructor assigns brand, model, and rating
        Car(String b, String m, double r) { brand=b; model=m; rating=r; }
    }

    //static list holding all available cars in the system
    private static final List<Car> CARS = new ArrayList<>();
    //static initializer block populates the car list when the class is loaded
    static {
        CARS.add(new Car("Toyota", "Veloz",   4.0));
        CARS.add(new Car("Honda",  "Civic",   4.7));
        CARS.add(new Car("Ford",   "Everest", 4.9));
        CARS.add(new Car("Nissan", "Z Proto", 5.0));
        CARS.add(new Car("Nissan", "Rogue",   4.6));
        CARS.add(new Car("Nissan", "Razer",   4.3));
        CARS.add(new Car("Toyota", "Hilux",   4.2));
        CARS.add(new Car("Toyota", "Wigo",    3.4));
    }

    //constructor sets up the JFrame window and adds both pages to the card layout
    public UserDashboard(String userName) {
        //save the username for use in labels throughout the dashboard
        this.userName = userName;
        //set the window title bar text
        setTitle("DriveDash — " + userName);
        //close the application when the window is closed
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        //set the initial window size to 1400x800 pixels
        setSize(1400, 800);
        //prevent the window from being resized below 1050x650
        setMinimumSize(new Dimension(1050, 650));
        //center the window on the screen
        setLocationRelativeTo(null);

        //add home page to the card layout under the key "HOME"
        root.add(buildHomePage(),   "HOME");
        //add browse page to the card layout under the key "BROWSE"
        root.add(buildBrowsePage(), "BROWSE");
        //attach the root panel (containing all pages) to the JFrame
        add(root);
        //show the Home page first when the dashboard opens
        cards.show(root, "HOME");
        //make the window visible to the user
        setVisible(true);
    }

    //builds and returns the red navigation bar used on every page
    private JPanel buildNav(String active) {
        //create the main nav bar panel with BorderLayout for left and right sections
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(RED);
        //set the nav bar height to 62 pixels
        bar.setPreferredSize(new Dimension(0, 62));
        //add horizontal padding inside the nav bar
        bar.setBorder(new EmptyBorder(0, 22, 0, 22));

        //logo section on the left side of the nav bar
        JPanel logo = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        logo.setOpaque(false);

        //checkered flag icon drawn manually using a grid of alternating colored squares
        JComponent flag = new JComponent() {
            { setPreferredSize(new Dimension(30, 30)); }
            //paintComponent draws the 4x4 checkered flag pattern
            @Override protected void paintComponent(Graphics g) {
                int s = 6;
                //loop through 4 rows and 4 columns to draw alternating black and white squares
                for (int r=0;r<4;r++) for (int c=0;c<4;c++) {
                    g.setColor((r+c)%2==0 ? WHITE : new Color(50,50,50));
                    g.fillRect(c*s+1, r*s+3, s, s);
                }
            }
        };

        //brand name label displayed next to the flag icon
        JLabel brand = new JLabel("DriveDash");
        brand.setFont(new Font("SansSerif", Font.BOLD, 27));
        brand.setForeground(WHITE);
        //add flag icon and brand name to the logo panel
        logo.add(flag);
        logo.add(brand);

        //wrap logo in a GridBagLayout panel to center it vertically in the nav bar
        JPanel logoWrap = new JPanel(new GridBagLayout());
        logoWrap.setOpaque(false);
        logoWrap.add(logo);
        //place the logo on the left side of the nav bar
        bar.add(logoWrap, BorderLayout.WEST);

        //navigation links section on the right side of the nav bar
        JPanel links = new JPanel(new FlowLayout(FlowLayout.RIGHT, 26, 0));
        links.setOpaque(false);

        //labels for each nav link
        String[] labels = {"Home", "Browse Cars", "Rent History", "Bookings"};
        //card keys that each nav link navigates to
        String[] ids    = {"HOME", "BROWSE", "HOME", "HOME"};

        //loop through each nav label and create a clickable label for it
        for (int i = 0; i < labels.length; i++) {
            final String dest = ids[i];
            JLabel lbl = new JLabel(labels[i]);
            //check if this link matches the currently active page
            boolean isActive = labels[i].equalsIgnoreCase(active)
                    || (labels[i].equals("Browse Cars") && active.equals("BROWSE"));
            lbl.setFont(new Font("SansSerif", Font.BOLD, 17));
            //highlight the active page link with a lighter red, others are white
            lbl.setForeground(isActive ? new Color(255, 215, 215) : WHITE);
            //change cursor to hand pointer to indicate the label is clickable
            lbl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            //add mouse listener to handle click, hover-in, and hover-out behavior
            lbl.addMouseListener(new MouseAdapter() {
                //switch to the destination page when clicked
                @Override public void mouseClicked(MouseEvent e) { cards.show(root, dest); }
                //lighten the link color when hovered
                @Override public void mouseEntered(MouseEvent e) { lbl.setForeground(new Color(255,200,200)); }
                //restore white color when mouse leaves the link
                @Override public void mouseExited(MouseEvent e)  { lbl.setForeground(WHITE); }
            });
            links.add(lbl);
        }

        //profile icon drawn as a circle with a person emoji inside
        JLabel icon = new JLabel("\u25CF") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                //draw semi-transparent white circle as the icon background
                g2.setColor(new Color(255,255,255,50));
                g2.fillOval(0,0,getWidth()-1,getHeight()-1);
                //draw the person emoji centered inside the circle
                g2.setColor(WHITE);
                g2.setFont(new Font("SansSerif",Font.PLAIN,22));
                FontMetrics fm = g2.getFontMetrics();
                String s = "\uD83D\uDC64";
                g2.drawString(s, (getWidth()-fm.stringWidth(s))/2, (getHeight()+fm.getAscent()-fm.getDescent())/2);
                g2.dispose();
            }
        };
        //set the size of the profile icon
        icon.setPreferredSize(new Dimension(36, 36));
        icon.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        //tooltip shows the logged-in username when hovering over the icon
        icon.setToolTipText("Logged in as: " + userName);
        links.add(icon);

        //wrap links panel in GridBagLayout to center it vertically in the nav bar
        JPanel linksWrap = new JPanel(new GridBagLayout());
        linksWrap.setOpaque(false);
        linksWrap.add(links);
        //place the links panel on the right side of the nav bar
        bar.add(linksWrap, BorderLayout.EAST);
        return bar;
    }

    //builds and returns the full Home page panel with sidebar and featured car grid
    private JPanel buildHomePage() {
        //create the main page container with BorderLayout
        JPanel page = new JPanel(new BorderLayout());
        page.setBackground(WHITE);
        //attach the nav bar at the top of the page
        page.add(buildNav("Home"), BorderLayout.NORTH);

        //sidebar panel on the left showing the previously rented car
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(SIDEBAR);
        //set fixed width for the sidebar
        sidebar.setPreferredSize(new Dimension(290, 0));
        sidebar.setBorder(new EmptyBorder(22, 18, 22, 18));

        //label at the top of the sidebar indicating the previous rental section
        JLabel prevTitle = new JLabel("Previous Car Rented...");
        prevTitle.setFont(new Font("SansSerif", Font.BOLD, 15));
        prevTitle.setForeground(RED);
        prevTitle.setAlignmentX(LEFT_ALIGNMENT);
        sidebar.add(prevTitle);
        //add vertical spacing below the title
        sidebar.add(Box.createVerticalStrut(14));

        //row inside the sidebar that holds the car silhouette and its name side by side
        JPanel prevRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        prevRow.setOpaque(false);
        prevRow.setAlignmentX(LEFT_ALIGNMENT);
        prevRow.setMaximumSize(new Dimension(260, 90));

        //build a small silhouette panel for the previously rented car (Toyota Veloz, index 0)
        JPanel miniCar = buildSilhouettePanel(CARS.get(0), 110, 72);
        prevRow.add(miniCar);

        //add the car name label next to the silhouette
        JLabel prevName = makeCarNameLabel(CARS.get(0), 18);
        prevRow.add(prevName);
        sidebar.add(prevRow);

        //push the rent history link to the bottom of the sidebar
        sidebar.add(Box.createVerticalGlue());

        //underlined link at the bottom of the sidebar to view full rent history
        JLabel histLink = new JLabel("<html><u>View all Rent History</u></html>");
        histLink.setFont(new Font("SansSerif", Font.PLAIN, 14));
        histLink.setForeground(RED);
        histLink.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        histLink.setAlignmentX(LEFT_ALIGNMENT);
        //show a placeholder message when the rent history link is clicked
        histLink.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                JOptionPane.showMessageDialog(UserDashboard.this,
                        "Rent History — coming soon!", "Rent History", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        sidebar.add(histLink);

        //main content area on the right side of the home page
        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(WHITE);

        //header panel containing the welcome message
        JPanel header = new JPanel(new FlowLayout(FlowLayout.LEFT, 38, 20));
        header.setBackground(WHITE);
        //welcome label uses HTML to style "Welcome Back," in red italic and the username in dark italic
        JLabel welcome = new JLabel();
        welcome.setText("<html>"
                + "<span style='color:rgb(204,41,34);font-size:40pt;'><i><b>Welcome Back, </b></i></span>"
                + "<span style='color:rgb(25,25,25);font-size:40pt;'><i><b>" + userName + "!</b></i></span>"
                + "</html>");
        header.add(welcome);
        //add the welcome header to the top of the main content area
        main.add(header, BorderLayout.NORTH);

        //indices of the 6 featured cars shown on the home page (skips Toyota Veloz at index 0)
        int[] featuredIdx = {1, 2, 3, 5, 6, 7};
        //build a 3-column grid using the featured car indices with card size 210x185
        JPanel grid = buildCarGrid(featuredIdx, 3, 210, 185);
        //wrap the grid in a scroll pane in case content overflows vertically
        JScrollPane scroll = new JScrollPane(grid);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(12);
        //place the scrollable grid in the center of the main content area
        main.add(scroll, BorderLayout.CENTER);

        //body panel combines the sidebar and main content side by side
        JPanel body = new JPanel(new BorderLayout());
        body.add(sidebar, BorderLayout.WEST);
        body.add(main,    BorderLayout.CENTER);
        //add the body to the center of the page
        page.add(body, BorderLayout.CENTER);

        //thin red decorative strip at the bottom of the page
        JPanel strip = new JPanel();
        strip.setBackground(RED);
        strip.setPreferredSize(new Dimension(0, 6));
        page.add(strip, BorderLayout.SOUTH);
        return page;
    }

    //builds and returns the Browse Cars page showing all 8 cars in a 4-column grid
    private JPanel buildBrowsePage() {
        //create the page container with BorderLayout
        JPanel page = new JPanel(new BorderLayout());
        page.setBackground(WHITE);
        //attach the nav bar at the top, marking Browse Cars as the active link
        page.add(buildNav("BROWSE"), BorderLayout.NORTH);

        //array of all 8 car indices to display on the browse page
        int[] allIdx = {0,1,2,3,4,5,6,7};
        //build a 4-column grid with all cars, each card sized 255x225
        JPanel grid = buildCarGrid(allIdx, 4, 255, 225);
        //wrap the grid in a scroll pane to handle overflow
        JScrollPane scroll = new JScrollPane(grid);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(14);
        //place the scrollable grid in the center of the page
        page.add(scroll, BorderLayout.CENTER);

        //thin red decorative strip at the bottom of the page
        JPanel strip = new JPanel();
        strip.setBackground(RED);
        strip.setPreferredSize(new Dimension(0, 6));
        page.add(strip, BorderLayout.SOUTH);
        return page;
    }

    //builds a container panel that arranges car cards in rows with a fixed number of columns
    private JPanel buildCarGrid(int[] indices, int cols, int cardW, int cardH) {
        //container stacks rows vertically using BoxLayout
        JPanel container = new JPanel();
        container.setBackground(WHITE);
        container.setBorder(new EmptyBorder(10, 24, 20, 24));
        container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));

        //current row panel being filled with car cards
        JPanel row = null;
        //loop through each car index and place it into the correct row
        for (int i = 0; i < indices.length; i++) {
            //start a new row every time we reach the column limit
            if (i % cols == 0) {
                row = new JPanel(new FlowLayout(FlowLayout.CENTER, 18, 14));
                row.setOpaque(false);
                container.add(row);
            }
            //add the car card for the current index into the current row
            row.add(buildCarCard(CARS.get(indices[i]), cardW, cardH));
        }
        return container;
    }

    //builds and returns a single car card panel with a rating badge, silhouette, and name label
    private JPanel buildCarCard(Car car, int w, int h) {

        //card panel uses null layout for absolute positioning of child components
        //paintComponent draws a rounded rectangle background in card color
        JPanel card = new JPanel(null) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                //fill the card background with the card color and rounded corners
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth()-1, getHeight()-1, 14, 14);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        //set the fixed dimensions of the card
        card.setPreferredSize(new Dimension(w, h));
        //show hand cursor when hovering over a card to indicate it is clickable
        card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        //rating badge panel in the top-left corner of the card
        //paintComponent draws a red rounded rectangle behind the star and rating text
        JPanel badge = new JPanel(new FlowLayout(FlowLayout.CENTER, 3, 1)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                //fill badge background with brand red color
                g2.setColor(RED);
                g2.fillRoundRect(0, 0, getWidth()-1, getHeight()-1, 7, 7);
                g2.dispose();
            }
        };
        badge.setOpaque(false);
        //label showing the star icon and the rating value
        JLabel ratingLbl = new JLabel("\u2605 " + car.rating);
        ratingLbl.setFont(new Font("SansSerif", Font.BOLD, 12));
        ratingLbl.setForeground(WHITE);
        badge.add(ratingLbl);
        //position the badge at the top-left corner of the card
        badge.setBounds(9, 9, 68, 24);
        card.add(badge);

        //calculate the height for the silhouette image area as 63% of the card height
        int imgH = (int)(h * 0.63);
        //build the silhouette panel for the car and position it inside the card
        JPanel imgPanel = buildSilhouettePanel(car, w - 10, imgH);
        imgPanel.setBounds(5, 8, w-10, imgH);
        card.add(imgPanel);

        //car name label positioned below the silhouette area
        JLabel nameLbl = makeCarNameLabel(car, 15);
        nameLbl.setHorizontalAlignment(SwingConstants.CENTER);
        //position the name label just below the image area with a small gap
        nameLbl.setBounds(4, imgH + 12, w - 8, 34);
        card.add(nameLbl);

        //mouse listener handles hover highlighting and click-to-book behavior
        card.addMouseListener(new MouseAdapter() {
            //show a red border around the card when the mouse enters
            @Override public void mouseEntered(MouseEvent e) {
                card.setBorder(BorderFactory.createLineBorder(RED, 2, true));
                card.repaint();
            }
            //remove the red border when the mouse leaves the card
            @Override public void mouseExited(MouseEvent e) {
                card.setBorder(null);
                card.repaint();
            }
            //open the booking dialog when the user clicks on the card
            @Override public void mouseClicked(MouseEvent e) {
                showCarDialog(car);
            }
        });
        return card;
    }

    //creates and returns a JLabel with the car brand in red italic and the model in dark bold using HTML styling
    private JLabel makeCarNameLabel(Car car, int fontSize) {
        JLabel lbl = new JLabel("<html>"
                + "<span style='color:rgb(204,41,34);font-style:italic;'><b>" + car.brand + "</b></span>"
                + "<span style='color:rgb(30,30,30);'><b> " + car.model + "</b></span>"
                + "</html>");
        lbl.setFont(new Font("SansSerif", Font.PLAIN, fontSize));
        return lbl;
    }

    //creates a transparent JPanel of the given size that draws a car silhouette when painted
    private JPanel buildSilhouettePanel(Car car, int w, int h) {
        return new JPanel() {
            //set panel to transparent and apply the requested dimensions
            { setOpaque(false); setPreferredSize(new Dimension(w, h)); }
            //delegate all drawing to the drawSilhouette method
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                drawSilhouette((Graphics2D) g.create(), car, getWidth(), getHeight());
            }
        };
    }

    //draws a vector car silhouette onto the given Graphics2D context based on the car type
    private void drawSilhouette(Graphics2D g2, Car car, int w, int h) {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        //retrieve the body color associated with this specific car
        Color body   = bodyColor(car);
        //semi-transparent blue-tinted color used for windows
        Color window = new Color(140, 195, 230, 110);
        //dark color used for the tyres
        Color tyre   = new Color(35, 35, 35);
        //light grey color used for the wheel rims
        Color rimCol = new Color(180, 182, 188);
        //yellow-tinted color for the front headlights
        Color light  = new Color(255, 240, 130, 200);
        //red-tinted color for the rear tail lights
        Color tlight = new Color(220, 50,  50,  180);

        //determine the shape type: SUV, TRUCK, SPORTS, or SEDAN
        String type = carType(car);

        //calculate the main body dimensions relative to the panel size
        int bw = (int)(w * 0.82);
        int bh = (int)(h * 0.26);
        int bx = (w - bw) / 2;
        int by = (int)(h * 0.52);

        //calculate wheel size and horizontal positions for the two wheels
        int wheelR = (int)(bw * 0.14);
        int w1x    = bx + (int)(bw * 0.17);
        int w2x    = bx + (int)(bw * 0.72);
        int wy     = by + bh - wheelR / 2;

        //draw the car body shape based on the car type
        if ("SPORTS".equals(type)) {
            //sports car uses a low wedge polygon shape for a sleek look
            int[] xb = {bx, bx+(int)(bw*.12), bx+(int)(bw*.32), bx+(int)(bw*.70), bx+(int)(bw*.92), bx+bw};
            int   tY = by - (int)(h * 0.18);
            int[] yb = {by+bh, by, tY, tY, by, by+bh};
            g2.setColor(body);
            g2.fillPolygon(xb, yb, xb.length);
            //draw the windshield window as a polygon on top of the body
            int[] xw = {bx+(int)(bw*.22), bx+(int)(bw*.38), bx+(int)(bw*.68), bx+(int)(bw*.58)};
            int[] yw = {by+2, tY+4, tY+4, by+2};
            g2.setColor(window);
            g2.fillPolygon(xw, yw, xw.length);

        } else if ("SUV".equals(type) || "TRUCK".equals(type)) {
            //SUV and truck use a boxy two-rectangle shape for a taller profile
            int rw2 = (int)(bw * 0.70);
            int rh  = (int)(h * 0.26);
            int rx  = bx + (int)(bw * 0.08);
            int ry  = by - rh;
            g2.setColor(body);
            //draw the lower body rectangle
            g2.fillRoundRect(bx, by, bw, bh, 10, 10);
            //draw the upper cabin rectangle on top of the lower body
            g2.fillRoundRect(rx, ry, rw2, rh + 6, 8, 8);
            //draw the window inside the upper cabin
            g2.setColor(window);
            g2.fillRoundRect(rx+6, ry+5, rw2-12, rh-8, 6, 6);

        } else {
            //sedan and hatchback use two rounded rectangles for a smooth curved profile
            int rw2 = (int)(bw * 0.58);
            int rh  = (int)(h * 0.22);
            int rx  = bx + (int)(bw * 0.20);
            int ry  = by - rh;
            g2.setColor(body);
            //draw the lower body
            g2.fillRoundRect(bx, by, bw, bh, 14, 14);
            //draw the upper roof section
            g2.fillRoundRect(rx, ry, rw2, rh + 8, 14, 14);
            //draw the window inside the roof section
            g2.setColor(window);
            g2.fillRoundRect(rx+6, ry+5, rw2-12, rh, 10, 10);
        }

        //draw a subtle dark shadow at the bottom of the body for depth
        g2.setColor(new Color(0,0,0,25));
        g2.fillRoundRect(bx, by+2, bw, bh-2, 14, 14);

        //draw each wheel using the calculated positions
        for (int wx : new int[]{w1x, w2x}) {
            //draw a dark oval shadow behind the wheel arch
            g2.setColor(new Color(0,0,0,45));
            g2.fillOval(wx - wheelR - 3, wy - 5, wheelR*2+6, wheelR+6);
            //draw the dark tyre circle
            g2.setColor(tyre);
            g2.fillOval(wx - wheelR, wy, wheelR*2, wheelR*2);
            //draw the lighter rim circle inside the tyre
            g2.setColor(rimCol);
            int rr = (int)(wheelR * 0.54);
            g2.fillOval(wx - rr, wy + wheelR - rr, rr*2, rr*2);
            //draw 3 spoke lines radiating from the center of the rim
            g2.setColor(new Color(150,152,158));
            g2.setStroke(new BasicStroke(1.3f));
            int cx2 = wx, cy2 = wy + wheelR;
            for (int a = 0; a < 3; a++) {
                double angle = Math.toRadians(a * 60);
                g2.drawLine(cx2, cy2,
                        cx2 + (int)(rr * Math.cos(angle)),
                        cy2 + (int)(rr * Math.sin(angle)));
            }
            //reset stroke to default after drawing spokes
            g2.setStroke(new BasicStroke(1f));
        }

        //draw the front headlight as a small yellow oval on the right side of the body
        g2.setColor(light);
        g2.fillOval(bx + bw - 16, by + 6, 12, 8);
        //draw the rear tail light as a small red oval on the left side of the body
        g2.setColor(tlight);
        g2.fillOval(bx + 4, by + 6, 12, 8);

        //dispose the graphics context to free resources
        g2.dispose();
    }

    //returns the display color for a car's body based on its brand and model name
    private Color bodyColor(Car c) {
        switch (c.brand + " " + c.model) {
            case "Toyota Veloz":   return new Color(228,230,234);
            case "Honda Civic":    return new Color(198,204,216);
            case "Ford Everest":   return new Color(175,182,188);
            case "Nissan Z Proto": return new Color(208,212,80);
            case "Nissan Rogue":   return new Color(45, 50, 62);
            case "Nissan Razer":   return new Color(55, 108,210);
            case "Toyota Hilux":   return new Color(192,192,186);
            case "Toyota Wigo":    return new Color(238,238,238);
            //default grey for any car not explicitly listed
            default:               return new Color(175,180,185);
        }
    }

    //returns the silhouette shape type for a car based on its brand and model name
    private String carType(Car c) {
        String k = c.brand + " " + c.model;
        switch (k) {
            //SUV body type for tall, boxy vehicles
            case "Toyota Veloz": case "Ford Everest": case "Nissan Rogue": return "SUV";
            //TRUCK body type for pickup trucks
            case "Toyota Hilux":                                            return "TRUCK";
            //SPORTS body type for low, aerodynamic vehicles
            case "Nissan Z Proto": case "Nissan Razer":                     return "SPORTS";
            //SEDAN is the default body type for all other cars
            default:                                                         return "SEDAN";
        }
    }

    //shows a booking dialog for the selected car with start and end date input fields
    private void showCarDialog(Car car) {
        //create a small panel with two labeled text fields for the booking dates
        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 8));
        panel.add(new JLabel("Start Date (YYYY-MM-DD):"));
        JTextField start = new JTextField();
        panel.add(start);
        panel.add(new JLabel("End Date (YYYY-MM-DD):"));
        JTextField end = new JTextField();
        panel.add(end);
        //spacer cells to fill the 3x2 grid layout
        panel.add(new JLabel(" "));
        panel.add(new JLabel(" "));

        //show the dialog as a confirm dialog with OK and Cancel buttons
        int res = JOptionPane.showConfirmDialog(this, panel,
                "Book: " + car.brand + " " + car.model + "  (\u2605 " + car.rating + ")",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        //handle the result when the user clicks OK
        if (res == JOptionPane.OK_OPTION) {
            String s = start.getText().trim(), e2 = end.getText().trim();
            //validate that both date fields are filled before confirming the booking
            if (s.isEmpty() || e2.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in both dates.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                //show a success message confirming the booking details
                JOptionPane.showMessageDialog(this,
                        "Booking confirmed!\n" + car.brand + " " + car.model
                                + "\nFrom: " + s + "  To: " + e2,
                        "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    //main method launches the dashboard standalone for testing in Eclipse
    public static void main(String[] args) {
        //run the GUI on the Event Dispatch Thread as required by Swing
        SwingUtilities.invokeLater(() -> new UserDashboard("User"));
    }
}