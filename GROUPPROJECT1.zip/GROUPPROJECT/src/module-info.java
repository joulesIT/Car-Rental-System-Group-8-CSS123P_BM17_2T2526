/**
 * 
 */
/**
 * 
 */
module GROUPPROJECT {
	requires java.desktop;
	requires java.sql;
}