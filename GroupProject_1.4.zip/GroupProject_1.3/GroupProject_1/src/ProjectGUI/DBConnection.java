package ProjectGUI;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/car_rental5";
    private static final String USER = "root"; 
    private static final String PASS = "myPASSsql@54321"; // <--- PUT PASSWORD HERE myPASSsql@54321

    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
}