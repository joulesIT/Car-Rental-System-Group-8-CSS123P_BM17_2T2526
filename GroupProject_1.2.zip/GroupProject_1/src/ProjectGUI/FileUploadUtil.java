package ProjectGUI;

import java.io.*;
import java.nio.file.*;
import java.util.UUID;

public class FileUploadUtil {
    // Defines where to save the files. This is relative to where you run the project.
    private static final String SAVE_DIR = "src/PROJECTGUI/IMAGES/";

    public static String saveFile(File sourceFile) throws IOException {
        if (sourceFile == null) return "default_car.png"; // Fallback image

        // Create the IMAGES directory if it doesn't exist
        File directory = new File(SAVE_DIR);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        // Generate a unique name for the file to prevent overwriting
        String originalName = sourceFile.getName();
        String fileExtension = originalName.substring(originalName.lastIndexOf("."));
        String uniqueName = UUID.randomUUID().toString() + fileExtension;

        // Copy the file
        Path targetPath = Paths.get(SAVE_DIR + uniqueName);
        Files.copy(sourceFile.toPath(), targetPath, StandardCopyOption.REPLACE_EXISTING);

        return uniqueName; // Return this new unique name to save in the database
    }
}