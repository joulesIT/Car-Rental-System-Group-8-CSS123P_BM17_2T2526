package PROJECTGUI;
import javax.swing.*;
import java.awt.*;

class FleetActionEditor extends DefaultCellEditor {
    protected JPanel panel;
    protected int currentId;
    public FleetActionEditor(JCheckBox checkBox, ManageFleetView parent) {
        super(checkBox);
        panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
        JButton ret = new JButton("Return"), del = new JButton("Delete");
        ret.addActionListener(e -> { parent.processReturn(currentId); fireEditingStopped(); });
        del.addActionListener(e -> { parent.removeCar(currentId); fireEditingStopped(); });
        panel.add(ret); panel.add(del);
    }
    public Component getTableCellEditorComponent(JTable t, Object v, boolean s, int r, int c) {
        currentId = (int) t.getValueAt(r, 0); return panel;
    }
}

class FleetActionRenderer extends JPanel implements javax.swing.table.TableCellRenderer {
    public FleetActionRenderer() { 
        setLayout(new FlowLayout(FlowLayout.CENTER, 5, 0));
        add(new JButton("Return")); add(new JButton("Delete"));
    }
    public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c) { return this; }
}