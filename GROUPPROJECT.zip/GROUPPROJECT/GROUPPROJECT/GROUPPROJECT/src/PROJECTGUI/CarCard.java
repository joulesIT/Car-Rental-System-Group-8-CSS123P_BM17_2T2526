package PROJECTGUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;

public class CarCard {
    private static final Color CARD_BG = new Color(45, 45, 48); 
    private static final Color TEXT_WHITE = Color.WHITE;

    public static JPanel build(Car car, int w, int h, String userName, UserDashboard dashboard) {
        JPanel card = new JPanel(null) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);
                g2.dispose();
            }
        };
        card.setPreferredSize(new Dimension(w, h));
        card.setOpaque(false);

        // 1. Image Holder (Corrected Path)
        JLabel imgLabel = new JLabel("", JLabel.CENTER);
        imgLabel.setBounds(20, 40, w - 40, 140);
        try {
            // Looking specifically in PROJECTGUI/IMAGES/
            URL imgURL = CarCard.class.getResource("/PROJECTGUI/IMAGES/" + car.getImagePath());
            if (imgURL != null) {
                ImageIcon icon = new ImageIcon(imgURL);
                Image img = icon.getImage().getScaledInstance(w - 40, 140, Image.SCALE_SMOOTH);
                imgLabel.setIcon(new ImageIcon(img));
            } else {
                imgLabel.setText("<html><font color='gray'>No Image</font></html>");
            }
        } catch (Exception e) { e.printStackTrace(); }
        card.add(imgLabel);

        // 2. Car Details
        JLabel name = new JLabel(car.getBrand() + " " + car.getModel());
        name.setFont(new Font("SansSerif", Font.BOLD, 18));
        name.setForeground(TEXT_WHITE);
        name.setBounds(20, 200, w-40, 25);
        card.add(name);

        JLabel price = new JLabel("$" + car.getPricePerDay() + " / day");
        price.setForeground(new Color(200, 200, 200));
        price.setBounds(20, 230, w-40, 20);
        card.add(price);

        card.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) { 
                if(car.isAvailable()) dashboard.showCarDetails(car); 
            }
        });

        return card;
    }
}