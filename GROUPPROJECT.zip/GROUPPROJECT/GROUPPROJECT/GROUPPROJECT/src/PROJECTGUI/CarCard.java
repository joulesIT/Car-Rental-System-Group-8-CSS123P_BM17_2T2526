package PROJECTGUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CarCard {
    private static final Color CARD_BG = new Color(45, 45, 48); // Dark Gray
    private static final Color TEXT_WHITE = Color.WHITE;

    public static JPanel build(Car car, int w, int h, String userName, UserDashboard dashboard) {
        JPanel card = new JPanel(null) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);
                g2.dispose();
            }
        };
        card.setPreferredSize(new Dimension(w, h));

        JLabel name = new JLabel(car.getBrand() + " " + car.getModel());
        name.setFont(new Font("SansSerif", Font.BOLD, 18));
        name.setForeground(TEXT_WHITE);
        name.setBounds(20, h/2 + 20, w-40, 25);
        card.add(name);

        JLabel price = new JLabel("$" + car.getPricePerDay() + " / day");
        price.setForeground(new Color(200, 200, 200));
        price.setBounds(20, h/2 + 45, w-40, 20);
        card.add(price);

        JLabel rating = new JLabel("⭐ " + car.getRating());
        rating.setForeground(new Color(255, 215, 0));
        rating.setBounds(w-70, 15, 60, 20);
        card.add(rating);

        card.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) { if(car.isAvailable()) dashboard.showCarDetails(car); }
        });

        return card;
    }
}