package PROJECTGUI;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;

public class ManageFleetView extends JPanel {
    private DefaultTableModel model;
    private JTable table;
    private UserDashboard dashboard;

    public ManageFleetView(UserDashboard dashboard) {
        this.dashboard = dashboard;
        setLayout(new BorderLayout(15, 15));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JButton addBtn = new JButton("+ Add New Car");
        addBtn.addActionListener(e -> addCarDialog());
        add(addBtn, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"ID", "Vehicle", "Status", "Action"}, 0);
        table = new JTable(model);
        table.setRowHeight(40);
        loadFleetData();

        // Attach custom renderer/editor for the Action buttons
        table.getColumn("Action").setCellRenderer(new FleetActionRenderer());
        table.getColumn("Action").setCellEditor(new FleetActionEditor(new JCheckBox(), this));

        add(new JScrollPane(table), BorderLayout.CENTER);
    }

    public void loadFleetData() {
        model.setRowCount(0);
        String sql = "SELECT c.id, c.brand, c.model, c.available, r.end_date " +
                     "FROM cars c LEFT JOIN rentals r ON c.id = r.car_id AND c.available = 0";
        try (Connection conn = DBConnection.connect(); ResultSet rs = conn.createStatement().executeQuery(sql)) {
            while (rs.next()) {
                String status = "Available";
                if (!rs.getBoolean("available")) {
                    Date d = rs.getDate("end_date");
                    if (d != null) {
                        LocalDate end = d.toLocalDate();
                        LocalDate now = LocalDate.now();
                        status = end.isBefore(now) ? "OVERDUE" : (end.isEqual(now) ? "DUE TODAY" : "RENTED");
                    } else status = "RENTED";
                }
                model.addRow(new Object[]{rs.getInt("id"), rs.getString("brand") + " " + rs.getString("model"), status, "Manage"});
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void processReturn(int id) {
        String input = JOptionPane.showInputDialog("Enter Customer Rating (1.0 - 5.0):");
        if (input != null) {
            try (Connection conn = DBConnection.connect()) {
                PreparedStatement ps = conn.prepareStatement("UPDATE cars SET available=1, rating=(rating+?)/2 WHERE id=?");
                ps.setDouble(1, Double.parseDouble(input));
                ps.setInt(2, id);
                ps.executeUpdate();
                loadFleetData(); dashboard.loadCarsFromDB();
            } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error processing return."); }
        }
    }

    public void removeCar(int id) {
        if (JOptionPane.showConfirmDialog(this, "Delete Car ID: " + id + "?") == 0) {
            try (Connection conn = DBConnection.connect()) {
                PreparedStatement ps = conn.prepareStatement("DELETE FROM cars WHERE id=?");
                ps.setInt(1, id); ps.executeUpdate();
                loadFleetData(); dashboard.loadCarsFromDB();
            } catch (SQLException e) { e.printStackTrace(); }
        }
    }

    private void addCarDialog() {
        // Implementation for Add Car Popup (Brand, Model, Price, Type)
        // ... (Similar to previous logic)
    }
}