package PROJECTGUI;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class CarDetailsView extends JPanel {
    private final UserDashboard parent;
    private final Car car;

    public CarDetailsView(Car car, UserDashboard parent) {
        this.car = car;
        this.parent = parent;
        
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // ── TOP NAVIGATION ──
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setOpaque(false);
        topPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 0, 0));

        JButton backBtn = new JButton("← Back to Browse");
        backBtn.setBackground(new Color(204, 41, 34)); 
        backBtn.setForeground(Color.WHITE);
        backBtn.setFont(new Font("SansSerif", Font.BOLD, 14));
        backBtn.addActionListener(e -> parent.showBrowseCars());
        
        topPanel.add(backBtn);
        add(topPanel, BorderLayout.NORTH);

        // ── MAIN CONTENT ──
        JPanel content = new JPanel(new GridLayout(1, 2, 30, 0));
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(20, 50, 40, 50));

        // Left Side: Image
        JLabel imgLabel = new JLabel("", JLabel.CENTER);
        try {
            URL imgURL = getClass().getResource("/PROJECTGUI/" + car.getImagePath());
            if (imgURL != null) {
                ImageIcon icon = new ImageIcon(imgURL);
                Image img = icon.getImage().getScaledInstance(500, 350, Image.SCALE_SMOOTH);
                imgLabel.setIcon(new ImageIcon(img));
            } else {
                imgLabel.setText("Image not found");
            }
        } catch (Exception e) { e.printStackTrace(); }

        // Right Side: Info
        JPanel specs = new JPanel();
        specs.setLayout(new BoxLayout(specs, BoxLayout.Y_AXIS));
        specs.setOpaque(false);

        JLabel nameLbl = new JLabel(car.getBrand() + " " + car.getModel());
        nameLbl.setFont(new Font("SansSerif", Font.BOLD, 32));

        JLabel typeLbl = new JLabel("Category: " + car.getType());
        typeLbl.setFont(new Font("SansSerif", Font.ITALIC, 18));
        typeLbl.setForeground(Color.GRAY);

        JLabel rateLbl = new JLabel("$" + car.getPricePerDay() + " / day");
        rateLbl.setFont(new Font("SansSerif", Font.BOLD, 24));
        rateLbl.setForeground(new Color(204, 41, 34));

        JTextArea desc = new JTextArea(car.getDescription());
        desc.setWrapStyleWord(true);
        desc.setLineWrap(true);
        desc.setEditable(false);
        desc.setFont(new Font("SansSerif", Font.PLAIN, 16));
        desc.setBackground(Color.WHITE);

        JButton bookBtn = new JButton("Proceed to Booking");
        bookBtn.setBackground(new Color(204, 41, 34));
        bookBtn.setForeground(Color.WHITE);
        bookBtn.setFont(new Font("SansSerif", Font.BOLD, 20));
        bookBtn.setPreferredSize(new Dimension(300, 50));
        bookBtn.addActionListener(e -> parent.showBooking(car));

        specs.add(nameLbl);
        specs.add(typeLbl);
        specs.add(Box.createVerticalStrut(10));
        specs.add(rateLbl);
        specs.add(Box.createVerticalStrut(20));
        specs.add(desc);
        specs.add(Box.createVerticalStrut(40));
        specs.add(bookBtn);

        content.add(imgLabel);
        content.add(specs);
        add(content, BorderLayout.CENTER);
    }
}