package PROJECTGUI;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class BookingFormView extends JPanel {
    private JComboBox<LocalDate> startD, endD;
    private JLabel totalLbl;
    private final Car car;
    private final String username;
    private final UserDashboard dashboard;

    public BookingFormView(String username, Car car, UserDashboard dashboard) {
        this.car = car;
        this.username = username;
        this.dashboard = dashboard;

        setLayout(new GridBagLayout()); // Fixes the broadening issue
        setBackground(new Color(245, 245, 245));

        JPanel formCard = new JPanel(new GridLayout(1, 2, 40, 0));
        formCard.setPreferredSize(new Dimension(850, 500));
        formCard.setBackground(Color.WHITE);
        formCard.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        // Form Side
        JPanel left = new JPanel();
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setOpaque(false);

        startD = new JComboBox<>();
        endD = new JComboBox<>();
        for(int i=0; i<30; i++) {
            startD.addItem(LocalDate.now().plusDays(i));
            endD.addItem(LocalDate.now().plusDays(i+1));
        }

        totalLbl = new JLabel("Total: $0.00");
        totalLbl.setFont(new Font("SansSerif", Font.BOLD, 18));

        JButton next = new JButton("Confirm Booking");
        next.addActionListener(e -> {
            LocalDate s = (LocalDate)startD.getSelectedItem();
            LocalDate end = (LocalDate)endD.getSelectedItem();
            long days = ChronoUnit.DAYS.between(s, end);
            if(days > 0) dashboard.showPayment(car, java.sql.Date.valueOf(s), java.sql.Date.valueOf(end), days * car.getPricePerDay());
        });

        left.add(new JLabel("Pickup Date:")); left.add(startD);
        left.add(Box.createVerticalStrut(20));
        left.add(new JLabel("Return Date:")); left.add(endD);
        left.add(Box.createVerticalStrut(40));
        left.add(totalLbl);
        left.add(Box.createVerticalStrut(20));
        left.add(next);

        formCard.add(left);
        add(formCard); // Centered because of GridBagLayout
    }
}