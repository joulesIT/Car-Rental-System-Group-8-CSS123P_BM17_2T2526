package PROJECTGUI;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class BookingFormView extends JPanel {
    private JTextField nameF, licenseF;
    private JComboBox<LocalDate> startDatePicker, endDatePicker;
    private JLabel totalLbl, carNameLbl;
    private final Car car;
    private final String username;
    private final UserDashboard dashboard;

    public BookingFormView(String username, Car car, UserDashboard dashboard) {
        this.car = car;
        this.username = username;
        this.dashboard = dashboard;
        
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // Header
        JPanel header = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton backBtn = new JButton("← Back");
        backBtn.addActionListener(e -> dashboard.showBrowseCars());
        header.add(backBtn);
        add(header, BorderLayout.NORTH);

        // Content
        JPanel content = new JPanel(new GridLayout(1, 2, 20, 0));
        content.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        
        carNameLbl = new JLabel(car.getBrand() + " " + car.getModel() + " (" + car.getType() + ")");
        carNameLbl.setFont(new Font("SansSerif", Font.BOLD, 22));
        
        nameF = new JTextField(); licenseF = new JTextField();
        startDatePicker = new JComboBox<>(); endDatePicker = new JComboBox<>();
        setupDates();

        form.add(carNameLbl);
        form.add(Box.createVerticalStrut(20));
        form.add(new JLabel("Full Name:")); form.add(nameF);
        form.add(new JLabel("License Number:")); form.add(licenseF);
        form.add(new JLabel("Pickup Date:")); form.add(startDatePicker);
        form.add(new JLabel("Return Date:")); form.add(endDatePicker);

        totalLbl = new JLabel("Total: $0.00");
        totalLbl.setFont(new Font("SansSerif", Font.BOLD, 24));
        totalLbl.setForeground(new Color(204, 41, 34));

        content.add(form);
        content.add(totalLbl);
        add(content, BorderLayout.CENTER);

        JButton nextBtn = new JButton("Proceed to Payment");
        nextBtn.addActionListener(e -> proceed());
        add(nextBtn, BorderLayout.SOUTH);

        startDatePicker.addActionListener(e -> updatePrice());
        endDatePicker.addActionListener(e -> updatePrice());
        updatePrice();
    }

    private void setupDates() {
        for(int i=0; i<30; i++) {
            startDatePicker.addItem(LocalDate.now().plusDays(i));
            endDatePicker.addItem(LocalDate.now().plusDays(i+1));
        }
    }

    private void updatePrice() {
        LocalDate start = (LocalDate)startDatePicker.getSelectedItem();
        LocalDate end = (LocalDate)endDatePicker.getSelectedItem();
        long days = ChronoUnit.DAYS.between(start, end);
        
        if (days <= 0) days = 1; // Minimum 1 day charge
        double total = days * car.getPricePerDay();
        totalLbl.setText(String.format("Total: $%.2f (%d Days)", total, days));
    }

    private void proceed() {
        LocalDate s = (LocalDate)startDatePicker.getSelectedItem();
        LocalDate e = (LocalDate)endDatePicker.getSelectedItem();
        long days = ChronoUnit.DAYS.between(s, e);
        
        if(days <= 0) {
            JOptionPane.showMessageDialog(this, "Return date must be after pickup date.");
            return;
        }

        dashboard.showPayment(car, java.sql.Date.valueOf(s), java.sql.Date.valueOf(e), days * car.getPricePerDay());
    }
}