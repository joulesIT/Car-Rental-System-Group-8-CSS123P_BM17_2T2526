package PROJECTGUI;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class PaymentMethodView extends JPanel {
    private final UserDashboard dashboard;
    private final Car car;
    private final java.sql.Date start, end;
    private final double total;
    private final String username;

    public PaymentMethodView(String username, Car car, java.sql.Date start, java.sql.Date end, double total, UserDashboard dashboard) {
        this.username = username;
        this.car = car;
        this.start = start;
        this.end = end;
        this.total = total;
        this.dashboard = dashboard;

        setLayout(new GridBagLayout()); 
        setBackground(new Color(242, 242, 242));
        
        JPanel container = new JPanel();
        container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
        container.setBackground(Color.WHITE);
        container.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        container.setPreferredSize(new Dimension(400, 450));

        JLabel title = new JLabel("Payment Details");
        title.setFont(new Font("SansSerif", Font.BOLD, 22));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel amountLbl = new JLabel(String.format("Amount Due: $%.2f", total));
        amountLbl.setFont(new Font("SansSerif", Font.BOLD, 18));
        amountLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton cardBtn = new JButton("Pay with Credit Card");
        JButton cashBtn = new JButton("Pay at Pickup");
        
        styleButton(cardBtn);
        styleButton(cashBtn);

        cardBtn.addActionListener(e -> finalizeBooking("CREDIT_CARD"));
        cashBtn.addActionListener(e -> finalizeBooking("CASH_ON_PICKUP"));

        container.add(title);
        container.add(Box.createVerticalStrut(20));
        container.add(amountLbl);
        container.add(Box.createVerticalStrut(40));
        container.add(cardBtn);
        container.add(Box.createVerticalStrut(10));
        container.add(cashBtn);

        add(container);
    }

    private void styleButton(JButton btn) {
        btn.setMaximumSize(new Dimension(300, 45));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setBackground(new Color(45, 45, 48));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
    }

    private void finalizeBooking(String method) {
        try (Connection conn = DBConnection.connect()) {
            // 1. Record the Rental
            String sql = "INSERT INTO rentals (car_id, username, start_date, end_date, total_price, payment_method) VALUES (?,?,?,?,?,?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, car.getId());
            ps.setString(2, username);
            ps.setDate(3, start);
            ps.setDate(4, end);
            ps.setDouble(5, total);
            ps.setString(6, method);
            ps.executeUpdate();

            // 2. Mark Car as Rented
            PreparedStatement ps2 = conn.prepareStatement("UPDATE cars SET available = 0 WHERE id = ?");
            ps2.setInt(1, car.getId());
            ps2.executeUpdate();

            JOptionPane.showMessageDialog(this, "Booking Successful!");
            dashboard.showBrowseCars(); // Go back to browse and refresh list
        } catch (SQLException e) { 
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
        }
    }
}