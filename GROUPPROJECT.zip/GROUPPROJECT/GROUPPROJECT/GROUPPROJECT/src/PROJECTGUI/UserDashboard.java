package PROJECTGUI;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class UserDashboard extends JFrame {
    private final String userName;
    private final String userRole;
    private final CardLayout cards = new CardLayout();
    private final JPanel root = new JPanel(cards);
    private JPanel carsGrid;

    public UserDashboard(String userName, String userRole) {
        this.userName = userName;
        this.userRole = (userRole == null) ? "USER" : userRole.toUpperCase();
        
        setTitle("DriveDash — " + (this.userRole.equals("ADMIN") ? "Admin Panel" : userName));
        setSize(1400, 850);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        Runnable logoutAction = () -> {
            if (JOptionPane.showConfirmDialog(this, "Sign out?") == 0) {
                this.dispose(); new LandingPage().setVisible(true);
            }
        };

        // Navigation
        JPanel nav = this.userRole.equals("ADMIN") ? 
            AdminNavBar.build("Home", userName, cards, root, () -> showManageFleet(), () -> showRentalHistory(), logoutAction) :
            ClientNavBar.build("Home", userName, cards, root, () -> showBrowseCars(), () -> showRentalHistory(), logoutAction);
        add(nav, BorderLayout.NORTH);

        // Browse Grid
        JPanel browsePage = new JPanel(new BorderLayout());
        browsePage.setBackground(new Color(245, 246, 248));
        carsGrid = new JPanel(new GridLayout(0, 4, 25, 25));
        carsGrid.setBackground(new Color(245, 246, 248));
        carsGrid.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));
        browsePage.add(new JScrollPane(carsGrid), BorderLayout.CENTER);

        root.add(new JPanel(), "HOME"); 
        root.add(browsePage, "BROWSE");
        add(root, BorderLayout.CENTER);
        
        showBrowseCars();
    }

    public void showBrowseCars() { loadCarsFromDB(); cards.show(root, "BROWSE"); }

    public void showManageFleet() {
        refreshComponent(ManageFleetView.class);
        root.add(new ManageFleetView(this), "MANAGE");
        cards.show(root, "MANAGE");
    }

    public void showRentalHistory() {
        refreshComponent(RentalHistoryView.class);
        String viewKey = userRole.equals("ADMIN") ? "ADMIN_VIEW" : userName;
        root.add(new RentalHistoryView(viewKey), "HISTORY");
        cards.show(root, "HISTORY");
    }

    public void showCarDetails(Car car) {
        root.add(new CarDetailsView(car, this), "CAR_DETAILS");
        cards.show(root, "CAR_DETAILS");
    }

    public void showBooking(Car car) {
        root.add(new BookingFormView(userName, car, this), "BOOKING");
        cards.show(root, "BOOKING");
    }

    public void showPayment(Car car, java.sql.Date s, java.sql.Date e, double t) {
        root.add(new PaymentMethodView(userName, car, s, e, t, this), "PAYMENT");
        cards.show(root, "PAYMENT");
    }

    private void refreshComponent(Class<?> type) {
        for (Component c : root.getComponents()) if (type.isInstance(c)) root.remove(c);
    }

    public void loadCarsFromDB() {
        carsGrid.removeAll();
        try (Connection conn = DBConnection.connect()) {
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM cars");
            while (rs.next()) {
                Car car = new Car(
                    rs.getInt("id"), rs.getString("brand"), rs.getString("model"),
                    rs.getString("type"), rs.getDouble("price_per_day"),
                    rs.getDouble("rating"), rs.getString("image_path"), rs.getString("description")
                );
                car.setAvailable(rs.getBoolean("available"));
                carsGrid.add(CarCard.build(car, 280, 380, userName, this));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        root.revalidate(); root.repaint();
    }
}