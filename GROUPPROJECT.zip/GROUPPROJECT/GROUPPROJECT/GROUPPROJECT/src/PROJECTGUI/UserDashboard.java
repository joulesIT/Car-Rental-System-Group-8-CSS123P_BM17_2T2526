package PROJECTGUI;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class UserDashboard extends JFrame {
    private final String userName, userRole;
    private final CardLayout cards = new CardLayout();
    private final JPanel root = new JPanel(cards);
    private JPanel carsGrid;

    public UserDashboard(String userName, String userRole) {
        this.userName = userName;
        this.userRole = (userRole == null) ? "USER" : userRole.toUpperCase();
        
        setTitle("DriveDash — " + (this.userRole.equals("ADMIN") ? "Admin Panel" : userName));
        setSize(1400, 850);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // 1. Setup Navigation
        Runnable logoutAction = () -> {
            if (JOptionPane.showConfirmDialog(this, "Sign out of DriveDash?") == 0) {
                this.dispose(); 
                new LandingPage().setVisible(true);
            }
        };

        // Select the correct Navbar based on Role
        JPanel nav = this.userRole.equals("ADMIN") ? 
            AdminNavBar.build("Home", userName, cards, root, () -> showManageFleet(), () -> showRentalHistory(), logoutAction) :
            ClientNavBar.build("Home", userName, cards, root, () -> showBrowseCars(), () -> showRentalHistory(), logoutAction);
        add(nav, BorderLayout.NORTH);

        // 2. Build the Browse Cars View (Constrainted to prevent broadening)
        JPanel browsePage = new JPanel(new BorderLayout());
        browsePage.setBackground(new Color(240, 240, 240));
        
        carsGrid = new JPanel(new GridLayout(0, 4, 25, 25)); // 4 columns
        carsGrid.setBackground(new Color(240, 240, 240));
        
        // Wrap grid in a container with side padding to prevent it from hitting edges
        JPanel gridPadding = new JPanel(new BorderLayout());
        gridPadding.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));
        gridPadding.add(carsGrid, BorderLayout.NORTH); 
        gridPadding.setOpaque(false);

        JScrollPane scroll = new JScrollPane(gridPadding);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        browsePage.add(scroll, BorderLayout.CENTER);

        // 3. Add Permanent Views to CardLayout
        root.add(browsePage, "BROWSE");
        add(root, BorderLayout.CENTER);

        // 4. ADMIN REDIRECT: Immediately show fleet management if admin
        if (this.userRole.equals("ADMIN")) {
            showManageFleet();
        } else {
            showBrowseCars();
        }
    }

    // ── NAVIGATION METHODS ──

    public void showBrowseCars() {
        loadCarsFromDB();
        cards.show(root, "BROWSE");
    }

    public void showManageFleet() {
        refreshView("MANAGE", new ManageFleetView(this));
        cards.show(root, "MANAGE");
    }

    public void showCarDetails(Car car) {
        refreshView("DETAILS", new CarDetailsView(car, this));
        cards.show(root, "DETAILS");
    }

    public void showBooking(Car car) {
        refreshView("BOOKING", new BookingFormView(userName, car, this));
        cards.show(root, "BOOKING");
    }

    public void showPayment(Car car, java.sql.Date s, java.sql.Date e, double t) {
        refreshView("PAYMENT", new PaymentMethodView(userName, car, s, e, t, this));
        cards.show(root, "PAYMENT");
    }
    
    public void showRentalHistory() {
        refreshView("HISTORY", new RentalHistoryView(userRole.equals("ADMIN") ? "ADMIN_VIEW" : userName));
        cards.show(root, "HISTORY");
    }

    /**
     * Helper to remove old versions of a view before adding a new one
     * Prevents memory leaks and "duplicate component" errors in CardLayout.
     */
    private void refreshView(String name, JPanel newView) {
        Component[] components = root.getComponents();
        for (Component c : components) {
            if (name.equals(root.getLayout().toString())) { /* CardLayout logic */ }
        }
        root.add(newView, name);
    }

    // ── DATABASE SYNC ──

    public void loadCarsFromDB() {
        carsGrid.removeAll();
        try (Connection conn = DBConnection.connect()) {
            // Using * to ensure all columns (type, price, description) are fetched
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM cars");
            while (rs.next()) {
                Car car = new Car(
                    rs.getInt("id"),
                    rs.getString("brand"),
                    rs.getString("model"),
                    rs.getString("type"),
                    rs.getDouble("price_per_day"),
                    rs.getDouble("rating"),
                    rs.getString("image_path"),
                    rs.getString("description")
                );
                car.setAvailable(rs.getBoolean("available"));
                
                // Add the card to the grid
                carsGrid.add(CarCard.build(car, 280, 380, userName, this));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading cars: " + e.getMessage());
        }
        carsGrid.revalidate();
        carsGrid.repaint();
    }
}