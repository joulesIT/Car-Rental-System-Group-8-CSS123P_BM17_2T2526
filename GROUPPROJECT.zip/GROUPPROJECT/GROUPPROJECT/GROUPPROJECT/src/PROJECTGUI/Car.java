package PROJECTGUI;

public class Car {
    private int id;
    private String brand, model, type, description, imagePath;
    private double rating, pricePerDay;
    private boolean available;

    // Synchronized Constructor (8 Parameters)
    public Car(int id, String brand, String model, String type, double price, double rating, String imagePath, String description) {
        this.id = id;
        this.brand = brand;
        this.model = model;
        this.type = type;
        this.pricePerDay = price;
        this.rating = rating;
        this.imagePath = imagePath;
        this.description = description;
        this.available = true;
    }

    // Getters
    public int getId() { return id; }
    public String getBrand() { return brand; }
    public String getModel() { return model; }
    public String getType() { return type; }
    public double getPricePerDay() { return pricePerDay; }
    public double getRating() { return rating; }
    public String getImagePath() { return imagePath; }
    public String getDescription() { return description; }
    public boolean isAvailable() { return available; }
    
    // Setters
    public void setAvailable(boolean available) { this.available = available; }
    public void setRating(double rating) { this.rating = rating; }
}