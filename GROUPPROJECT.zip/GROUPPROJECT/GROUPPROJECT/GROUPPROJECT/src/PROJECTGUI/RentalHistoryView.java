package PROJECTGUI;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.*;

public class RentalHistoryView extends JPanel {
    private final String username;
    private DefaultTableModel model;
    private final boolean isAdmin;

    public RentalHistoryView(String username) {
        // Check if this is being opened by an Admin
        this.isAdmin = username.equals("ADMIN_VIEW");
        this.username = username;

        setLayout(new BorderLayout(0, 20));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        // ── HEADER ──
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JLabel title = new JLabel(isAdmin ? "Global Rental History (Admin)" : "My Rental History");
        title.setFont(new Font("SansSerif", Font.BOLD, 28));
        header.add(title, BorderLayout.WEST);

        // Only show "Clear History" for regular users, or customize for Admin
        JButton clearBtn = new JButton(isAdmin ? "Purge All Records" : "Clear My History");
        styleButton(clearBtn);
        clearBtn.addActionListener(e -> clearHistory());
        header.add(clearBtn, BorderLayout.EAST);

        add(header, BorderLayout.NORTH);

        // ── TABLE ──
        // Added "User" column so Admin knows who rented which car
        String[] cols = isAdmin ? 
            new String[]{"ID", "Customer", "Car Name", "Start Date", "End Date", "Total"} :
            new String[]{"ID", "Car Name", "Start Date", "End Date", "Total Paid", "Method"};

        model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        JTable table = new JTable(model);
        table.setRowHeight(40);
        table.setFont(new Font("SansSerif", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 14));
        
        JScrollPane scroll = new JScrollPane(table);
        scroll.getViewport().setBackground(Color.WHITE);
        add(scroll, BorderLayout.CENTER);

        loadData();
    }

    private void loadData() {
        model.setRowCount(0);
        String query;
        
        // If Admin, don't filter by username
        if (this.username.equals("ADMIN_VIEW")) {
            query = "SELECT r.id, CONCAT(c.brand, ' ', c.model) as car_name, r.username, r.start_date, r.end_date, r.total_price, r.payment_method " +
                    "FROM rentals r JOIN cars c ON r.car_id = c.id ORDER BY r.id DESC";
        } else {
            query = "SELECT r.id, CONCAT(c.brand, ' ', c.model) as car_name, r.username, r.start_date, r.end_date, r.total_price, r.payment_method " +
                    "FROM rentals r JOIN cars c ON r.car_id = c.id WHERE r.username = ? ORDER BY r.id DESC";
        }

        try (Connection conn = DBConnection.connect();
             PreparedStatement ps = conn.prepareStatement(query)) {
            
            if (!this.username.equals("ADMIN_VIEW")) {
                ps.setString(1, username);
            }
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                model.addRow(new Object[]{
                    "#" + rs.getInt("id"),
                    rs.getString("car_name"),
                    rs.getDate("start_date"),
                    rs.getDate("end_date"),
                    "$" + String.format("%.2f", rs.getDouble("total_price")),
                    rs.getString("payment_method")
                });
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }

    private void clearHistory() {
        String confirmMsg = isAdmin ? "Delete EVERY rental record in the database?" : "Clear your history?";
        int choice = JOptionPane.showConfirmDialog(this, confirmMsg, "Confirm Delete", JOptionPane.YES_NO_OPTION);
        
        if (choice == JOptionPane.YES_OPTION) {
            String deleteSql = isAdmin ? "DELETE FROM rentals" : "DELETE FROM rentals WHERE username = ?";
            try (Connection conn = DBConnection.connect();
                 PreparedStatement ps = conn.prepareStatement(deleteSql)) {
                
                if (!isAdmin) ps.setString(1, username);
                
                ps.executeUpdate();
                loadData();
                JOptionPane.showMessageDialog(this, "History cleared.");
            } catch (SQLException e) { e.printStackTrace(); }
        }
    }

    private void styleButton(JButton btn) {
        btn.setBackground(new Color(204, 41, 34));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
}