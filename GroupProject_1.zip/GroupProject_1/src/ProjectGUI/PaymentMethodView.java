package ProjectGUI;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class PaymentMethodView extends JPanel {
    private final UserDashboard dashboard;
    private final Car car;
    private final java.sql.Date start, end;
    private final double total;
    private final String username;

    public PaymentMethodView(String username, Car car, java.sql.Date start, java.sql.Date end, double total, UserDashboard dashboard) {
        this.username = username;
        this.car = car;
        this.start = start;
        this.end = end;
        this.total = total;
        this.dashboard = dashboard;

        setLayout(new GridBagLayout()); 
        setBackground(new Color(242, 242, 242));
        
        JPanel container = new JPanel();
        container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
        container.setBackground(Color.WHITE);
        container.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));
        container.setPreferredSize(new Dimension(450, 500));

        // Title
        JLabel title = new JLabel("Select Payment Method");
        title.setFont(new Font("SansSerif", Font.BOLD, 24));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Amount Display (₱)
        JLabel amountLbl = new JLabel(String.format("Total Amount: ₱%,.2f", total));
        amountLbl.setFont(new Font("SansSerif", Font.BOLD, 20));
        amountLbl.setForeground(new Color(204, 41, 34));
        amountLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

        // 1. Credit/Debit Card Button
        JButton cardBtn = new JButton("💳  Credit / Debit Card");
        styleButton(cardBtn);
        cardBtn.addActionListener(e -> finalizeBooking("Credit/Debit Card"));

        // 2. Cash on Pickup Button
        JButton cashBtn = new JButton("💵  Cash on Pickup");
        styleButton(cashBtn);
        cashBtn.addActionListener(e -> finalizeBooking("Cash on Pickup"));

        // Add components with spacing
        container.add(title);
        container.add(Box.createVerticalStrut(10));
        container.add(amountLbl);
        container.add(Box.createVerticalStrut(40));
        container.add(cardBtn);
        container.add(Box.createVerticalStrut(15));
        container.add(cashBtn);

        add(container);
    }

    private void styleButton(JButton btn) {
        btn.setMaximumSize(new Dimension(350, 60));
        btn.setPreferredSize(new Dimension(350, 60));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setBackground(new Color(30, 30, 30));
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("SansSerif", Font.BOLD, 16));
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Hover effect
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { btn.setBackground(new Color(204, 41, 34)); }
            public void mouseExited(java.awt.event.MouseEvent e) { btn.setBackground(new Color(30, 30, 30)); }
        });
    }

    private void finalizeBooking(String method) {
        if (method.equals("Credit/Debit Card")) {
            showCardInputDialog();
        } else {
            processDatabaseUpdate(method); // For Cash on Pickup
        }
    }

    private void showCardInputDialog() {
        JPanel panel = new JPanel(new GridLayout(0, 1, 5, 5));
        panel.setPreferredSize(new Dimension(300, 200));

        JTextField cardNum = new JTextField();
        JTextField expiry = new JTextField("MM/YY");
        JPasswordField cvv = new JPasswordField();

        panel.add(new JLabel("Card Number:"));
        panel.add(cardNum);
        panel.add(new JLabel("Expiry Date:"));
        panel.add(expiry);
        panel.add(new JLabel("CVV:"));
        panel.add(cvv);

        int result = JOptionPane.showConfirmDialog(this, panel, "Enter Card Credentials", 
                     JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            if (cardNum.getText().length() < 13 || cvv.getPassword().length < 3) {
                JOptionPane.showMessageDialog(this, "Invalid Card Details. Please try again.");
            } else {
                processDatabaseUpdate("Credit/Debit Card");
            }
        }
    }

    private void processDatabaseUpdate(String method) {
        try (Connection conn = DBConnection.connect()) {
            // 1. Record Rental
            String sql = "INSERT INTO rentals (car_id, username, start_date, end_date, total_price, payment_method) VALUES (?,?,?,?,?,?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, car.getId());
            ps.setString(2, username);
            ps.setDate(3, start);
            ps.setDate(4, end);
            ps.setDouble(5, total);
            ps.setString(6, method);
            ps.executeUpdate();

            // 2. Mark Car Unavailable
            PreparedStatement ps2 = conn.prepareStatement("UPDATE cars SET available = 0 WHERE id = ?");
            ps2.setInt(1, car.getId());
            ps2.executeUpdate();

            JOptionPane.showMessageDialog(this, "Booking Successful via " + method + "!");
            dashboard.showBrowseCars();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
}