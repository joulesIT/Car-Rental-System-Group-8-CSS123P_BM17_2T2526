package ProjectGUI;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.sql.*;

public class BookingFormView extends JPanel {
    private JComboBox<LocalDate> startD, endD;
    private JLabel totalLbl;
    private final Car car;
    private final String username;
    private final UserDashboard dashboard;
    
    // User Data variables
    private String legalName = "N/A", license = "N/A", phone = "N/A";

    public BookingFormView(String username, Car car, UserDashboard dashboard) {
        this.car = car;
        this.username = username;
        this.dashboard = dashboard;

        fetchUserDetails(); // Retrieve Name, License, and Phone from DB
        
        setLayout(new GridBagLayout());
        setBackground(new Color(245, 245, 245));

        // --- MAIN FORM CARD ---
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230), 1),
            BorderFactory.createEmptyBorder(40, 50, 40, 50)
        ));
        card.setPreferredSize(new Dimension(500, 650));

        // Header
        JLabel title = new JLabel("Booking Confirmation");
        title.setFont(new Font("SansSerif", Font.BOLD, 26));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // 1. VEHICLE INFO
        JLabel carLabel = new JLabel(car.getBrand().toUpperCase() + " " + car.getModel());
        carLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        carLabel.setForeground(new Color(204, 41, 34));
        carLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // 2. USER DETAILS (Retrieved from DB)
        JPanel detailsPanel = new JPanel(new GridLayout(0, 1, 5, 5));
        detailsPanel.setBackground(Color.WHITE);
        detailsPanel.setMaximumSize(new Dimension(400, 150));
        detailsPanel.add(new JLabel("<html><b>Legal Name:</b> " + legalName + "</html>"));
        detailsPanel.add(new JLabel("<html><b>Driver's License:</b> " + license + "</html>"));
        detailsPanel.add(new JLabel("<html><b>Contact No:</b> " + phone + "</html>"));
        detailsPanel.setBorder(BorderFactory.createTitledBorder("Customer Information"));

        // 3. DATE SELECTION
        startD = new JComboBox<>();
        endD = new JComboBox<>();
        for(int i=0; i<30; i++) {
            startD.addItem(LocalDate.now().plusDays(i));
            endD.addItem(LocalDate.now().plusDays(i+1));
        }
        startD.addActionListener(e -> updatePrice());
        endD.addActionListener(e -> updatePrice());

        // 4. PRICE SUMMARY
        totalLbl = new JLabel("Total: ₱0.00");
        totalLbl.setFont(new Font("SansSerif", Font.BOLD, 22));
        totalLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

        // 5. NEXT BUTTON
        JButton nextBtn = new JButton("PROCEED TO PAYMENT");
        nextBtn.setBackground(new Color(204, 41, 34));
        nextBtn.setForeground(Color.WHITE);
        nextBtn.setFont(new Font("SansSerif", Font.BOLD, 16));
        nextBtn.setFocusPainted(false);
        nextBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        nextBtn.setMaximumSize(new Dimension(400, 50));
        nextBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        nextBtn.addActionListener(e -> {
            LocalDate s = (LocalDate)startD.getSelectedItem();
            LocalDate end = (LocalDate)endD.getSelectedItem();
            long days = ChronoUnit.DAYS.between(s, end);
            if(days <= 0) days = 1;
            dashboard.showPayment(car, java.sql.Date.valueOf(s), java.sql.Date.valueOf(end), days * car.getPricePerDay());
        });

        // Add to card
        card.add(title);
        card.add(Box.createVerticalStrut(10));
        card.add(carLabel);
        card.add(Box.createVerticalStrut(30));
        card.add(detailsPanel);
        card.add(Box.createVerticalStrut(30));
        card.add(new JLabel("Pickup Date:"));
        card.add(startD);
        card.add(Box.createVerticalStrut(15));
        card.add(new JLabel("Return Date:"));
        card.add(endD);
        card.add(Box.createVerticalStrut(40));
        card.add(totalLbl);
        card.add(Box.createVerticalStrut(20));
        card.add(nextBtn);

        add(card);
        updatePrice();
    }

    private void fetchUserDetails() {
        try (Connection conn = DBConnection.connect();
             PreparedStatement ps = conn.prepareStatement("SELECT legal_name, drivers_license, phone_number FROM users WHERE USERNAME = ?")) {
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                legalName = rs.getString("legal_name");
                license = rs.getString("drivers_license");
                phone = rs.getString("phone_number");
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }

    private void updatePrice() {
        LocalDate s = (LocalDate)startD.getSelectedItem();
        LocalDate e = (LocalDate)endD.getSelectedItem();
        long days = ChronoUnit.DAYS.between(s, e);
        if (days <= 0) days = 1;
        totalLbl.setText(String.format("Total: ₱%,.2f", days * car.getPricePerDay()));
    }
}