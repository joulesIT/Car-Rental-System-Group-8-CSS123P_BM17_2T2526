package ProjectGUI;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class UserDashboard extends JFrame {
    private final String userName, userRole;
    private final CardLayout cards = new CardLayout();
    private final JPanel root = new JPanel(cards);
    private JPanel carsGrid;

    public UserDashboard(String userName, String userRole) {
        this.userName = userName;
        this.userRole = (userRole == null) ? "USER" : userRole.toUpperCase();
        
        setTitle("DriveDash — " + (this.userRole.equals("ADMIN") ? "Admin Panel" : userName));
        setSize(1400, 850);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        Runnable logoutAction = () -> {
            if (JOptionPane.showConfirmDialog(this, "Sign out?") == 0) {
                this.dispose(); 
                new LandingPage().setVisible(true);
            }
        };

        // NAVIGATION BAR AT THE TOP
        JPanel nav = this.userRole.equals("ADMIN") ? 
            AdminNavBar.build("Home", userName, cards, root, () -> showManageFleet(), () -> showRentalHistory(), logoutAction) :
            ClientNavBar.build("Home", userName, cards, root, () -> showBrowseCars(), () -> showRentalHistory(), logoutAction);
        add(nav, BorderLayout.NORTH); 

        root.setBackground(Color.WHITE);
        add(root, BorderLayout.CENTER);

        setupBrowseCarsView();
        
        if (this.userRole.equals("ADMIN")) {
            showManageFleet();
        } else {
            showBrowseCars();
        }
    }

    private void setupBrowseCarsView() {
        JPanel browsePanel = new JPanel(new BorderLayout());
        browsePanel.setBackground(new Color(245, 245, 245));

        JLabel header = new JLabel("Explore Our Fleet");
        header.setFont(new Font("SansSerif", Font.BOLD, 32));
        header.setHorizontalAlignment(SwingConstants.CENTER); // Center the Title
        header.setBorder(BorderFactory.createEmptyBorder(25, 0, 20, 0));
        browsePanel.add(header, BorderLayout.NORTH);

        // grid with CENTER alignment
        carsGrid = new JPanel(new FlowLayout(FlowLayout.CENTER, 35, 35));
        carsGrid.setBackground(new Color(245, 245, 245));

        JPanel centeringWrapper = new JPanel(new BorderLayout());
        centeringWrapper.setBackground(new Color(245, 245, 245));
        centeringWrapper.add(carsGrid, BorderLayout.NORTH); 

        JScrollPane scroll = new JScrollPane(centeringWrapper);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(18); // Smoother scrolling
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        
        browsePanel.addComponentListener(new java.awt.event.ComponentAdapter() {
            @Override
            public void componentResized(java.awt.event.ComponentEvent e) {
                int cardsPerRow = Math.max(1, scroll.getWidth() / 350); // Estimating card width + gap
                int rows = (int) Math.ceil((double) carsGrid.getComponentCount() / cardsPerRow);
                int newHeight = rows * 460; // Card height (420) + gap
                carsGrid.setPreferredSize(new Dimension(scroll.getWidth() - 50, newHeight));
                carsGrid.revalidate();
            }
        });

        browsePanel.add(scroll, BorderLayout.CENTER);
        root.add(browsePanel, "BrowseCars");
        loadCarsFromDB();
    }

    public void showBrowseCars() {
        loadCarsFromDB();
        cards.show(root, "BrowseCars");
    }

    public void showCarDetails(Car car) {
        root.add(new CarDetailsView(car, this), "CarDetails");
        cards.show(root, "CarDetails");
    }

    public void showBooking(Car car) {
        root.add(new BookingFormView(userName, car, this), "BookingForm");
        cards.show(root, "BookingForm");
    }

    public void showPayment(Car car, java.sql.Date start, java.sql.Date end, double total) {
        root.add(new PaymentMethodView(userName, car, start, end, total, this), "PaymentMethod");
        cards.show(root, "PaymentMethod");
    }

    public void showRentalHistory() {
        String queryUser = userRole.equals("ADMIN") ? "ADMIN_VIEW" : userName;
        root.add(new RentalHistoryView(queryUser), "RentalHistory");
        cards.show(root, "RentalHistory");
    }

    public void showManageFleet() {
        root.add(new ManageFleetView(this), "ManageFleet");
        cards.show(root, "ManageFleet");
    }

    public void loadCarsFromDB() {
        carsGrid.removeAll();
        try (Connection conn = DBConnection.connect()) {
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM cars");
            while (rs.next()) {
                Car car = new Car(
                    rs.getInt("id"), rs.getString("brand"), rs.getString("model"),
                    rs.getString("type"), rs.getDouble("price_per_day"),
                    rs.getDouble("rating"), rs.getString("image_path"), rs.getString("description")
                );
                car.setAvailable(rs.getBoolean("available"));
                carsGrid.add(CarCard.build(car, 300, 400, userName, this));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        carsGrid.revalidate();
        carsGrid.repaint();
    }
}