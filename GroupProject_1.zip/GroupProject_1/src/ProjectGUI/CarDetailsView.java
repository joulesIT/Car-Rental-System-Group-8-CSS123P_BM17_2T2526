package ProjectGUI;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class CarDetailsView extends JPanel {
    private final UserDashboard parent;
    private final Car car;

    public CarDetailsView(Car car, UserDashboard parent) {
        this.car = car;
        this.parent = parent;
        
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // --- TOP NAVIGATION ---
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.setBackground(Color.WHITE);
        JButton back = new JButton("← BACK TO FLEET");
        back.addActionListener(e -> parent.showBrowseCars());
        top.add(back);
        add(top, BorderLayout.NORTH);

        // --- CONTENT PANEL ---
        JPanel content = new JPanel(new GridLayout(1, 2, 40, 0));
        content.setBackground(Color.WHITE);
        content.setBorder(BorderFactory.createEmptyBorder(40, 60, 40, 60));

        // Left: Large Image
        JLabel imgLabel = new JLabel();
        try {
            URL imgURL = CarDetailsView.class.getResource("/PROJECTGUI/IMAGES/" + car.getImagePath());
            if (imgURL != null) {
                ImageIcon icon = new ImageIcon(imgURL);
                Image img = icon.getImage().getScaledInstance(500, 350, Image.SCALE_SMOOTH);
                imgLabel.setIcon(new ImageIcon(img));
            }
        } catch (Exception e) { }
        content.add(imgLabel);

        // Right: Information
        JPanel info = new JPanel();
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
        info.setBackground(Color.WHITE);

        JLabel name = new JLabel(car.getBrand() + " " + car.getModel());
        name.setFont(new Font("SansSerif", Font.BOLD, 36));

        JLabel price = new JLabel(String.format("₱%,.2f / Day", car.getPricePerDay()));
        price.setFont(new Font("SansSerif", Font.BOLD, 24));
        price.setForeground(new Color(204, 41, 34));

        JTextArea desc = new JTextArea(car.getDescription());
        desc.setLineWrap(true);
        desc.setWrapStyleWord(true);
        desc.setEditable(false);
        desc.setFont(new Font("SansSerif", Font.PLAIN, 16));

        JButton rentBtn = new JButton("RENT THIS VEHICLE");
        rentBtn.setBackground(new Color(204, 41, 34));
        rentBtn.setForeground(Color.WHITE);
        rentBtn.setFont(new Font("SansSerif", Font.BOLD, 18));
        rentBtn.setMaximumSize(new Dimension(300, 50));
        rentBtn.addActionListener(e -> parent.showBooking(car));

        info.add(name);
        info.add(Box.createVerticalStrut(10));
        info.add(price);
        info.add(Box.createVerticalStrut(30));
        info.add(new JScrollPane(desc));
        info.add(Box.createVerticalStrut(30));
        info.add(rentBtn);

        content.add(info);
        add(content, BorderLayout.CENTER);
    }
}