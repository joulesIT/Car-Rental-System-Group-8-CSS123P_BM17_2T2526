module ProjectGUI {
    requires java.desktop; // Required for Swing/AWT components
    requires java.sql;     // Required for DBConnection.java
}