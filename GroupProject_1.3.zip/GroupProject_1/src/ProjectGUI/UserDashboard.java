package ProjectGUI;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class UserDashboard extends JFrame {
    private final String userName, userRole;
    private final CardLayout cards = new CardLayout();
    private final JPanel root = new JPanel(cards);
    private JPanel carsGrid;

    public UserDashboard(String userName, String userRole) {
        this.userName = userName;
        this.userRole = (userRole == null) ? "USER" : userRole.toUpperCase();
        
        setTitle("DriveDash — " + (this.userRole.equals("ADMIN") ? "Admin Panel" : userName));
        setSize(1400, 850);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        Runnable logoutAction = () -> {
            if (JOptionPane.showConfirmDialog(this, "Sign out?") == 0) {
                this.dispose(); 
                new LandingPage().setVisible(true);
            }
        };

        // Navigation Switcher
        JPanel nav = this.userRole.equals("ADMIN") ? 
            AdminNavBar.build("Home", userName, cards, root, 
                () -> showAdminHome(), 
                () -> showManageFleet(), 
                () -> showRentalHistory(), 
                logoutAction) :
            ClientNavBar.build("Home", userName, cards, root, 
                () -> showBrowseCars(), 
                () -> showRentalHistory(), 
                logoutAction);
        
        add(nav, BorderLayout.NORTH); 
        root.setBackground(Color.WHITE);
        add(root, BorderLayout.CENTER);

        setupBrowseCarsView();
        
        if (this.userRole.equals("ADMIN")) showAdminHome(); 
        else showBrowseCars();
    }

    // --- Admin Views ---
    public void showAdminHome() {
        JPanel adminHome = new JPanel(new BorderLayout(20, 20));
        adminHome.setBackground(new Color(240, 242, 245));
        adminHome.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        JPanel statsPanel = new JPanel(new GridLayout(1, 3, 25, 0));
        statsPanel.setOpaque(false);
        statsPanel.add(createStatCard("Total Vehicles", "SELECT COUNT(*) FROM cars", new Color(52, 152, 219)));
        statsPanel.add(createStatCard("Active Rentals", "SELECT COUNT(*) FROM cars WHERE available=0", new Color(231, 76, 60)));
        statsPanel.add(createStatCard("Total Earnings", "SELECT SUM(total_price) FROM rentals", new Color(46, 204, 113)));
        adminHome.add(statsPanel, BorderLayout.NORTH);

        JPanel activityPanel = new JPanel(new BorderLayout());
        activityPanel.setBackground(Color.WHITE);
        activityPanel.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220)));

        JLabel title = new JLabel("  Recent System Activity");
        title.setFont(new Font("SansSerif", Font.BOLD, 18));
        title.setPreferredSize(new Dimension(0, 50));
        activityPanel.add(title, BorderLayout.NORTH);

        DefaultListModel<String> listModel = new DefaultListModel<>();
        try (Connection conn = DBConnection.connect()) {
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM rentals ORDER BY id DESC LIMIT 15");
            while (rs.next()) {
                listModel.addElement(String.format("  Booking #%d | User: %s | Car ID: %d | Total: ₱%,.2f", 
                                     rs.getInt("id"), rs.getString("username"), 
                                     rs.getInt("car_id"), rs.getDouble("total_price")));
            }
        } catch (SQLException e) { e.printStackTrace(); }

        JList<String> list = new JList<>(listModel);
        list.setFixedCellHeight(45);
        list.setFont(new Font("Monospaced", Font.PLAIN, 14));
        activityPanel.add(new JScrollPane(list), BorderLayout.CENTER);

        adminHome.add(activityPanel, BorderLayout.CENTER);
        root.add(adminHome, "ADMIN_HOME");
        cards.show(root, "ADMIN_HOME");
    }

    private JPanel createStatCard(String title, String sql, Color color) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230)),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        String val = "0";
        try (Connection conn = DBConnection.connect()) {
            ResultSet rs = conn.createStatement().executeQuery(sql);
            if (rs.next()) {
                val = sql.contains("SUM") ? String.format("₱%,.0f", rs.getDouble(1)) : rs.getString(1);
            }
        } catch (Exception e) { val = "0"; }
        JLabel tLbl = new JLabel(title);
        tLbl.setFont(new Font("SansSerif", Font.PLAIN, 14));
        JLabel vLbl = new JLabel(val == null ? "₱0" : val);
        vLbl.setFont(new Font("SansSerif", Font.BOLD, 32));
        vLbl.setForeground(color);
        card.add(tLbl, BorderLayout.NORTH);
        card.add(vLbl, BorderLayout.CENTER);
        return card;
    }

    public void showManageFleet() {
        root.add(new ManageFleetView(this), "ManageFleet");
        cards.show(root, "ManageFleet");
    }

    public void showRentalHistory() {
        String queryUser = userRole.equals("ADMIN") ? "ADMIN_VIEW" : userName;
        root.add(new RentalHistoryView(queryUser), "RentalHistory");
        cards.show(root, "RentalHistory");
    }

    // --- Browse Cars View (The Grid) ---
    private void setupBrowseCarsView() {
        JPanel browsePanel = new JPanel(new BorderLayout());
        browsePanel.setBackground(new Color(245, 245, 245));

        // Container 1: The Centering Wrapper
        // GridBagLayout centers its content by default if no weights are specified
        JPanel centeringWrapper = new JPanel(new GridBagLayout());
        centeringWrapper.setBackground(new Color(245, 245, 245));
        centeringWrapper.setBorder(BorderFactory.createEmptyBorder(50, 20, 50, 20));

        // Container 2: The Grid itself
        // 0 rows means infinite growth, 4 columns is strict
        carsGrid = new JPanel(new GridLayout(0, 4, 30, 30));
        carsGrid.setOpaque(false);

        centeringWrapper.add(carsGrid, new GridBagConstraints());

        JScrollPane scroll = new JScrollPane(centeringWrapper);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16); // Smoother scrolling
        
        browsePanel.add(scroll, BorderLayout.CENTER);
        root.add(browsePanel, "BrowseCars");
        loadCarsFromDB();
    }

    public void showBrowseCars() { 
        loadCarsFromDB(); 
        cards.show(root, "BrowseCars"); 
    }

    public void loadCarsFromDB() {
        carsGrid.removeAll();
        try (Connection conn = DBConnection.connect()) {
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM cars");
            while (rs.next()) {
                Car car = new Car(
                    rs.getInt("id"), 
                    rs.getString("brand"), 
                    rs.getString("model"), 
                    rs.getString("type"), 
                    rs.getDouble("price_per_day"), 
                    rs.getDouble("rating"), 
                    rs.getString("image_path"), 
                    rs.getString("description")
                );
                car.setAvailable(rs.getBoolean("available"));
                
                // Add the card to the 4-column grid
                carsGrid.add(CarCard.build(car, 300, 420, userName, this));
            }
        } catch (SQLException e) { 
            e.printStackTrace(); 
        }
        carsGrid.revalidate(); 
        carsGrid.repaint();
    }

    // --- Navigation Controls ---
    public void showCarDetails(Car car) { root.add(new CarDetailsView(car, this), "CarDetails"); cards.show(root, "CarDetails"); }
    public void showBooking(Car car) { root.add(new BookingFormView(userName, car, this), "BookingForm"); cards.show(root, "BookingForm"); }
    public void showPayment(Car car, java.sql.Date start, java.sql.Date end, double total) { root.add(new PaymentMethodView(userName, car, start, end, total, this), "PaymentMethod"); cards.show(root, "PaymentMethod"); }
}