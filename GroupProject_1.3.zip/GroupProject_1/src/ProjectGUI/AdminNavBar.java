package ProjectGUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AdminNavBar {
    private static final Color RED = new Color(204, 41, 34);
    private static final Color WHITE = Color.WHITE;

    // Updated to accept 4 Runnables: onHome, onManageCars, onRentHistory, onLogout
    public static JPanel build(String active, String userName, CardLayout cards, JPanel root,
                                Runnable onHome, Runnable onManageCars, Runnable onRentHistory, Runnable onLogout) {

        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(RED);
        bar.setPreferredSize(new Dimension(0, 62));
        bar.setBorder(BorderFactory.createEmptyBorder(0, 22, 0, 22));

        JLabel brand = new JLabel("DriveDash ADMIN");
        brand.setFont(new Font("SansSerif", Font.BOLD, 22));
        brand.setForeground(WHITE);
        bar.add(brand, BorderLayout.WEST);

        JPanel links = new JPanel(new FlowLayout(FlowLayout.RIGHT, 26, 15));
        links.setOpaque(false);

        // Map labels to the correct Runnables
        links.add(createLink("Home", active.equals("Home"), e -> onHome.run()));
        links.add(createLink("Manage Fleet", active.equals("Manage"), e -> onManageCars.run()));
        links.add(createLink("All History", active.equals("History"), e -> onRentHistory.run()));
        
        JLabel logoutLbl = createLink("Logout ⏻", false, e -> onLogout.run());
        logoutLbl.setForeground(new Color(255, 180, 180));
        links.add(logoutLbl);

        bar.add(links, BorderLayout.CENTER);
        return bar;
    }

    private static JLabel createLink(String text, boolean isActive, ActionListener action) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 16));
        lbl.setForeground(isActive ? new Color(255, 255, 150) : WHITE);
        lbl.setCursor(new Cursor(Cursor.HAND_CURSOR));
        lbl.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) { action.actionPerformed(null); }
        });
        return lbl;
    }
}