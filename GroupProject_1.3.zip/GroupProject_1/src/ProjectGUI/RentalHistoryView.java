package ProjectGUI;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.*;

public class RentalHistoryView extends JPanel {
    private final String username;
    private DefaultTableModel model;
    private final boolean isAdmin;

    public RentalHistoryView(String username) {
        this.isAdmin = username.equals("ADMIN_VIEW");
        this.username = username;

        setLayout(new BorderLayout(0, 20));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        JLabel title = new JLabel(isAdmin ? "Global Rental History" : "My Rental History");
        title.setFont(new Font("SansSerif", Font.BOLD, 28));
        add(title, BorderLayout.NORTH);

        String[] cols = {"ID", "User", "Start Date", "End Date", "Total Price", "Payment"};
        model = new DefaultTableModel(cols, 0);
        JTable table = new JTable(model);
        table.setRowHeight(35);
        
        loadData();
        add(new JScrollPane(table), BorderLayout.CENTER);
    }

    private void loadData() {
        model.setRowCount(0);
        String sql = isAdmin ? "SELECT * FROM rentals" : "SELECT * FROM rentals WHERE username = ?";
        try (Connection conn = DBConnection.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            if (!isAdmin) ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("username"),
                    rs.getDate("start_date"),
                    rs.getDate("end_date"),
                    String.format("₱%,.2f", rs.getDouble("total_price")),
                    rs.getString("payment_method")
                });
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }
}