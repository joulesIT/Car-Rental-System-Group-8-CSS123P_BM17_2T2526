package ProjectGUI;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.*;

public class PaymentMethodView extends JPanel {
    private final UserDashboard dashboard;
    private final Car car;
    private final java.sql.Date start, end;
    private final double total;
    private final String username;

    private final Color ACCENT_RED = new Color(204, 41, 34);
    private final Color SIDEBAR_BG = new Color(30, 30, 30); // Dark theme for Review Order

    public PaymentMethodView(String username, Car car, java.sql.Date start, java.sql.Date end, double total, UserDashboard dashboard) {
        this.username = username;
        this.car = car;
        this.start = start;
        this.end = end;
        this.total = total;
        this.dashboard = dashboard;

        setLayout(new BorderLayout());
        setBackground(new Color(248, 249, 250));

        // SPLIT VIEW: Left for Buttons, Right for Summary
        JPanel mainContent = new JPanel(new GridLayout(1, 2, 0, 0));
        mainContent.setOpaque(false);

        mainContent.add(createPaymentSelectionPanel());
        mainContent.add(createSummaryPanel()); // Restored the sidebar

        add(mainContent, BorderLayout.CENTER);
    }

    private JPanel createPaymentSelectionPanel() {
        JPanel outer = new JPanel(new GridBagLayout());
        outer.setOpaque(false);
        
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);

        JLabel title = new JLabel("Choose Payment");
        title.setFont(new Font("SansSerif", Font.BOLD, 32));
        panel.add(title);
        panel.add(Box.createVerticalStrut(40));

        // Credit Card Option
        panel.add(createOptionButton("Credit / Debit Card", "💳", e -> showCardDialog()));
        panel.add(Box.createVerticalStrut(20));
        
        // Cash Option
        panel.add(createOptionButton("Pay on Arrival", "💵", e -> processDatabaseUpdate("Cash on Arrival")));

        outer.add(panel);
        return outer;
    }

    private JPanel createSummaryPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(SIDEBAR_BG);
        panel.setBorder(new EmptyBorder(60, 60, 60, 60));

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setOpaque(false);

        JLabel sumTitle = new JLabel("Review Order");
        sumTitle.setForeground(Color.WHITE);
        sumTitle.setFont(new Font("SansSerif", Font.BOLD, 26));
        
        content.add(sumTitle);
        content.add(Box.createVerticalStrut(30));
        
        content.add(createSummaryRow("Vehicle:", car.getBrand() + " " + car.getModel()));
        content.add(Box.createVerticalStrut(15));
        content.add(createSummaryRow("Days:", String.valueOf(calculateDays())));
        content.add(Box.createVerticalStrut(40));
        
        content.add(new JSeparator());
        content.add(Box.createVerticalStrut(30));

        JLabel totalLabel = new JLabel("TOTAL DUE");
        totalLabel.setForeground(Color.GRAY);
        totalLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        
        JLabel totalVal = new JLabel(String.format("₱%,.2f", total));
        totalVal.setForeground(ACCENT_RED);
        totalVal.setFont(new Font("SansSerif", Font.BOLD, 42));

        content.add(totalLabel);
        content.add(totalVal);

        panel.add(content, BorderLayout.NORTH);
        return panel;
    }

    private JPanel createSummaryRow(String left, String right) {
        JPanel row = new JPanel(new BorderLayout());
        row.setOpaque(false);
        JLabel l = new JLabel(left);
        l.setForeground(Color.LIGHT_GRAY);
        JLabel r = new JLabel(right);
        r.setForeground(Color.WHITE);
        r.setFont(new Font("SansSerif", Font.BOLD, 14));
        row.add(l, BorderLayout.WEST);
        row.add(r, BorderLayout.EAST);
        return row;
    }

    private void showCardDialog() {
        JPanel panel = new JPanel(new GridLayout(0, 1, 10, 10));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JTextField nameF = new JTextField();
        JTextField cardF = new JTextField();
        JTextField expF = new JTextField("MM/YY");
        JPasswordField cvvF = new JPasswordField();

        panel.add(new JLabel("Cardholder Name:"));
        panel.add(nameF);
        panel.add(new JLabel("Card Number:"));
        panel.add(cardF);
        panel.add(new JLabel("Expiry & CVV:"));
        JPanel row = new JPanel(new GridLayout(1, 2, 5, 0));
        row.add(expF); row.add(cvvF);
        panel.add(row);

        int result = JOptionPane.showConfirmDialog(this, panel, "Enter Card Credentials", 
                     JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String cardNum = cardF.getText().trim();
            if (cardNum.length() < 13) {
                JOptionPane.showMessageDialog(this, "Invalid card number.");
            } else {
                // Masking the card for the database
                String masked = "**** **** **** " + cardNum.substring(cardNum.length() - 4);
                processDatabaseUpdate("Credit Card (" + masked + ")");
            }
        }
    }

    private void processDatabaseUpdate(String method) {
        try (Connection conn = DBConnection.connect()) {
            // Update Rentals Table
            String sql = "INSERT INTO rentals (car_id, username, start_date, end_date, total_price, payment_method) VALUES (?,?,?,?,?,?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, car.getId());
            ps.setString(2, username);
            ps.setDate(3, start);
            ps.setDate(4, end);
            ps.setDouble(5, total);
            ps.setString(6, method);
            ps.executeUpdate();

            // Mark car as unavailable
            PreparedStatement ps2 = conn.prepareStatement("UPDATE cars SET available = 0 WHERE id = ?");
            ps2.setInt(1, car.getId());
            ps2.executeUpdate();

            JOptionPane.showMessageDialog(this, "Booking Successful!");
            dashboard.showBrowseCars();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private long calculateDays() {
        long diff = end.getTime() - start.getTime();
        return Math.max(1, diff / (1000 * 60 * 60 * 24));
    }

    private JButton createOptionButton(String text, String icon, java.awt.event.ActionListener action) {
        JButton btn = new JButton("  " + icon + "    " + text);
        btn.setPreferredSize(new Dimension(450, 80));
        btn.setMaximumSize(new Dimension(450, 80));
        btn.setFont(new Font("SansSerif", Font.BOLD, 17));
        btn.setBackground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(new Color(230, 230, 230)));
        btn.addActionListener(action);
        return btn;
    }
}