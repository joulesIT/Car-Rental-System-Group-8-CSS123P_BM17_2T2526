package ProjectGUI;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.*;
import java.io.File;

public class ManageFleetView extends JPanel {
    private DefaultTableModel model;
    private JTable table;
    private UserDashboard dashboard;

    public ManageFleetView(UserDashboard dashboard) {
        this.dashboard = dashboard;
        setLayout(new BorderLayout(15, 15));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JButton addBtn = new JButton("+ Add New Car");
        addBtn.setBackground(new Color(30, 30, 30));
        addBtn.setForeground(Color.WHITE);
        addBtn.setFont(new Font("SansSerif", Font.BOLD, 14));
        addBtn.addActionListener(e -> addCarDialog());
        add(addBtn, BorderLayout.NORTH);

        String[] columns = {"ID", "Vehicle", "Seats", "Fuel", "Status", "Action"};
        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return col == 5; }
        };

        table = new JTable(model);
        table.setRowHeight(50);
        loadFleetData();

        table.getColumn("Action").setCellRenderer(new FleetActionRenderer());
        table.getColumn("Action").setCellEditor(new FleetActionEditor(this));

        add(new JScrollPane(table), BorderLayout.CENTER);
    }

    public void loadFleetData() {
        model.setRowCount(0);
        try (Connection conn = DBConnection.connect()) {
            // ADD THIS: WHERE is_deleted = 0
            String sql = "SELECT id, brand, model, seats, fuel_type, available FROM cars WHERE is_deleted = 0";
            ResultSet rs = conn.createStatement().executeQuery(sql);
            while (rs.next()) {
                String status = rs.getInt("available") == 1 ? "Available" : "Rented";
                model.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("brand") + " " + rs.getString("model"),
                    rs.getInt("seats"),
                    rs.getString("fuel_type"),
                    status,
                    "Manage"
                });
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }

    private void addCarDialog() {
        JTextField brand = new JTextField(), modelF = new JTextField(), price = new JTextField(), seats = new JTextField();
        JComboBox<String> type = new JComboBox<>(new String[]{"Sedan", "SUV", "Van", "Luxury"});
        JComboBox<String> fuel = new JComboBox<>(new String[]{"Petroleum", "Diesel", "Electric"});
        
        // Photo Selection
        JLabel photoLabel = new JLabel("No file selected");
        JButton uploadBtn = new JButton("Select Photo");
        final File[] selectedFile = {null};
        uploadBtn.addActionListener(e -> {
            JFileChooser fc = new JFileChooser();
            if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                selectedFile[0] = fc.getSelectedFile();
                photoLabel.setText(selectedFile[0].getName());
            }
        });

        JTextArea descArea = new JTextArea(6, 25);
        descArea.setLineWrap(true);
        descArea.setWrapStyleWord(true);
        JScrollPane descScroll = new JScrollPane(descArea);

        Object[] fields = {
            "Brand:", brand, "Model:", modelF, "Seats:", seats, "Fuel:", fuel,
            "Price/Day:", price, "Photo:", uploadBtn, photoLabel, "Description:", descScroll
        };

        if (JOptionPane.showConfirmDialog(this, fields, "Add New Car", 2) == 0) {
            try (Connection conn = DBConnection.connect()) {
                String imgName = FileUploadUtil.saveFile(selectedFile[0]);
                String sql = "INSERT INTO cars (brand, model, type, seats, fuel_type, price_per_day, image_path, description) VALUES (?,?,?,?,?,?,?,?)";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, brand.getText());
                ps.setString(2, modelF.getText());
                ps.setString(3, type.getSelectedItem().toString());
                ps.setInt(4, Integer.parseInt(seats.getText()));
                ps.setString(5, fuel.getSelectedItem().toString());
                ps.setDouble(6, Double.parseDouble(price.getText()));
                ps.setString(7, imgName);
                ps.setString(8, descArea.getText());
                ps.executeUpdate();
                loadFleetData();
                dashboard.loadCarsFromDB();
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage()); }
        }
    }

    public void processReturn(int id) {
        String r = JOptionPane.showInputDialog(this, "Rating (1-5):");
        if (r != null) {
            try (Connection conn = DBConnection.connect()) {
                PreparedStatement ps = conn.prepareStatement("UPDATE cars SET available=1, rating=(rating+?)/2 WHERE id=?");
                ps.setDouble(1, Double.parseDouble(r));
                ps.setInt(2, id);
                ps.executeUpdate();
                loadFleetData(); dashboard.loadCarsFromDB();
            } catch (Exception e) { e.printStackTrace(); }
        }
    }

    public void removeCar(int id) {
        if (JOptionPane.showConfirmDialog(this, "Delete Car ID " + id + "?") == 0) {
            try (Connection conn = DBConnection.connect()) {
                // Change DELETE to UPDATE to hide the car instead of wiping history
                PreparedStatement ps = conn.prepareStatement("UPDATE cars SET is_deleted = 1 WHERE id = ?");
                ps.setInt(1, id); 
                ps.executeUpdate();
                loadFleetData(); 
                dashboard.loadCarsFromDB();
            } catch (SQLException e) { 
                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage()); 
            }
        }
    }
    
}