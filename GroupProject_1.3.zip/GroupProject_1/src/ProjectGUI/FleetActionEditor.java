package ProjectGUI;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.EventObject;

class FleetActionRenderer extends JPanel implements TableCellRenderer {
    public FleetActionRenderer() {
        setLayout(new FlowLayout(FlowLayout.CENTER, 5, 2));
        JButton ret = new JButton("Return");
        JButton del = new JButton("Delete");
        ret.setBackground(new Color(40, 167, 69)); ret.setForeground(Color.WHITE);
        del.setBackground(new Color(204, 41, 34)); del.setForeground(Color.WHITE);
        add(ret); add(del);
    }
    @Override
    public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c) {
        setBackground(s ? t.getSelectionBackground() : t.getBackground());
        return this;
    }
}

class FleetActionEditor extends AbstractCellEditor implements TableCellEditor {
    private final JPanel panel;
    private int currentId;

    public FleetActionEditor(ManageFleetView parent) {
        panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 2));
        JButton ret = new JButton("Return"), del = new JButton("Delete");
        ret.setBackground(new Color(40, 167, 69)); ret.setForeground(Color.WHITE);
        del.setBackground(new Color(204, 41, 34)); del.setForeground(Color.WHITE);

        ret.addActionListener(e -> { stopCellEditing(); parent.processReturn(currentId); });
        del.addActionListener(e -> { stopCellEditing(); parent.removeCar(currentId); });
        panel.add(ret); panel.add(del);
    }

    @Override
    public Component getTableCellEditorComponent(JTable t, Object v, boolean s, int r, int c) {
        currentId = (int) t.getValueAt(r, 0);
        panel.setBackground(t.getSelectionBackground());
        return panel;
    }

    @Override public Object getCellEditorValue() { return ""; }
    @Override public boolean isCellEditable(EventObject e) { return true; }
}