package ProjectGUI;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.InputStream;
import java.sql.*;

public class LandingPage extends JFrame {

    private final CardLayout cardLayout = new CardLayout();
    private final JPanel mainContainer = new JPanel(cardLayout);
    private final Color DASH_RED = new Color(204, 41, 34);
    private final String ADMIN_CODE = "DRIVEDASHadminCODE2026";

    public LandingPage() {
        setTitle("DriveDash Car Rental System by Group 8");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1400, 800);
        mainContainer.add(createLandingFrame(), "LANDING PAGE");
        mainContainer.add(createAuthView(true),  "LOGIN PAGE");
        mainContainer.add(createAuthView(false), "SIGNUP PAGE");
        add(mainContainer);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    // ── Placeholder + Limit Field Factory ────────────────────────────────────────

    private JTextField placeholderField(String placeholder, Dimension size, Font font, int maxChars) {
        JTextField f = new JTextField() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (getText().isEmpty() && !isFocusOwner()) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setColor(Color.GRAY);
                    g2.setFont(getFont());
                    Insets ins = getInsets();
                    g2.drawString(placeholder, ins.left, getHeight() / 2 + getFont().getSize() / 2 - 2);
                    g2.dispose();
                }
            }
        };
        styleField(f, size, font);

        if (maxChars > 0) {
            ((AbstractDocument) f.getDocument()).setDocumentFilter(new DocumentFilter() {
                @Override
                public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
                    if (fb.getDocument().getLength() + string.length() <= maxChars)
                        super.insertString(fb, offset, string, attr);
                }
                @Override
                public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                    if (fb.getDocument().getLength() - length + text.length() <= maxChars)
                        super.replace(fb, offset, length, text, attrs);
                }
            });
        }
        return f;
    }

    private JPasswordField placeholderPassword(String placeholder, Dimension size, Font font) {
        JPasswordField f = new JPasswordField() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (getPassword().length == 0 && !isFocusOwner()) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setColor(Color.GRAY);
                    g2.setFont(getFont());
                    Insets ins = getInsets();
                    g2.drawString(placeholder, ins.left, getHeight() / 2 + getFont().getSize() / 2 - 2);
                    g2.dispose();
                }
            }
        };
        styleField(f, size, font);
        return f;
    }

    // ── Landing Page UI ──────────────────────────────────────────────────────────

    private JPanel createLandingFrame() {
        ImagePanel panel = new ImagePanel("/res/1.png");
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.5;
        gbc.fill = GridBagConstraints.BOTH;
        panel.add(Box.createGlue(), gbc);

        JPanel btnBox = new JPanel(new GridLayout(2, 1, 0, 20));
        btnBox.setOpaque(false);
        Dimension btnSize = new Dimension(250, 70);
        Font btnFont = new Font("SansSerif", Font.BOLD, 22);

        JButton loginBtn = styledButton("Log-In", btnSize, btnFont, DASH_RED, Color.WHITE, true);
        loginBtn.addActionListener(e -> cardLayout.show(mainContainer, "LOGIN PAGE"));

        JButton signupBtn = styledButton("SignUp", btnSize, btnFont, Color.WHITE, null, false);
        signupBtn.addActionListener(e -> cardLayout.show(mainContainer, "SIGNUP PAGE"));

        btnBox.add(loginBtn);
        btnBox.add(signupBtn);

        gbc.gridx = 1; gbc.weightx = 0.5;
        gbc.insets = new Insets(300, 200, 0, 0);
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill   = GridBagConstraints.NONE;
        panel.add(btnBox, gbc);
        return panel;
    }

    private JButton styledButton(String text, Dimension size, Font font, Color fg, Color bg, boolean opaque) {
        JButton btn = new JButton(text);
        btn.setPreferredSize(size); btn.setFont(font);
        btn.setForeground(fg); btn.setFocusPainted(false);
        if (opaque) { btn.setBackground(bg); }
        else { btn.setContentAreaFilled(false); btn.setOpaque(false); btn.setBorder(BorderFactory.createLineBorder(fg, 3)); }
        return btn;
    }

    // ── Auth View ────────────────────────────────────────────────────────────────

    private JPanel createAuthView(boolean isLogin) {
        JPanel split = new JPanel(new GridLayout(1, 2));

        JPanel left = new JPanel(new GridBagLayout());
        left.setBackground(Color.WHITE);
        GridBagConstraints lc = new GridBagConstraints();
        lc.gridx = 0; lc.weightx = 1.0; lc.fill = GridBagConstraints.NONE;

        JButton backBtn = new JButton("← Back");
        backBtn.setFont(new Font("SansSerif", Font.BOLD, 16));
        backBtn.setForeground(DASH_RED);
        backBtn.setContentAreaFilled(false); backBtn.setBorderPainted(false); backBtn.setFocusPainted(false);
        backBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        backBtn.addActionListener(e -> cardLayout.show(mainContainer, "LANDING PAGE"));
        lc.gridy = 0; lc.weighty = 0; lc.anchor = GridBagConstraints.NORTHWEST;
        lc.insets = new Insets(20, 50, 0, 0);
        left.add(backBtn, lc);

        JLabel title = new JLabel(isLogin ? "Log-in" : "Sign-Up");
        title.setFont(new Font("SansSerif", Font.BOLD, 80));
        lc.gridy = 1; lc.weighty = 0.1; lc.anchor = GridBagConstraints.WEST;
        lc.insets = new Insets(10, 50, 0, 0);
        left.add(title, lc);

        JCheckBox check = new JCheckBox(isLogin ? "I am not a robot" : "I agree to the ");
        check.setBackground(Color.WHITE);
        check.setFont(new Font("SansSerif", Font.PLAIN, 20));

        JPanel verRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        verRow.setBackground(Color.WHITE);
        verRow.add(check);
        if (!isLogin) {
            JLabel terms = new JLabel("<html><u>Terms and Conditions</u></html>");
            terms.setForeground(DASH_RED);
            terms.setFont(new Font("SansSerif", Font.PLAIN, 20));
            terms.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            terms.addMouseListener(new MouseAdapter() {
                @Override public void mouseClicked(MouseEvent e) { showTermsPopup(); }
            });
            verRow.add(terms);
        }
        lc.gridy = 2; lc.weighty = 1.0; lc.anchor = GridBagConstraints.SOUTHWEST;
        lc.insets = new Insets(0, 50, 40, 0);
        left.add(verRow, lc);

        JPanel right = new JPanel(new GridBagLayout());
        right.setBackground(DASH_RED);
        GridBagConstraints rc = new GridBagConstraints();
        rc.fill = GridBagConstraints.HORIZONTAL; rc.gridx = 0;

        JLabel header = new JLabel("Enter your Details:");
        header.setForeground(Color.WHITE);
        header.setFont(new Font("SansSerif", Font.BOLD, 24));
        rc.gridy = 0; rc.insets = new Insets(20, 50, 20, 50);
        right.add(header, rc);

        Dimension fSz = new Dimension(400, 50);
        Font fFt = new Font("SansSerif", Font.PLAIN, 18);

        JTextField userF = placeholderField("Username", fSz, fFt, 20);
        rc.gridy = 1; rc.insets = new Insets(10, 50, 10, 50);
        right.add(userF, rc);

        JLabel passLbl = new JLabel("<html><font color='white'>Password:</font></html>");
        passLbl.setFont(new Font("SansSerif", Font.BOLD, 14));
        rc.gridy = 2; right.add(passLbl, rc);

        JPasswordField passF = placeholderPassword("Password", fSz, fFt);
        rc.gridy = 3; right.add(passF, rc);

        // ── MODIFIED: Show Password Toggle ──
        JCheckBox showPass = new JCheckBox("Show Password");
        showPass.setForeground(Color.WHITE);
        showPass.setBackground(DASH_RED);
        showPass.addActionListener(e -> {
            if (showPass.isSelected()) {
                passF.setEchoChar((char) 0); // Show password
            } else {
                passF.setEchoChar('•'); // Hiding the password
            }
        });
        rc.gridy = 4; rc.insets = new Insets(0, 50, 10, 50);
        right.add(showPass, rc);

        Dimension bSz = new Dimension(180, 50);
        Font bFt = new Font("SansSerif", Font.BOLD, 18);

        if (!isLogin) {
            JTextField emailF   = placeholderField("Email",            fSz, fFt, 0);
            JTextField nameF    = placeholderField("Legal Name",       fSz, fFt, 100);
            JTextField licenseF = placeholderField("Driver's License", fSz, fFt, 20);
            JTextField phoneF   = placeholderField("Phone Number",     fSz, fFt, 11);

            ((AbstractDocument) phoneF.getDocument()).setDocumentFilter(new DocumentFilter() {
                @Override
                public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
                    if (string.matches("\\d+") && fb.getDocument().getLength() + string.length() <= 11)
                        super.insertString(fb, offset, string, attr);
                }
                @Override
                public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                    if (text.matches("\\d+") && fb.getDocument().getLength() - length + text.length() <= 11)
                        super.replace(fb, offset, length, text, attrs);
                }
            });

            int signupRow = 5; // Updated starting index due to showPass checkbox
            for (JTextField f : new JTextField[]{emailF, nameF, licenseF, phoneF}) {
                rc.gridy = signupRow++; right.add(f, rc);
            }
            JButton regBtn = new JButton("SIGNUP NOW");
            regBtn.setPreferredSize(bSz); regBtn.setFont(bFt);
            rc.gridy = signupRow; rc.fill = GridBagConstraints.NONE; rc.anchor = GridBagConstraints.EAST;
            right.add(regBtn, rc);
            regBtn.addActionListener(e -> {
                if (!check.isSelected()) JOptionPane.showMessageDialog(this, "Agree to the Terms & Conditions first!");
                else handleSignup(userF.getText(), new String(passF.getPassword()),
                        emailF.getText(), nameF.getText(), licenseF.getText(), phoneF.getText());
            });
        } else {
            JButton logBtn = new JButton("Log-In");
            logBtn.setPreferredSize(bSz); logBtn.setFont(bFt);
            rc.gridy = 5; rc.fill = GridBagConstraints.NONE; rc.anchor = GridBagConstraints.EAST;
            right.add(logBtn, rc);
            logBtn.addActionListener(e -> {
                if (!check.isSelected()) JOptionPane.showMessageDialog(this, "Check 'I am not a robot'");
                else handleLogin(userF.getText(), new String(passF.getPassword()));
            });
        }

        split.add(left); split.add(right);
        return split;
    }

    private void styleField(JTextField f, Dimension size, Font font) {
        f.setPreferredSize(size); f.setFont(font);
        f.setBorder(BorderFactory.createCompoundBorder(
                f.getBorder(), BorderFactory.createEmptyBorder(5, 10, 5, 10)));
    }

    private void showTermsPopup() {
        JTextArea ta = new JTextArea("DRIVEDASH TERMS AND CONDITIONS...");
        ta.setEditable(false); ta.setLineWrap(true);
        JScrollPane sp = new JScrollPane(ta);
        sp.setPreferredSize(new Dimension(400, 300));
        JOptionPane.showMessageDialog(this, sp, "Terms & Conditions", JOptionPane.INFORMATION_MESSAGE);
    }

    // ── Fixed Database Logic ─────────────────────────────────────────────────────

    private void handleLogin(String user, String pass) {
        try (Connection conn = DBConnection.connect()) {
            // ── MODIFIED: Added BINARY for exact case-sensitive comparison ──
            String sql = "SELECT USERNAME, role FROM users WHERE USERNAME = ? AND BINARY password = ?"; 
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, user);
            ps.setString(2, pass);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String loggedUser = rs.getString("USERNAME");
                String loggedRole = rs.getString("role");

                this.dispose(); 
                SwingUtilities.invokeLater(() -> new UserDashboard(loggedUser, loggedRole).setVisible(true));
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials! (Check case-sensitivity)");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
        }
    }

    private void handleSignup(String u, String p, String email, String name, String lic, String ph) {
        int res = JOptionPane.showConfirmDialog(this, "Register as Admin?", "Role", JOptionPane.YES_NO_OPTION);
        String role = "USER";
        String empId = null;

        if (res == JOptionPane.YES_OPTION) {
            String code = JOptionPane.showInputDialog(this, "Enter Admin Code:");
            if (code != null && ADMIN_CODE.equals(code)) {
                role = "ADMIN";
                empId = JOptionPane.showInputDialog(this, "Enter Employee ID:");
            } else if (code != null) {
                JOptionPane.showMessageDialog(this, "Wrong Admin Code. Registering as regular User.");
            }
        }

        try (Connection conn = DBConnection.connect();
             PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO users (USERNAME,EMAIL,password,legal_name,drivers_license,phone_number,role,EMPLOYEE_ID) VALUES (?,?,?,?,?,?,?,?)")) {
            ps.setString(1, u); ps.setString(2, email); ps.setString(3, p);
            ps.setString(4, name); ps.setString(5, lic); ps.setString(6, ph);
            ps.setString(7, role); ps.setString(8, empId);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Account created successfully!");
            cardLayout.show(mainContainer, "LOGIN PAGE");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Signup failed: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    class ImagePanel extends JPanel {
        private BufferedImage img;
        public ImagePanel(String path) {
            try {
                InputStream is = LandingPage.class.getResourceAsStream(path);
                if (is == null) is = LandingPage.class.getClassLoader().getResourceAsStream(path.replaceFirst("^/", ""));
                if (is != null) img = ImageIO.read(is);
            } catch (Exception e) { e.printStackTrace(); }
        }
        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (img != null) g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
        }
    }

    public static void main(String[] args) { SwingUtilities.invokeLater(LandingPage::new); }
}