package ProjectGUI;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class CarDetailsView extends JPanel {
    private final UserDashboard parent;
    private final Car car;

    public CarDetailsView(Car car, UserDashboard parent) {
        this.car = car;
        this.parent = parent;
        
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // --- TOP NAVIGATION ---
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.setBackground(Color.WHITE);
        top.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 0)); // Added padding for the back button
        
        JButton back = new JButton("← BACK TO FLEET");
        back.setFocusPainted(false);
        back.addActionListener(e -> parent.showBrowseCars());
        top.add(back);
        add(top, BorderLayout.NORTH);

        // --- CONTENT PANEL ---
        // 1 row, 2 columns for a balanced split
        JPanel content = new JPanel(new GridLayout(1, 2, 50, 0));
        content.setBackground(Color.WHITE);
        content.setBorder(BorderFactory.createEmptyBorder(40, 80, 40, 80));

        // --- LEFT SIDE: Large Car Image ---
        JLabel imgLabel = new JLabel("", JLabel.CENTER);
        try {
            // Updated path logic to ensure case-sensitivity matches your resource folder
            URL imgURL = CarDetailsView.class.getResource("/ProjectGUI/IMAGES/" + car.getImagePath());
            if (imgURL != null) {
                ImageIcon icon = new ImageIcon(imgURL);
                // Scaled specifically to balance the right-side text
                Image img = icon.getImage().getScaledInstance(550, 400, Image.SCALE_SMOOTH);
                imgLabel.setIcon(new ImageIcon(img));
            } else {
                imgLabel.setText("<html><i style='color:gray;'>Image Not Found</i></html>");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        content.add(imgLabel);

        // --- RIGHT SIDE: Information ---
        JPanel info = new JPanel();
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
        info.setBackground(Color.WHITE);

        // Brand and Model
        JLabel name = new JLabel(car.getBrand() + " " + car.getModel());
        name.setFont(new Font("SansSerif", Font.BOLD, 42));
        name.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Price
        JLabel price = new JLabel(String.format("₱%,.2f / Day", car.getPricePerDay()));
        price.setFont(new Font("SansSerif", Font.BOLD, 28));
        price.setForeground(new Color(204, 41, 34));
        price.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Description - REMOVED THE BOX
        JTextArea desc = new JTextArea(car.getDescription());
        desc.setLineWrap(true);
        desc.setWrapStyleWord(true);
        desc.setEditable(false);
        desc.setFocusable(false);
        desc.setOpaque(false); // Makes the background disappear
        desc.setBorder(null);   // Explicitly removes any remaining border
        desc.setFont(new Font("SansSerif", Font.PLAIN, 18));
        desc.setForeground(new Color(60, 60, 60));
        desc.setAlignmentX(Component.LEFT_ALIGNMENT);
        desc.setMaximumSize(new Dimension(500, 300));

        // Rent Button
        JButton rentBtn = new JButton("RENT THIS VEHICLE");
        rentBtn.setBackground(new Color(204, 41, 34));
        rentBtn.setForeground(Color.WHITE);
        rentBtn.setFont(new Font("SansSerif", Font.BOLD, 18));
        rentBtn.setFocusPainted(false);
        rentBtn.setBorderPainted(false);
        rentBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        rentBtn.setMaximumSize(new Dimension(300, 55));
        rentBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        rentBtn.addActionListener(e -> parent.showBooking(car));

        // Assembly
        info.add(Box.createVerticalGlue()); // Keeps content centered vertically
        info.add(name);
        info.add(Box.createVerticalStrut(10));
        info.add(price);
        info.add(Box.createVerticalStrut(30));
        info.add(desc); // Added directly without JScrollPane to remove the box
        info.add(Box.createVerticalStrut(40));
        info.add(rentBtn);
        info.add(Box.createVerticalGlue());

        content.add(info);
        add(content, BorderLayout.CENTER);
    }
}