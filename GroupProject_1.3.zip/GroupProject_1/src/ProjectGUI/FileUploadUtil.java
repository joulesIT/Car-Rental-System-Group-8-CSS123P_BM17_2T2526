package ProjectGUI;

import java.io.*;
import java.nio.file.*;
import java.util.UUID;

public class FileUploadUtil {
    // This creates a folder named 'car_images' in your main project directory
    public static final String SAVE_DIR = "car_images/";

    public static String saveFile(File sourceFile) throws IOException {
        if (sourceFile == null) return "default_car.png";

        File directory = new File(SAVE_DIR);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        String originalName = sourceFile.getName();
        String fileExtension = originalName.substring(originalName.lastIndexOf("."));
        String uniqueName = UUID.randomUUID().toString() + fileExtension;

        Path targetPath = Paths.get(SAVE_DIR + uniqueName);
        Files.copy(sourceFile.toPath(), targetPath, StandardCopyOption.REPLACE_EXISTING);

        return uniqueName;
    }
}