package ProjectGUI;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class CarCard {
    private static final Color BOX_BG = new Color(30, 30, 30); 
    private static final Color TEXT_GRAY = new Color(180, 180, 180);
    private static final Color ACCENT_RED = new Color(204, 41, 34);

    public static JPanel build(Car car, int w, int h, String userName, UserDashboard dashboard) {
        // Fixed dimensions for grid consistency
        int cardW = 300;
        int cardH = 420;

        JPanel card = new JPanel(null) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BOX_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 35, 35);
                g2.dispose();
            }
        };
        
        // Critical for GridLayout behavior
        card.setPreferredSize(new Dimension(cardW, cardH));
        card.setMinimumSize(new Dimension(cardW, cardH));
        card.setOpaque(false);

        // 1. Image Holder
        JLabel imgLabel = new JLabel("", JLabel.CENTER);
        imgLabel.setBounds(15, 15, cardW - 30, 200);
        try {
            // Updated path logic to ensure case sensitivity matches your folder
            URL imgURL = CarCard.class.getResource("/ProjectGUI/IMAGES/" + car.getImagePath());
            if (imgURL != null) {
                ImageIcon icon = new ImageIcon(imgURL);
                Image img = icon.getImage().getScaledInstance(cardW - 30, 200, Image.SCALE_SMOOTH);
                imgLabel.setIcon(new ImageIcon(img));
            } else {
                imgLabel.setText("<html><font color='gray'>Image Not Found</font></html>");
            }
        } catch (Exception e) { e.printStackTrace(); }
        card.add(imgLabel);

        // 2. Car Brand & Model
        JLabel name = new JLabel(car.getBrand().toUpperCase() + " " + car.getModel());
        name.setFont(new Font("SansSerif", Font.BOLD, 19));
        name.setForeground(Color.WHITE);
        name.setBounds(25, 230, cardW - 50, 30);
        card.add(name);

        // 3. Price Label
        JLabel price = new JLabel(String.format("₱%,.2f / day", car.getPricePerDay()));
        price.setFont(new Font("SansSerif", Font.PLAIN, 16));
        price.setForeground(TEXT_GRAY);
        price.setBounds(25, 260, cardW - 50, 25);
        card.add(price);

        // 4. Status Indicator
        JLabel status = new JLabel(car.isAvailable() ? "● Available" : "● Currently Rented");
        status.setForeground(car.isAvailable() ? new Color(100, 255, 100) : new Color(255, 150, 0));
        status.setFont(new Font("SansSerif", Font.BOLD, 13));
        status.setBounds(25, 290, cardW - 50, 20);
        card.add(status);

        // 5. Action Button
        JButton viewBtn = new JButton(car.isAvailable() ? "VIEW DETAILS" : "UNAVAILABLE");
        viewBtn.setBounds(25, 340, cardW - 50, 50);
        viewBtn.setFont(new Font("SansSerif", Font.BOLD, 14));
        viewBtn.setFocusPainted(false);
        viewBtn.setBorderPainted(false);

        if (car.isAvailable()) {
            viewBtn.setBackground(ACCENT_RED);
            viewBtn.setForeground(Color.WHITE);
            viewBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            viewBtn.addActionListener(e -> dashboard.showCarDetails(car));
        } else {
            viewBtn.setBackground(new Color(60, 60, 60));
            viewBtn.setForeground(Color.GRAY);
            viewBtn.setEnabled(false);
        }
        card.add(viewBtn);

        return card;
    }
}