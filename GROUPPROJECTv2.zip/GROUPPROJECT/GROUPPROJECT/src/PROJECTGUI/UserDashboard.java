//package declaration
package PROJECTGUI;

//swing imports for GUI components
import javax.swing.*;
import javax.swing.border.*;
//awt imports for graphics, layout, and events
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
//io, sql, and util imports
import java.io.InputStream;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;

//main class for the user-facing dashboard, extends JFrame to create a window
public class UserDashboard extends JFrame {

    //brand color constants used throughout the UI
    private static final Color RED      = new Color(204, 41,  34); //primary brand red
    private static final Color DARK_RED = new Color(160, 28,  22); //darker red for hover/remove states
    private static final Color CARD_BG  = new Color(195, 207, 215); //light blue-grey background for car cards
    private static final Color SIDEBAR  = new Color(210, 221, 229); //slightly lighter grey for the sidebar panel
    private static final Color WHITE    = Color.WHITE;
    private static final Color DARK_TXT = new Color(30,  30,  30); //near-black used for dark body text

    //stores the logged-in username displayed on the dashboard header and used in database queries
    final String userName;
    //stores the user's role ("ADMIN" or "USER") to control which features are visible
    private final String userRole;

    //cardLayout allows switching between Home, Browse, Car Detail, and Booking pages in the same window
    final CardLayout cards = new CardLayout();
    //root panel holds all pages managed by cardLayout
    final JPanel root = new JPanel(cards);

    //live list of cars loaded from the database; updated whenever cars are added or removed
    private final List<Car> CARS = new ArrayList<>();

    //references to the page panels so they can be removed and rebuilt after car-list changes
    private JPanel homePageRef;
    private JPanel browsePageRef;

    //inner class representing a single car entry with all fields pulled from the database
    static final class Car {
        final int    id;         //primary key from the cars table, used when inserting bookings
        final String brand;      //car manufacturer name, e.g. "Toyota"
        final String model;      //car model name, e.g. "Veloz"
        final String imagePath;  //filename of the car photo stored in the /car_images/ resource folder
        final double rating;     //average user rating displayed on the card badge

        //constructor assigns all fields at once
        Car(int id, String b, String m, double r, String imgPath) {
            this.id = id; brand = b; model = m; rating = r; imagePath = imgPath;
        }
    }

    //IMAGE CACHE - loads a car photo from the classpath resource folder /car_images/<filename>
    //returns null if the file does not exist so callers can fall back to the vector silhouette
    private static BufferedImage loadCarImage(String imagePath) {
        if (imagePath == null || imagePath.isBlank()) return null; //no path means no image to load
        try {
            String res = "/car_images/" + imagePath; //build the full classpath resource path
            InputStream is = UserDashboard.class.getResourceAsStream(res); //locate the image file
            return (is != null) ? ImageIO.read(is) : null; //decode and return, or null if not found
        } catch (Exception e) {
            return null; //return null on any IO or decode error so the silhouette fallback is used
        }
    }

    //constructor sets up the JFrame window, loads cars from the database, and adds both pages
    public UserDashboard(String userName, String userRole) {
        this.userName = userName; //save the username for labels and database queries
        this.userRole = (userRole == null) ? "USER" : userRole.toUpperCase(); //normalize role to uppercase

        setTitle("DriveDash \u2014 " + userName); //window title shows the logged-in user's name
        setDefaultCloseOperation(EXIT_ON_CLOSE); //close the app when the window is closed
        setSize(1400, 800); //initial window size in pixels
        setMinimumSize(new Dimension(1050, 650)); //prevent the window from becoming too small to use
        setLocationRelativeTo(null); //center the window on the screen

        loadCarsFromDB(); //fetch all available cars from the database into the CARS list

        //build both pages and add them to the card layout with string keys
        homePageRef   = buildHomePage();
        browsePageRef = buildBrowsePage();

        root.add(homePageRef,   "HOME");   //home page shown on login
        root.add(browsePageRef, "BROWSE"); //browse page shows all available cars

        add(root); //attach the root card panel to the JFrame
        cards.show(root, "HOME"); //show the Home page first when the dashboard opens
        setVisible(true); //make the window visible
    }

    //DATABASE CONNECTION - creates a JDBC connection to the local MySQL car_rental database
    private Connection connect() throws SQLException {
        return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/car_rental2", "root", "myPASSsql@54321");
    }

    //LOAD CARS FROM DATABASE - clears and repopulates the CARS list from the cars table
    private void loadCarsFromDB() {
        CARS.clear(); //remove any previously loaded cars before fetching fresh data
        try (Connection conn = connect();
             Statement  st   = conn.createStatement();
             //only load cars marked as available, sorted by ID for consistent display order
             ResultSet  rs   = st.executeQuery(
                     "SELECT id,brand,model,rating,image_path FROM cars WHERE available=TRUE ORDER BY id")) {
            while (rs.next()) {
                //create a Car object from each database row and add it to the list
                CARS.add(new Car(
                        rs.getInt("id"),
                        rs.getString("brand"),
                        rs.getString("model"),
                        rs.getDouble("rating"),
                        rs.getString("image_path")));
            }
        } catch (SQLException ex) {
            ex.printStackTrace(); //print any database errors to the console
            JOptionPane.showMessageDialog(this, "Could not load cars: " + ex.getMessage(),
                    "DB Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    //FETCH LAST BOOKING - queries the bookings table for the most recent booking by this user
    //returns a String array {brand, model, start_date, end_date, image_path} or null if none found
    private String[] fetchLastBooking() {
        //join bookings with cars to get the car details alongside the booking dates
        String sql = "SELECT c.brand, c.model, b.start_date, b.end_date, c.image_path " +
                     "FROM bookings b JOIN cars c ON b.car_id = c.id " +
                     "WHERE b.username = ? ORDER BY b.booked_at DESC LIMIT 1"; //most recent booking only
        try (Connection conn = connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, userName); //filter bookings by the logged-in user
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                //return the five fields needed to populate the sidebar
                return new String[]{
                        rs.getString("brand"),
                        rs.getString("model"),
                        rs.getString("start_date"),
                        rs.getString("end_date"),
                        rs.getString("image_path")
                };
            }
        } catch (SQLException ex) { ex.printStackTrace(); }
        return null; //no booking found for this user
    }

    //INSERT BOOKING - writes a confirmed booking record into the bookings table
    private void insertBooking(int carId, String startDate, String endDate) throws SQLException {
        String sql = "INSERT INTO bookings (username, car_id, start_date, end_date) VALUES (?,?,?,?)";
        try (Connection conn = connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, userName);  //associate the booking with the logged-in user
            ps.setInt   (2, carId);     //the ID of the car being booked
            ps.setString(3, startDate); //rental start date in YYYY-MM-DD format
            ps.setString(4, endDate);   //rental end date in YYYY-MM-DD format
            ps.executeUpdate(); //execute the insert statement
        }
    }

    //ADD CAR TO DATABASE - inserts a new car record into the cars table (admin only)
    private void dbAddCar(String brand, String model, double rating, String imagePath) throws SQLException {
        String sql = "INSERT INTO cars (brand,model,rating,image_path,available) VALUES (?,?,?,?,TRUE)";
        try (Connection conn = connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, brand);     //manufacturer name
            ps.setString(2, model);     //model name
            ps.setDouble(3, rating);    //initial rating value
            ps.setString(4, imagePath); //image filename in the car_images folder
            ps.executeUpdate();
        }
    }

    //REMOVE CAR FROM DATABASE - soft-deletes a car by setting available=FALSE (admin only)
    //soft delete preserves the record for historical booking references
    private void dbRemoveCar(int carId) throws SQLException {
        String sql = "UPDATE cars SET available=FALSE WHERE id=?";
        try (Connection conn = connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, carId); //identify the car to deactivate by its primary key
            ps.executeUpdate();
        }
    }

    //REBUILD PAGES - removes and recreates both page panels after the car list has changed
    //called after admin adds or removes a car so the grids reflect the updated database state
    void rebuildPages() {
        root.remove(homePageRef);   //remove the old home page from the card layout
        root.remove(browsePageRef); //remove the old browse page from the card layout
        homePageRef   = buildHomePage();   //build a fresh home page with updated car data
        browsePageRef = buildBrowsePage(); //build a fresh browse page with updated car data
        root.add(homePageRef,   "HOME");   //re-add the rebuilt home page under the same key
        root.add(browsePageRef, "BROWSE"); //re-add the rebuilt browse page under the same key
        root.revalidate(); //trigger Swing to recalculate the layout
        root.repaint();    //redraw the panel with the new content
        cards.show(root, "HOME"); //navigate back to the home page after rebuilding
    }

    //NAVIGATION BAR - builds and returns the red top bar used on every page
    //active parameter highlights the currently selected nav link
    private JPanel buildNav(String active) {
        //main nav bar container uses BorderLayout so logo sits left and links sit right
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(RED); //brand red background
        bar.setPreferredSize(new Dimension(0, 62)); //fixed height for the nav bar
        bar.setBorder(new EmptyBorder(0, 22, 0, 22)); //horizontal padding inside the bar

        //LOGO SECTION - checkered flag icon followed by the DriveDash brand name
        JPanel logo = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        logo.setOpaque(false); //transparent so the red nav bar shows through

        //checkered flag icon drawn manually using a 4x4 grid of alternating black and white squares
        JComponent flag = new JComponent() {
            { setPreferredSize(new Dimension(30, 30)); } //fixed size for the flag icon
            @Override protected void paintComponent(Graphics g) {
                int s = 6; //size of each square in the checkered pattern
                //loop through 4 rows and 4 columns to draw the alternating pattern
                for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) {
                    g.setColor((r + c) % 2 == 0 ? WHITE : new Color(50, 50, 50)); //alternate white/dark
                    g.fillRect(c * s + 1, r * s + 3, s, s); //draw each square at the calculated position
                }
            }
        };

        //brand name label displayed next to the flag icon
        JLabel brand = new JLabel("DriveDash");
        brand.setFont(new Font("SansSerif", Font.BOLD, 27));
        brand.setForeground(WHITE); //white text on red background
        logo.add(flag);  //add the flag icon first
        logo.add(brand); //then add the brand name next to it

        //wrap the logo in GridBagLayout so it centers vertically within the 62px nav height
        JPanel logoWrap = new JPanel(new GridBagLayout());
        logoWrap.setOpaque(false);
        logoWrap.add(logo);
        bar.add(logoWrap, BorderLayout.WEST); //pin logo to the left side of the nav bar

        //NAVIGATION LINKS - list of page labels that switch between cards when clicked
        JPanel links = new JPanel(new FlowLayout(FlowLayout.RIGHT, 26, 0));
        links.setOpaque(false);

        //labels for each navigation link shown in the nav bar
        String[] labels = {"Home", "Browse Cars", "Rent History", "Bookings"};
        //card keys that each label navigates to when clicked
        String[] ids    = {"HOME", "BROWSE", "HOME", "HOME"};

        //loop through each label and create a clickable JLabel with hover and click behavior
        for (int i = 0; i < labels.length; i++) {
            final String dest = ids[i]; //capture destination key for use in the listener closure
            JLabel lbl = new JLabel(labels[i]);
            //check if this label matches the currently active page to apply the highlight style
            boolean isActive = labels[i].equalsIgnoreCase(active)
                    || (labels[i].equals("Browse Cars") && active.equals("BROWSE"));
            lbl.setFont(new Font("SansSerif", Font.BOLD, 17));
            //active link uses a light pinkish-white, inactive links use plain white
            lbl.setForeground(isActive ? new Color(255, 215, 215) : WHITE);
            lbl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); //hand cursor indicates clickable
            lbl.addMouseListener(new MouseAdapter() {
                @Override public void mouseClicked(MouseEvent e)  { cards.show(root, dest); } //navigate to page
                @Override public void mouseEntered(MouseEvent e)  { lbl.setForeground(new Color(255, 200, 200)); } //lighten on hover
                @Override public void mouseExited(MouseEvent e)   { lbl.setForeground(WHITE); } //restore white on exit
            });
            links.add(lbl);
        }

        //ADMIN-ONLY MANAGE CARS BUTTON - only visible when the logged-in user has the ADMIN role
        if ("ADMIN".equals(userRole)) {
            JLabel adminBtn = new JLabel("\u2699 Manage Cars");
            adminBtn.setFont(new Font("SansSerif", Font.BOLD, 15));
            adminBtn.setForeground(new Color(255, 240, 160)); //soft yellow to distinguish admin controls
            adminBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            adminBtn.addMouseListener(new MouseAdapter() {
                @Override public void mouseClicked(MouseEvent e)  { showCarManagementDialog(); } //open admin dialog
                @Override public void mouseEntered(MouseEvent e)  { adminBtn.setForeground(Color.YELLOW); } //brighter on hover
                @Override public void mouseExited(MouseEvent e)   { adminBtn.setForeground(new Color(255, 240, 160)); } //restore on exit
            });
            links.add(adminBtn);
        }

        //PROFILE ICON - circle drawn with a person emoji, shows username on hover as a tooltip
        JLabel icon = new JLabel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255, 255, 255, 50)); //semi-transparent white circle background
                g2.fillOval(0, 0, getWidth() - 1, getHeight() - 1);
                g2.setColor(WHITE);
                g2.setFont(new Font("SansSerif", Font.PLAIN, 22));
                FontMetrics fm = g2.getFontMetrics();
                String s = "\uD83D\uDC64"; //person silhouette emoji character
                g2.drawString(s, (getWidth() - fm.stringWidth(s)) / 2, //center horizontally
                        (getHeight() + fm.getAscent() - fm.getDescent()) / 2); //center vertically
                g2.dispose();
            }
        };
        icon.setPreferredSize(new Dimension(36, 36)); //fixed circle size
        icon.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        icon.setToolTipText("Logged in as: " + userName + " (" + userRole + ")"); //tooltip on hover

        links.add(icon); //add the profile icon at the end of the link row

        //wrap links in GridBagLayout so they center vertically within the nav bar height
        JPanel linksWrap = new JPanel(new GridBagLayout());
        linksWrap.setOpaque(false);
        linksWrap.add(links);
        bar.add(linksWrap, BorderLayout.EAST); //pin links to the right side of the nav bar
        return bar;
    }

    //HOME PAGE - builds the main dashboard view with a last-rented sidebar and featured car grid
    private JPanel buildHomePage() {
        //main page container with BorderLayout to attach nav, body, and footer strip
        JPanel page = new JPanel(new BorderLayout());
        page.setBackground(WHITE);
        page.add(buildNav("Home"), BorderLayout.NORTH); //attach nav bar at the top

        //SIDEBAR - shows the most recently rented car with image and booking dates
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS)); //stack elements vertically
        sidebar.setBackground(SIDEBAR);
        sidebar.setPreferredSize(new Dimension(290, 0)); //fixed sidebar width, height fills the panel
        sidebar.setBorder(new EmptyBorder(22, 18, 22, 18)); //inner padding

        //sidebar section title label
        JLabel prevTitle = new JLabel("Last Car Rented");
        prevTitle.setFont(new Font("SansSerif", Font.BOLD, 15));
        prevTitle.setForeground(RED); //red to match brand color
        prevTitle.setAlignmentX(LEFT_ALIGNMENT);
        sidebar.add(prevTitle);
        sidebar.add(Box.createVerticalStrut(14)); //spacing below the title

        //QUERY LAST BOOKING - fetch the most recent booking record from the database for this user
        String[] last = fetchLastBooking(); //returns {brand, model, start_date, end_date, image_path} or null

        if (last != null) {
            //unpack the returned booking data into named local variables
            String brand     = last[0]; //car manufacturer name
            String model     = last[1]; //car model name
            String startDate = last[2]; //booking start date string
            String endDate   = last[3]; //booking end date string
            String imgPath   = last[4]; //car image filename

            //CAR IMAGE OR SILHOUETTE - shows the real photo if available, else draws the vector shape
            JPanel imgPanel = buildCarImagePanel(imgPath, findCar(brand, model), 120, 78);
            imgPanel.setAlignmentX(LEFT_ALIGNMENT);
            imgPanel.setMaximumSize(new Dimension(254, 78)); //constrain the image panel size
            sidebar.add(imgPanel);
            sidebar.add(Box.createVerticalStrut(8)); //spacing between image and name

            //CAR NAME - brand in red italic and model in dark bold using HTML formatting
            JLabel carName = makeCarNameLabel(brand, model, 16);
            carName.setAlignmentX(LEFT_ALIGNMENT);
            sidebar.add(carName);
            sidebar.add(Box.createVerticalStrut(6));

            //BOOKING DATE RANGE - shows the start and end dates with an arrow separator
            JLabel dateLbl = new JLabel("<html><span style='color:rgb(60,60,60);font-size:12pt;'>"
                    + startDate + " \u2192 " + endDate + "</span></html>"); //→ arrow character
            dateLbl.setFont(new Font("SansSerif", Font.PLAIN, 12));
            dateLbl.setAlignmentX(LEFT_ALIGNMENT);
            sidebar.add(dateLbl);
            sidebar.add(Box.createVerticalStrut(4));

            //DAYS AGO - calculates and shows how long ago the rental started relative to today
            try {
                LocalDate bookedOn = LocalDate.parse(startDate); //parse the date string to LocalDate
                long daysAgo = ChronoUnit.DAYS.between(bookedOn, LocalDate.now()); //difference in days
                //format the elapsed time into a human-readable string
                String ago = (daysAgo == 0) ? "Today" : (daysAgo == 1) ? "Yesterday" : daysAgo + " days ago";
                JLabel agoLbl = new JLabel(ago);
                agoLbl.setFont(new Font("SansSerif", Font.ITALIC, 12));
                agoLbl.setForeground(new Color(120, 120, 120)); //grey for secondary info
                agoLbl.setAlignmentX(LEFT_ALIGNMENT);
                sidebar.add(agoLbl);
            } catch (DateTimeParseException ignored) {} //skip the ago label if the date is malformed

        } else {
            //NO RENTAL HISTORY - show a friendly placeholder when the user has no bookings yet
            JLabel noRent = new JLabel("<html><i>No rentals yet.<br>Book your first car!</i></html>");
            noRent.setFont(new Font("SansSerif", Font.PLAIN, 14));
            noRent.setForeground(new Color(100, 100, 100)); //grey to indicate secondary/empty state
            noRent.setAlignmentX(LEFT_ALIGNMENT);
            sidebar.add(noRent);
        }

        sidebar.add(Box.createVerticalGlue()); //push the history link to the bottom of the sidebar

        //VIEW ALL RENT HISTORY LINK - clickable label that opens the full booking history dialog
        JLabel histLink = new JLabel("<html><u>View all Rent History</u></html>");
        histLink.setFont(new Font("SansSerif", Font.PLAIN, 14));
        histLink.setForeground(RED); //red underline link style
        histLink.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        histLink.setAlignmentX(LEFT_ALIGNMENT);
        histLink.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { showRentHistory(); } //open history dialog
        });
        sidebar.add(histLink);

        //MAIN CONTENT AREA - welcome header and the featured car grid
        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(WHITE);

        //WELCOME HEADER - greeting label with the user's name styled in HTML
        JPanel header = new JPanel(new FlowLayout(FlowLayout.LEFT, 38, 20));
        header.setBackground(WHITE);
        JLabel welcome = new JLabel();
        welcome.setText("<html>"
                + "<span style='color:rgb(204,41,34);font-size:40pt;'><i><b>Welcome Back, </b></i></span>"
                + "<span style='color:rgb(25,25,25);font-size:40pt;'><i><b>" + userName + "!</b></i></span>"
                + "</html>");
        header.add(welcome);
        main.add(header, BorderLayout.NORTH); //pin the welcome header to the top of the main area

        //FEATURED CAR GRID - shows up to 6 cars starting from index 1 (skips the "previous" car at 0)
        int[] featuredIdx = buildFeaturedIndices(6);
        JPanel grid = buildCarGrid(featuredIdx, 3, 210, 185); //3 columns, each card 210x185 pixels
        JScrollPane scroll = new JScrollPane(grid);
        scroll.setBorder(null); //remove the default scroll pane border
        scroll.getVerticalScrollBar().setUnitIncrement(12); //smooth scrolling speed
        main.add(scroll, BorderLayout.CENTER); //fill the center of main with the scrollable grid

        //BODY - combines the sidebar on the left and the main content on the right
        JPanel body = new JPanel(new BorderLayout());
        body.add(sidebar, BorderLayout.WEST);
        body.add(main,    BorderLayout.CENTER);
        page.add(body, BorderLayout.CENTER); //attach the body to the center of the page

        //RED FOOTER STRIP - thin decorative bar at the bottom of the page
        JPanel strip = new JPanel();
        strip.setBackground(RED);
        strip.setPreferredSize(new Dimension(0, 6)); //6px tall accent strip
        page.add(strip, BorderLayout.SOUTH);
        return page;
    }

    //BUILD FEATURED INDICES - creates an index array of up to count cars starting from index 1
    //skips index 0 so the first car (reserved for the sidebar) is not shown in the featured grid
    private int[] buildFeaturedIndices(int count) {
        int start = Math.min(1, CARS.size()); //start at 1 if there is more than one car
        int end   = Math.min(start + count, CARS.size()); //don't exceed the list size
        int[] idx = new int[end - start];
        for (int i = 0; i < idx.length; i++) idx[i] = start + i; //fill sequentially from start
        return idx;
    }

    //FIND CAR - searches the CARS list for a car matching the given brand and model names
    //returns the matched Car object or null if not found
    private Car findCar(String brand, String model) {
        for (Car c : CARS) if (c.brand.equals(brand) && c.model.equals(model)) return c;
        return null; //return null if no car matches the given brand and model
    }

    //BROWSE PAGE - full grid of all available cars displayed in a 4-column layout
    private JPanel buildBrowsePage() {
        JPanel page = new JPanel(new BorderLayout());
        page.setBackground(WHITE);
        page.add(buildNav("BROWSE"), BorderLayout.NORTH); //nav bar with Browse Cars highlighted as active

        //index array covering all cars in the list
        int[] allIdx = new int[CARS.size()];
        for (int i = 0; i < CARS.size(); i++) allIdx[i] = i;

        //4-column grid with larger card dimensions for the browse view
        JPanel grid = buildCarGrid(allIdx, 4, 255, 225);
        JScrollPane scroll = new JScrollPane(grid);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(14); //smooth scroll speed
        page.add(scroll, BorderLayout.CENTER);

        //RED FOOTER STRIP
        JPanel strip = new JPanel();
        strip.setBackground(RED);
        strip.setPreferredSize(new Dimension(0, 6));
        page.add(strip, BorderLayout.SOUTH);
        return page;
    }

    //BUILD CAR GRID - arranges car cards into rows with a fixed number of columns
    //indices array controls which cars from CARS are included and in what order
    private JPanel buildCarGrid(int[] indices, int cols, int cardW, int cardH) {
        //container stacks rows of cards vertically
        JPanel container = new JPanel();
        container.setBackground(WHITE);
        container.setBorder(new EmptyBorder(10, 24, 20, 24)); //padding around the whole grid
        container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));

        JPanel row = null; //current row being filled with car cards
        for (int i = 0; i < indices.length; i++) {
            if (i % cols == 0) {
                //start a new row every time the column limit is reached
                row = new JPanel(new FlowLayout(FlowLayout.CENTER, 18, 14)); //18px horizontal, 14px vertical gaps
                row.setOpaque(false);
                container.add(row);
            }
            //add the car card for the current index if it is within the valid list bounds
            if (indices[i] < CARS.size()) {
                row.add(buildCarCard(CARS.get(indices[i]), cardW, cardH));
            }
        }
        return container;
    }

    //BUILD CAR CARD - creates a single rounded card panel with rating badge, image, and name label
    private JPanel buildCarCard(Car car, int w, int h) {

        //card panel uses null layout for absolute positioning of child components
        //paintComponent draws a rounded rectangle background in the card color
        JPanel card = new JPanel(null) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG); //light blue-grey card background
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14); //rounded corners radius 14
                g2.dispose();
            }
        };
        card.setOpaque(false); //transparent outside the rounded rect so it looks clean
        card.setPreferredSize(new Dimension(w, h)); //fixed card dimensions
        card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); //hand cursor shows the card is clickable

        //RATING BADGE - red pill in the top-left corner showing the star icon and rating value
        JPanel badge = new JPanel(new FlowLayout(FlowLayout.CENTER, 3, 1)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(RED); //red pill background
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 7, 7); //small rounded corners
                g2.dispose();
            }
        };
        badge.setOpaque(false);
        //star character followed by the numeric rating value
        JLabel ratingLbl = new JLabel("\u2605 " + car.rating);
        ratingLbl.setFont(new Font("SansSerif", Font.BOLD, 12));
        ratingLbl.setForeground(WHITE); //white text on red badge
        badge.add(ratingLbl);
        badge.setBounds(9, 9, 68, 24); //absolute position: 9px from left, 9px from top
        card.add(badge);

        //CAR IMAGE OR SILHOUETTE - real photo if available, vector drawing as fallback
        int imgH = (int)(h * 0.63); //image occupies 63% of the card height
        JPanel imgPanel = buildCarImagePanel(car.imagePath, car, w - 10, imgH);
        imgPanel.setBounds(5, 8, w - 10, imgH); //slight inset from card edges
        card.add(imgPanel);

        //CAR NAME LABEL - brand in red italic and model in dark text positioned below the image
        JLabel nameLbl = makeCarNameLabel(car.brand, car.model, 15);
        nameLbl.setHorizontalAlignment(SwingConstants.CENTER); //center the text within the label
        nameLbl.setBounds(4, imgH + 12, w - 8, 34); //positioned just below the image area
        card.add(nameLbl);

        //HOVER AND CLICK BEHAVIOR - red border on hover, car detail page on click inside the same window
        card.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) {
                card.setBorder(BorderFactory.createLineBorder(RED, 2, true)); //red border appears on hover
                card.repaint();
            }
            @Override public void mouseExited(MouseEvent e) {
                card.setBorder(null); //remove border when mouse leaves
                card.repaint();
            }
            @Override public void mouseClicked(MouseEvent e) {
                Booking.openCarDetail(car, userName, UserDashboard.this); //open car detail inside this window
            }
        });
        return card;
    }

    //MAKE CAR NAME LABEL - creates an HTML-styled label with brand in red italic and model in dark bold
    private JLabel makeCarNameLabel(String brand, String model, int fontSize) {
        JLabel lbl = new JLabel("<html>"
                + "<span style='color:rgb(204,41,34);font-style:italic;'><b>" + brand + "</b></span>"
                + "<span style='color:rgb(30,30,30);'><b> " + model + "</b></span>"
                + "</html>");
        lbl.setFont(new Font("SansSerif", Font.PLAIN, fontSize));
        return lbl;
    }

    //BUILD CAR IMAGE PANEL - returns a panel showing the real car photo or the vector silhouette
    //loads from /car_images/<imagePath> on the classpath; falls back to drawSilhouette if not found
    private JPanel buildCarImagePanel(String imagePath, Car car, int w, int h) {
        BufferedImage img = loadCarImage(imagePath); //attempt to load the photo from classpath
        if (img != null) {
            final BufferedImage finalImg = img; //must be effectively final for use in the anonymous class
            return new JPanel() {
                { setOpaque(false); setPreferredSize(new Dimension(w, h)); }
                @Override protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    //ASPECT RATIO SCALING - fit the image inside the panel without stretching or cropping
                    int iw = finalImg.getWidth(), ih = finalImg.getHeight();
                    double scale = Math.min((double) getWidth() / iw, (double) getHeight() / ih); //uniform scale factor
                    int dw = (int)(iw * scale), dh = (int)(ih * scale); //scaled destination dimensions
                    int dx = (getWidth()  - dw) / 2; //center horizontally
                    int dy = (getHeight() - dh) / 2; //center vertically
                    g.drawImage(finalImg, dx, dy, dw, dh, this); //draw the scaled image centered
                }
            };
        }
        //FALLBACK - no image file found, draw the vector silhouette instead
        return buildSilhouettePanel(car, w, h);
    }

    //BUILD SILHOUETTE PANEL - transparent panel that delegates painting to drawSilhouette
    private JPanel buildSilhouettePanel(Car car, int w, int h) {
        return new JPanel() {
            { setOpaque(false); setPreferredSize(new Dimension(w, h)); }
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (car != null) drawSilhouette((Graphics2D) g.create(), car, getWidth(), getHeight());
            }
        };
    }

    //DRAW SILHOUETTE - paints a vector car shape onto the given Graphics2D context
    //shape type (SPORTS, SUV, TRUCK, SEDAN) is determined by the car's brand and model
    private void drawSilhouette(Graphics2D g2, Car car, int w, int h) {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        Color body   = bodyColor(car); //unique body color assigned to each specific car
        Color window = new Color(140, 195, 230, 110); //semi-transparent blue for windows
        Color tyre   = new Color(35, 35, 35); //dark grey for tyre circles
        Color rimCol = new Color(180, 182, 188); //light grey for wheel rims
        Color light  = new Color(255, 240, 130, 200); //yellow tint for front headlights
        Color tlight = new Color(220, 50,  50,  180); //red tint for rear tail lights
        String type  = carType(car); //determine which silhouette shape to draw

        //BODY DIMENSIONS - calculated as proportions of the panel size for resolution independence
        int bw = (int)(w * 0.82), bh = (int)(h * 0.26); //body width and height
        int bx = (w - bw) / 2,   by = (int)(h * 0.52); //body x and y origin
        int wheelR = (int)(bw * 0.14); //wheel radius proportional to body width
        int w1x = bx + (int)(bw * 0.17); //x center of front wheel
        int w2x = bx + (int)(bw * 0.72); //x center of rear wheel
        int wy  = by + bh - wheelR / 2; //y position where wheels sit against the bottom of the body

        //DRAW BODY SHAPE based on the detected car type
        if ("SPORTS".equals(type)) {
            //sports car uses a low wedge polygon for a sleek aerodynamic look
            int[] xb = {bx,bx+(int)(bw*.12),bx+(int)(bw*.32),bx+(int)(bw*.70),bx+(int)(bw*.92),bx+bw};
            int   tY = by-(int)(h*.18); //top of the roofline lower than SUV/sedan
            int[] yb = {by+bh,by,tY,tY,by,by+bh};
            g2.setColor(body); g2.fillPolygon(xb,yb,xb.length); //draw the wedge body
            //windshield polygon drawn on top of the body
            int[] xw={bx+(int)(bw*.22),bx+(int)(bw*.38),bx+(int)(bw*.68),bx+(int)(bw*.58)};
            int[] yw={by+2,tY+4,tY+4,by+2};
            g2.setColor(window); g2.fillPolygon(xw,yw,xw.length);

        } else if ("SUV".equals(type) || "TRUCK".equals(type)) {
            //SUV and truck use two stacked rectangles for a taller, boxier profile
            int rw2=(int)(bw*.70),rh=(int)(h*.26),rx=bx+(int)(bw*.08),ry=by-rh;
            g2.setColor(body);
            g2.fillRoundRect(bx,by,bw,bh,10,10); //lower body rectangle
            g2.fillRoundRect(rx,ry,rw2,rh+6,8,8); //upper cabin rectangle
            g2.setColor(window); g2.fillRoundRect(rx+6,ry+5,rw2-12,rh-8,6,6); //window inside the cabin

        } else {
            //sedan and hatchback use two smooth rounded rectangles for a classic car profile
            int rw2=(int)(bw*.58),rh=(int)(h*.22),rx=bx+(int)(bw*.20),ry=by-rh;
            g2.setColor(body);
            g2.fillRoundRect(bx,by,bw,bh,14,14); //lower body
            g2.fillRoundRect(rx,ry,rw2,rh+8,14,14); //upper roof section
            g2.setColor(window); g2.fillRoundRect(rx+6,ry+5,rw2-12,rh,10,10); //window inside the roof
        }

        //SHADOW - subtle dark shape at the bottom of the body adds depth to the silhouette
        g2.setColor(new Color(0,0,0,25));
        g2.fillRoundRect(bx,by+2,bw,bh-2,14,14);

        //WHEELS - draw both front and rear wheels using the same steps
        for (int wx : new int[]{w1x, w2x}) {
            g2.setColor(new Color(0,0,0,45)); //dark shadow behind wheel arch
            g2.fillOval(wx-wheelR-3,wy-5,wheelR*2+6,wheelR+6);
            g2.setColor(tyre); g2.fillOval(wx-wheelR,wy,wheelR*2,wheelR*2); //dark tyre circle
            g2.setColor(rimCol);
            int rr=(int)(wheelR*.54); //rim is 54% of the tyre radius
            g2.fillOval(wx-rr,wy+wheelR-rr,rr*2,rr*2); //lighter rim circle inside the tyre
            //SPOKES - three lines radiating from the rim center at 60-degree intervals
            g2.setColor(new Color(150,152,158));
            g2.setStroke(new BasicStroke(1.3f));
            for (int a=0;a<3;a++) {
                double angle=Math.toRadians(a*60); //each spoke 60 degrees apart
                g2.drawLine(wx,wy+wheelR,
                        wx+(int)(rr*Math.cos(angle)),
                        wy+wheelR+(int)(rr*Math.sin(angle)));
            }
            g2.setStroke(new BasicStroke(1f)); //reset stroke to default width after spokes
        }

        //LIGHTS - small oval shapes on the front and rear of the body
        g2.setColor(light);  g2.fillOval(bx+bw-16,by+6,12,8); //yellow front headlight
        g2.setColor(tlight); g2.fillOval(bx+4,    by+6,12,8); //red rear tail light
        g2.dispose(); //release the graphics context to free resources
    }

    //BODY COLOR - returns the specific paint color assigned to each car's silhouette
    private Color bodyColor(Car c) {
        if (c == null) return new Color(175, 180, 185); //default grey for null car reference
        switch (c.brand + " " + c.model) {
            case "Toyota Veloz":   return new Color(228,230,234); //light silver
            case "Honda Civic":    return new Color(198,204,216); //blue-silver
            case "Ford Everest":   return new Color(175,182,188); //steel grey
            case "Nissan Z Proto": return new Color(208,212,80);  //bright lime yellow
            case "Nissan Rogue":   return new Color(45, 50, 62);  //dark navy
            case "Nissan Razer":   return new Color(55, 108,210); //vibrant blue
            case "Toyota Hilux":   return new Color(192,192,186); //matte silver
            case "Toyota Wigo":    return new Color(238,238,238); //white
            default:               return new Color(175,180,185); //neutral grey for unknown cars
        }
    }

    //CAR TYPE - returns the silhouette shape category for a car based on brand and model
    private String carType(Car c) {
        if (c == null) return "SEDAN"; //default to sedan shape if car is null
        switch (c.brand + " " + c.model) {
            case "Toyota Veloz": case "Ford Everest": case "Nissan Rogue": return "SUV";   //tall boxy shape
            case "Toyota Hilux":                                            return "TRUCK"; //pickup with tray
            case "Nissan Z Proto": case "Nissan Razer":                     return "SPORTS"; //low wedge shape
            default:                                                         return "SEDAN"; //standard two-box
        }
    }

    //RENT HISTORY DIALOG - queries the bookings table and displays all past rentals in a table
    private void showRentHistory() {
        //join bookings with cars to get car names alongside booking dates, newest first
        String sql = "SELECT c.brand, c.model, b.start_date, b.end_date, b.booked_at " +
                     "FROM bookings b JOIN cars c ON b.car_id = c.id " +
                     "WHERE b.username = ? ORDER BY b.booked_at DESC";
        String[] cols = {"Car", "Start", "End", "Booked At"}; //column headers for the table
        java.util.Vector<String[]> rows = new java.util.Vector<>();
        try (Connection conn = connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, userName); //filter by the logged-in user
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                //add each booking as a row in the results vector
                rows.add(new String[]{
                        rs.getString("brand") + " " + rs.getString("model"), //car full name
                        rs.getString("start_date"),
                        rs.getString("end_date"),
                        rs.getString("booked_at") //timestamp of when the booking was made
                });
            }
        } catch (SQLException ex) { ex.printStackTrace(); }

        //show a message if no bookings exist for this user
        if (rows.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No rental history yet.", "Rent History", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        //convert the vector rows to a 2D array for the table model
        String[][] data = rows.stream().toArray(String[][]::new);
        javax.swing.table.DefaultTableModel model =
                new javax.swing.table.DefaultTableModel(data, cols) {
                    @Override public boolean isCellEditable(int r, int c) { return false; } //read-only table
                };
        JTable table = new JTable(model);
        table.setFillsViewportHeight(true); //fill the scrollpane even when there are few rows
        JScrollPane sp = new JScrollPane(table);
        sp.setPreferredSize(new Dimension(600, 300));
        JOptionPane.showMessageDialog(this, sp, "Rent History \u2014 " + userName, JOptionPane.PLAIN_MESSAGE);
    }

    //ADMIN CAR MANAGEMENT DIALOG - lets admin users add new cars or soft-delete existing ones
    private void showCarManagementDialog() {
        //modal dialog blocks input to the main window while it is open
        JDialog dialog = new JDialog(this, "Manage Cars", true);
        dialog.setSize(700, 480);
        dialog.setLocationRelativeTo(this); //center dialog over the parent window
        dialog.setLayout(new BorderLayout(10, 10));

        //TABLE OF CURRENT CARS - read-only view of all active cars with their database details
        String[] cols = {"ID", "Brand", "Model", "Rating", "Image File"};
        Object[][] data = CARS.stream().map(c ->
                new Object[]{c.id, c.brand, c.model, c.rating, c.imagePath == null ? "" : c.imagePath}
        ).toArray(Object[][]::new);

        javax.swing.table.DefaultTableModel tblModel =
                new javax.swing.table.DefaultTableModel(data, cols) {
                    @Override public boolean isCellEditable(int r, int c) { return false; } //read-only
                };
        JTable table = new JTable(tblModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); //only one row selectable at a time
        dialog.add(new JScrollPane(table), BorderLayout.CENTER);

        //BUTTON PANEL - add and remove car action buttons at the bottom of the dialog
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.CENTER, 18, 10));

        //ADD CAR BUTTON - opens a form to enter details for a new car and inserts it into the database
        JButton addBtn = new JButton("+ Add Car");
        addBtn.setBackground(RED); addBtn.setForeground(WHITE);
        addBtn.setFocusPainted(false);
        addBtn.addActionListener(ae -> {
            //input form fields for the new car's details
            JTextField brandF  = new JTextField(12);
            JTextField modelF  = new JTextField(12);
            JTextField ratingF = new JTextField("4.5", 6); //default rating prefilled
            JTextField imgF    = new JTextField("brand_model.png", 18); //hint for naming convention

            //2-column form layout with labels and fields
            JPanel form = new JPanel(new GridLayout(4, 2, 8, 8));
            form.add(new JLabel("Brand:"));           form.add(brandF);
            form.add(new JLabel("Model:"));           form.add(modelF);
            form.add(new JLabel("Rating (0-5):"));    form.add(ratingF);
            form.add(new JLabel("Image filename:"));  form.add(imgF);

            int r = JOptionPane.showConfirmDialog(dialog, form, "Add New Car",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (r == JOptionPane.OK_OPTION) {
                String br = brandF.getText().trim(), mo = modelF.getText().trim();
                String ip = imgF.getText().trim();
                double rt;
                try { rt = Double.parseDouble(ratingF.getText().trim()); } //parse rating to double
                catch (NumberFormatException ex) { rt = 4.0; } //default to 4.0 if parsing fails
                //brand and model are required fields; abort if either is empty
                if (br.isEmpty() || mo.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "Brand and Model are required.");
                    return;
                }
                try {
                    dbAddCar(br, mo, rt, ip.isEmpty() ? null : ip); //insert new car into the database
                    JOptionPane.showMessageDialog(dialog, "Car added successfully!");
                    dialog.dispose(); //close the management dialog
                    loadCarsFromDB(); //reload the CARS list to include the new entry
                    rebuildPages();   //rebuild the UI pages to reflect the updated list
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage());
                }
            }
        });

        //REMOVE CAR BUTTON - soft-deletes the selected car from the database
        JButton removeBtn = new JButton("\u2715 Remove Selected");
        removeBtn.setBackground(DARK_RED); removeBtn.setForeground(WHITE);
        removeBtn.setFocusPainted(false);
        removeBtn.addActionListener(ae -> {
            int row = table.getSelectedRow(); //get the index of the currently selected row
            if (row < 0) { JOptionPane.showMessageDialog(dialog, "Select a car first."); return; }
            int carId   = (int) tblModel.getValueAt(row, 0); //retrieve car ID from column 0
            String name = tblModel.getValueAt(row, 1) + " " + tblModel.getValueAt(row, 2); //car display name
            //confirm removal before making the database change
            int conf = JOptionPane.showConfirmDialog(dialog,
                    "Remove '" + name + "' from the fleet?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (conf == JOptionPane.YES_OPTION) {
                try {
                    dbRemoveCar(carId); //set available=FALSE in the database (soft delete)
                    JOptionPane.showMessageDialog(dialog, "Car removed.");
                    dialog.dispose(); //close the management dialog
                    loadCarsFromDB(); //reload the CARS list without the removed car
                    rebuildPages();   //rebuild the UI pages to remove the card from the grids
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage());
                }
            }
        });

        btns.add(addBtn);    //add the add button to the button panel
        btns.add(removeBtn); //add the remove button to the button panel
        dialog.add(btns, BorderLayout.SOUTH); //pin the button panel to the bottom of the dialog
        dialog.setVisible(true); //make the modal dialog visible and block the main window
    }

    //MAIN METHOD - standalone test entry point to launch the dashboard directly from Eclipse
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new UserDashboard("User", "USER")); //run on the Event Dispatch Thread
    }
}