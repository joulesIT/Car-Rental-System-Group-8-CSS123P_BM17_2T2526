//package declaration
package PROJECTGUI;

//swing imports for GUI components
import javax.swing.*;
import javax.swing.border.*;
//awt imports for graphics, layout, and events
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
//io, sql, and util imports
import java.io.InputStream;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;
import javax.imageio.ImageIO;

//booking class holds all UML fields and methods and builds the car detail and booking detail pages
//both pages are injected directly into UserDashboard's existing CardLayout so no new window opens
public class Booking {

    //UML FIELDS - all fields defined in the Booking UML diagram
    private int               id;          //primary key of the booking record
    private int               userID;      //foreign key referencing the user who made the booking
    private int               carID;       //foreign key referencing the car being booked
    private String            user;        //username of the logged-in user who owns this booking
    private UserDashboard.Car car;         //Car object from UserDashboard representing the booked vehicle
    private java.util.Date    startDate;   //rental start date set by the user during booking
    private java.util.Date    endDate;     //rental end date set by the user during booking
    private int               rentalDays;  //total number of days calculated from start to end date
    private double            totalAmount; //total cost calculated as rentalDays multiplied by the daily rate
    private java.util.Date    bookingDate; //timestamp of when the booking was submitted
    private int               overdueDays; //number of days the car was returned past the end date

    //UML METHOD - calculates the number of rental days between start and end date
    public int calculateRentalDays() {
        if (startDate == null || endDate == null) return 0; //return zero if either date is missing
        long diff = endDate.getTime() - startDate.getTime(); //difference in milliseconds
        return (int)(diff / (1000 * 60 * 60 * 24)); //convert milliseconds to whole days
    }

    //UML METHOD - calculates the total rental cost using the daily rate and number of rental days
    public double calculateTotal() {
        double dailyRate = getDailyRate(car); //look up the daily rate for this car
        return calculateRentalDays() * dailyRate; //multiply days by rate to get the total
    }

    //UML METHOD - returns a formatted string summary of all booking details for display or logging
    public String getBookingDetails() {
        return "Booking[id=" + id + ", user=" + user +
               ", car=" + (car != null ? car.brand + " " + car.model : "N/A") +
               ", start=" + startDate + ", end=" + endDate +
               ", days=" + rentalDays + ", total=" + totalAmount + "]";
    }

    //GETTERS - return the value of each private field as defined in the UML diagram
    public int               getID()          { return id; }
    public int               getUserID()      { return userID; }
    public int               getCarID()       { return carID; }
    public String            getUser()        { return user; }
    public UserDashboard.Car getCar()         { return car; }
    public java.util.Date    getStartDate()   { return startDate; }
    public java.util.Date    getEndDate()     { return endDate; }
    public int               getRentalDays()  { return rentalDays; }
    public double            getTotalAmount() { return totalAmount; }
    public java.util.Date    getBookingDate() { return bookingDate; }
    public int               getOverdueDays() { return overdueDays; }

    //SETTERS - assign values to each private field as defined in the UML diagram
    public void setID(int id)                    { this.id = id; }
    public void setUserID(int userID)            { this.userID = userID; }
    public void setCarID(int carID)              { this.carID = carID; }
    public void setUser(String user)             { this.user = user; }
    public void setCar(UserDashboard.Car car)    { this.car = car; }
    public void setStartDate(java.util.Date d)   { this.startDate = d; }
    public void setEndDate(java.util.Date d)     { this.endDate = d; }
    public void setRentalDays(int days)          { this.rentalDays = days; }
    public void setTotalAmount(double amt)       { this.totalAmount = amt; }
    public void setBookingDate(java.util.Date d) { this.bookingDate = d; }

    //UML METHOD - calculates overdue fees charged at 1.5x the daily rate per overdue day
    public double calculateOverdueFees() {
        if (overdueDays <= 0) return 0; //no fees if the car was returned on time or early
        return overdueDays * getDailyRate(car) * 1.5; //50% surcharge applied per overdue day
    }

    //UML METHOD - returns the grand total including the base rental cost and any overdue fees
    public double calculateFinalAmount() {
        return totalAmount + calculateOverdueFees(); //sum of rental total and any late return fees
    }

    //BRAND COLOR CONSTANTS - mirror the exact same colors used in UserDashboard for visual consistency
    private static final Color RED      = new Color(204, 41,  34); //primary brand red
    private static final Color DARK_RED = new Color(160, 28,  22); //darker red used for button hover states
    private static final Color CARD_BG  = new Color(195, 207, 215); //light blue-grey used on car cards
    private static final Color SIDEBAR  = new Color(210, 221, 229); //sidebar grey used on left detail panel
    private static final Color WHITE    = Color.WHITE;
    private static final Color DARK_TXT = new Color(30,  30,  30); //near-black for body text

    //CAR INFO MAP - stores key highlights and seating details for each car shown on the detail page
    //key is "Brand Model", value array uses "|" as a separator between highlights and body paragraph
    private static final Map<String, String[]> CAR_INFO = new HashMap<>();

    //CAR DAILY RATES MAP - stores the rental price per day in Philippine Pesos for each car
    private static final Map<String, Integer> DAILY_RATES = new HashMap<>();

    //CAR STATIC DETAILS MAP - stores plate number, condition, and status for each car
    private static final Map<String, String[]> CAR_STATIC = new HashMap<>();

    //STATIC INITIALIZER - populates all three maps when the class is first loaded
    static {

        //NISSAN Z PROTO - sports car detail data
        CAR_INFO.put("Nissan Z Proto", new String[]{
            "Key Highlights of the Nissan Z/Proto:",
            "Design: A \"retro-mod\" aesthetic, featuring a long hood, short deck, and 240ZG-inspired headlights, designed to evoke the original 240Z.",
            "Performance: Equipped with a VR30DDTT 3.0-liter V6 twin-turbo engine (383 PS or roughly in some markets), available in 6-speed manual or 9-speed automatic.",
            "Interior: Driver-focused cabin with a 12.3-inch digital display, leather-wrapped steering wheel, and a classic triple-gauge pod for boost, turbo speed, and voltage.",
            "Proto Spec Edition: A limited-edition (240 units) model featuring special yellow brake calipers, bronze wheels, and custom interior accents.",
            "Status: While the Z Proto was a concept, it led directly to the 2023-2024 production Nissan Z, with variants like the Performance and NISMO (up to 420 PS).",
            "Market: The car is positioned as a direct competitor to other sports cars, with a strong emphasis on manual transmission availability.",
            "|", //separator between highlights section and body paragraph
            "The 2023 Nissan Z Proto Spec is a 2-passenger (2-seater) sports car with two doors. It is designed with a focus on the driver and passenger, featuring sport bucket seats. The interior is configured for 2 adults only.",
            "Key seating details:",
            "Capacity: 2 (Driver and Passenger)",
            "Seat Types: Sport front bucket seats with leather-appointed surfaces and synthetic suede inserts.",
            "Adjustability: 4-way manual or power-adjustable passenger seat.",
            "Comfort: Designed with significant bolstered support for track driving."
        });

        //TOYOTA VELOZ - MPV detail data
        CAR_INFO.put("Toyota Veloz", new String[]{
            "Key Highlights of the Toyota Veloz:",
            "Design: Sporty and modern MPV design with a bold front grille, sleek LED headlights, and dynamic character lines along the body.",
            "Performance: Powered by a 1.5-liter Dual VVT-i engine producing approximately 105 hp, paired with a CVT or 5-speed manual transmission.",
            "Interior: Spacious 7-seater cabin featuring a 9-inch touchscreen infotainment system, dual-zone climate control, and ambient lighting.",
            "Safety: Equipped with Toyota Safety Sense including pre-collision warning, lane departure alert, and automatic high beam.",
            "Connectivity: Android Auto, Apple CarPlay, and built-in Wi-Fi hotspot support for seamless connectivity on the go.",
            "Market: Positioned as a premium MPV for families seeking comfort, safety, and versatility in urban and highway driving.",
            "|",
            "The Toyota Veloz is a 7-passenger multi-purpose vehicle (MPV) designed for families. It offers a spacious and comfortable interior with three rows of seating, making it ideal for both daily commutes and long-distance travel.",
            "Key seating details:",
            "Capacity: 7 passengers (2-3-2 seating configuration)",
            "Seat Types: Premium fabric or leather seats with lumbar support on front seats.",
            "Adjustability: 6-way manually adjustable driver seat and 4-way adjustable passenger seat.",
            "Comfort: Second-row captain seats offer armrests; third row folds flat for cargo space."
        });

        //HONDA CIVIC - sedan detail data
        CAR_INFO.put("Honda Civic", new String[]{
            "Key Highlights of the Honda Civic:",
            "Design: Clean, sophisticated sedan design with a fastback-inspired roofline, chrome accents, and sleek LED headlights with DRL.",
            "Performance: 1.5-liter VTEC Turbo engine delivering 174 hp and 220 Nm of torque, paired with a CVT transmission for smooth, efficient driving.",
            "Interior: Driver-oriented cockpit with a 9-inch Honda CONNECT infotainment display, wireless charging, and soft-touch dashboard materials.",
            "Safety: Honda SENSING suite includes Collision Mitigation Braking System, Road Departure Mitigation, Lane Keeping Assist, and Adaptive Cruise Control.",
            "Efficiency: Achieves approximately 15-17 km/L in combined driving, making it one of the most fuel-efficient sedans in its class.",
            "Market: A benchmark compact sedan known for reliability, sporty dynamics, and strong resale value across global markets.",
            "|",
            "The Honda Civic is a 5-passenger compact sedan known for its sporty performance and premium feel. The 2023 model features a completely redesigned interior with improved materials and cutting-edge technology.",
            "Key seating details:",
            "Capacity: 5 passengers (2 front + 3 rear)",
            "Seat Types: Fabric or leather-trimmed seats with heated front seats available on higher trims.",
            "Adjustability: 10-way power-adjustable driver seat with lumbar support; 4-way manual passenger seat.",
            "Comfort: Rear seats offer 38 inches of legroom; flat floor for center passenger comfort."
        });

        //FORD EVEREST - SUV detail data
        CAR_INFO.put("Ford Everest", new String[]{
            "Key Highlights of the Ford Everest:",
            "Design: Bold, truck-inspired SUV styling with a commanding road presence, C-clamp LED headlights, and a prominent front skid plate.",
            "Performance: Available engines include a 2.0-liter Bi-Turbo diesel (210 hp) and a powerful 3.0-liter V6 turbodiesel producing 250 hp and 600 Nm of torque.",
            "Interior: Premium 3-row cabin with a 12-inch SYNC 4 infotainment system, 12-inch digital instrument cluster, and available panoramic sunroof.",
            "Off-road Capability: Terrain Management System with 7 drive modes, electronic locking rear differential, and wading depth of 800mm.",
            "Safety: Ford Co-Pilot 360 technology includes AEB, Blind Spot Information System, Cross-Traffic Alert, Lane Centering, and Evasive Steering Assist.",
            "Market: Positioned as a premium 7-seat body-on-frame SUV competing directly with Toyota Fortuner and Mitsubishi Montero Sport.",
            "|",
            "The Ford Everest is a full-size, body-on-frame SUV offering 7 seats and exceptional off-road capability. With its powerful engine options and advanced technology, it is equally at home on city streets and rugged terrain.",
            "Key seating details:",
            "Capacity: 7 passengers (2-3-2 seating configuration)",
            "Seat Types: Premium leather seats with ventilated front seats on Titanium+ trim.",
            "Adjustability: 10-way power-adjustable driver seat with memory function; 6-way power passenger seat.",
            "Comfort: Second-row seats slide and recline; third-row seats fold 60/40 into the floor."
        });

        //NISSAN ROGUE - crossover SUV detail data
        CAR_INFO.put("Nissan Rogue", new String[]{
            "Key Highlights of the Nissan Rogue:",
            "Design: Modern crossover SUV with a V-Motion grille, floating roof design, and boomerang-shaped LED daytime running lights.",
            "Performance: 1.5-liter VC-Turbo (Variable Compression) engine producing 201 hp and 300 Nm of torque, paired with an Xtronic CVT.",
            "Interior: Zero Gravity front seats, a 12.3-inch digital instrument cluster, 9-inch infotainment display, and a panoramic moonroof.",
            "Technology: ProPILOT Assist with Navi-link provides semi-autonomous driving capability on highways.",
            "Safety: Nissan Safety Shield 360 with automatic emergency braking, rear cross-traffic alert, blind spot warning, and lane departure prevention.",
            "Market: A top-selling compact SUV in North America known for its comfort-focused ride and innovative features.",
            "|",
            "The Nissan Rogue is a 5-passenger compact SUV designed for modern families and urban adventurers. Its award-winning Zero Gravity seats and spacious cargo area make it one of the most comfortable vehicles in its segment.",
            "Key seating details:",
            "Capacity: 5 passengers (2 front + 3 rear)",
            "Seat Types: Zero Gravity front seats inspired by NASA research; rear bench with 60/40 split.",
            "Adjustability: 8-way power-adjustable driver seat; 4-way manual passenger seat.",
            "Comfort: Rear seats slide up to 6 inches forward/back; 39.5 inches of rear legroom."
        });

        //NISSAN RAZER - sport truck detail data
        CAR_INFO.put("Nissan Razer", new String[]{
            "Key Highlights of the Nissan Razer:",
            "Design: Aggressive sport-truck styling with razor-sharp body lines, a muscular hood scoop, wide fender flares, and 18-inch alloy wheels.",
            "Performance: 2.5-liter DOHC diesel engine producing 190 hp and 450 Nm of torque, available with 4WD and a 6-speed manual or automatic transmission.",
            "Interior: Sport-themed cabin with red accent stitching, a 7-inch touchscreen, and Nissan Connect for smartphone integration.",
            "Off-road Features: Electronic locking rear differential, hill descent control, and multi-terrain selector with 4 drive modes.",
            "Utility: Payload capacity of over 1 ton, with a composite-material truck bed featuring integrated tie-down rails and LED bed lighting.",
            "Market: Positioned as a high-performance lifestyle pickup competing with the Toyota HiLux Revo and Mitsubishi Strada GT.",
            "|",
            "The Nissan Razer is a sport-oriented pickup truck built for those who demand performance both on and off the road. With its bold design and powerful diesel engine, it combines work capability with street style.",
            "Key seating details:",
            "Capacity: 5 passengers (2 front + 3 rear double cab)",
            "Seat Types: Sport fabric seats with red stitching; driver seat with integrated lumbar support.",
            "Adjustability: 6-way manually adjustable driver seat; reclining rear bench.",
            "Comfort: Rear cabin offers 35 inches of legroom with fold-up rear seats for additional cargo storage."
        });

        //TOYOTA HILUX - pickup truck detail data
        CAR_INFO.put("Toyota Hilux", new String[]{
            "Key Highlights of the Toyota Hilux:",
            "Design: Tough, no-nonsense pickup truck styling with a wide stance, high ground clearance, and the iconic Hilux front fascia with LED daytime running lights.",
            "Performance: 2.8-liter 1GD-FTV turbodiesel engine producing 204 hp and 500 Nm of torque, available in 4x2 and 4x4 configurations.",
            "Interior: Practical and durable cabin with an 8-inch touchscreen, multi-information display, and optionally leather-trimmed seats on premium trims.",
            "Durability: Ladder-frame construction tested across the Dakar Rally and extreme off-road environments, renowned for near-indestructibility.",
            "Safety: Toyota Safety Sense includes pre-collision system, lane departure alert, and automatic high beams on higher variants.",
            "Market: The world's best-selling pickup truck, valued globally for its legendary reliability, strong resale value, and towing capacity of up to 3.5 tons.",
            "|",
            "The Toyota Hilux is a mid-size pickup truck available in single, extra, and double cab configurations. Its legendary toughness and reliability make it the go-to choice for both commercial use and adventure seekers worldwide.",
            "Key seating details:",
            "Capacity: 5 passengers (Double Cab) / 3 passengers (Extra Cab) / 2 passengers (Single Cab)",
            "Seat Types: Fabric or leather seats depending on trim; driver seat with lumbar support.",
            "Adjustability: 8-way power-adjustable driver seat on top trims; manual on base trims.",
            "Comfort: Double Cab rear seats recline and fold up for expanded cargo access."
        });

        //TOYOTA WIGO - subcompact hatchback detail data
        CAR_INFO.put("Toyota Wigo", new String[]{
            "Key Highlights of the Toyota Wigo:",
            "Design: Compact city hatchback with a cheerful, rounded design, reflector LED headlights, and available two-tone exterior color combinations.",
            "Performance: 1.0-liter DOHC VVT-i engine producing 65 hp and 89 Nm of torque, paired with a 5-speed manual or 4-speed automatic transmission.",
            "Interior: Surprisingly spacious cabin for a sub-compact car, featuring a 7-inch touchscreen with Android Auto and Apple CarPlay on higher variants.",
            "Fuel Efficiency: Achieves up to 20 km/L in highway conditions, making it one of the most economical vehicles available in its class.",
            "Practicality: Small exterior footprint (3,600mm length) makes it ideal for tight city parking while offering a competitive trunk capacity of 199 liters.",
            "Market: The best-selling entry-level hatchback in the Philippines, ideal for first-time car buyers and urban commuters.",
            "|",
            "The Toyota Wigo is a sub-compact 5-passenger hatchback designed for city driving. Its compact dimensions, excellent fuel economy, and low cost of ownership make it the perfect choice for budget-conscious urban drivers.",
            "Key seating details:",
            "Capacity: 5 passengers (2 front + 3 rear)",
            "Seat Types: Fabric seats with a simple but comfortable design; driver seat with height adjustment on G variant.",
            "Adjustability: 4-way manually adjustable driver seat; fixed passenger seat on base trim.",
            "Comfort: Rear bench offers 34 inches of legroom; adequate for short to medium trips."
        });

        //DAILY RATES - rental price per day in Philippine Pesos for each car
        DAILY_RATES.put("Toyota Veloz",   8000);
        DAILY_RATES.put("Honda Civic",    9500);
        DAILY_RATES.put("Ford Everest",   15000);
        DAILY_RATES.put("Nissan Z Proto", 20000);
        DAILY_RATES.put("Nissan Rogue",   12000);
        DAILY_RATES.put("Nissan Razer",   10000);
        DAILY_RATES.put("Toyota Hilux",   11000);
        DAILY_RATES.put("Toyota Wigo",    5000);

        //CAR STATIC DETAILS - plate number, condition, and availability status for each car
        CAR_STATIC.put("Toyota Veloz",   new String[]{"ABC 1234",  "Good",      "Available"});
        CAR_STATIC.put("Honda Civic",    new String[]{"DEF 5678",  "Excellent", "Available"});
        CAR_STATIC.put("Ford Everest",   new String[]{"GHI 9012",  "Excellent", "Available"});
        CAR_STATIC.put("Nissan Z Proto", new String[]{"UIUX 2026", "Excellent", "Available"});
        CAR_STATIC.put("Nissan Rogue",   new String[]{"JKL 3456",  "Very Good", "Available"});
        CAR_STATIC.put("Nissan Razer",   new String[]{"MNO 7890",  "Good",      "Available"});
        CAR_STATIC.put("Toyota Hilux",   new String[]{"PQR 2345",  "Excellent", "Available"});
        CAR_STATIC.put("Toyota Wigo",    new String[]{"STU 6789",  "Good",      "Available"});
    }

    //OPEN CAR DETAIL - static entry point called from UserDashboard when a car card is clicked
    //injects a new CAR DETAIL card into the dashboard's existing root CardLayout and navigates to it
    public static void openCarDetail(UserDashboard.Car car, String userName, UserDashboard dashboard) {
        SwingUtilities.invokeLater(() -> {
            //BUILD AND INJECT CAR DETAIL PAGE - add it to the existing root panel under a unique key
            String detailKey  = "DETAIL_"  + car.id; //unique card key so each car gets its own panel
            String bookingKey = "BOOKING_" + car.id; //unique card key for the booking form of this car
            JPanel detailPage = buildCarDetailPage(car, userName, dashboard, detailKey, bookingKey);
            dashboard.root.add(detailPage, detailKey); //inject the detail page into the card layout
            dashboard.cards.show(dashboard.root, detailKey); //navigate to the car detail page
        });
    }

    //BUILD CAR DETAIL PAGE - creates the full car detail page as a panel that fits inside the dashboard
    //left half shows the grey panel with car name and image; right half shows all text, rating, and price
    private static JPanel buildCarDetailPage(UserDashboard.Car car, String userName,
                                              UserDashboard dashboard, String detailKey, String bookingKey) {
        JPanel page = new JPanel(new BorderLayout());
        page.setBackground(WHITE);

        //TOP BAR - white bar with a back arrow that navigates back to the browse page
        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 18, 10));
        topBar.setBackground(WHITE);
        topBar.setBorder(new MatteBorder(0, 0, 1, 0, new Color(220, 220, 220))); //thin bottom border

        JLabel backArrow = new JLabel("\u2190 Back"); //← left arrow character
        backArrow.setFont(new Font("SansSerif", Font.BOLD, 15));
        backArrow.setForeground(RED); //red to match brand color
        backArrow.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); //hand cursor shows it is clickable
        backArrow.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                dashboard.cards.show(dashboard.root, "BROWSE"); //go back to the browse page
                dashboard.root.remove(page); //remove this detail panel to free memory
            }
            @Override public void mouseEntered(MouseEvent e) { backArrow.setForeground(DARK_RED); } //darken on hover
            @Override public void mouseExited(MouseEvent e)  { backArrow.setForeground(RED); } //restore on exit
        });
        topBar.add(backArrow);
        page.add(topBar, BorderLayout.NORTH);

        //SPLIT LAYOUT - JSplitPane replaces GridLayout so the right panel can wrap text at its actual width
        //left side gets 45% of the available width; right side gets the remaining 55%
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerSize(0);      //invisible divider so it looks like a normal two-column layout
        splitPane.setBorder(null);        //remove the default JSplitPane border
        splitPane.setResizeWeight(0.45);  //left panel keeps 45% when the window is resized

        //LEFT PANEL - grey gradient background with big italic brand and model name and the car photo
        JPanel leftPanel = buildDetailLeft(car);
        splitPane.setLeftComponent(leftPanel);

        //RIGHT PANEL - scrollable text area with highlights, seating, rating, price, and Book Now
        JPanel rightPanel = buildDetailRight(car, userName, dashboard, page, bookingKey);
        JScrollPane rightScroll = new JScrollPane(rightPanel,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER); //never show horizontal scrollbar so text wraps instead
        rightScroll.setBorder(null); //remove the default scroll pane border
        rightScroll.getVerticalScrollBar().setUnitIncrement(14); //smooth scrolling speed
        splitPane.setRightComponent(rightScroll);

        page.add(splitPane, BorderLayout.CENTER);

        //DIVIDER LOCATION - set after layout so the 45% split is applied against the real window width
        SwingUtilities.invokeLater(() -> {
            int totalWidth = page.getWidth();
            if (totalWidth > 0) splitPane.setDividerLocation((int)(totalWidth * 0.45));
        });

        //RED FOOTER STRIP - thin decorative bar at the bottom matching the rest of the dashboard
        JPanel strip = new JPanel();
        strip.setBackground(RED);
        strip.setPreferredSize(new Dimension(0, 6)); //6px tall accent strip
        page.add(strip, BorderLayout.SOUTH);

        return page;
    }

    //BUILD DETAIL LEFT - creates the left half of the car detail page with gradient background,
    //large italic brand and model name labels, and the car image scaled to fit the available space
    private static JPanel buildDetailLeft(UserDashboard.Car car) {
        JPanel panel = new JPanel(new BorderLayout()) { //BorderLayout so image fills remaining space
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint( //light grey gradient top to bottom
                        0, 0, new Color(225, 228, 232),
                        0, getHeight(), new Color(200, 206, 212));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight()); //fill the entire panel with the gradient
            }
        };

        //NAME BLOCK - stacks the brand label and model label vertically at the top of the left panel
        JPanel nameBlock = new JPanel();
        nameBlock.setLayout(new BoxLayout(nameBlock, BoxLayout.Y_AXIS));
        nameBlock.setOpaque(false); //transparent so the gradient background shows through
        nameBlock.setBorder(new EmptyBorder(20, 24, 8, 24)); //padding around the name labels

        //BRAND LABEL - large red italic brand name at the top; reduced from 48 to 36 to save vertical space
        JLabel brandLbl = new JLabel("<html><i>" + car.brand + "</i></html>");
        brandLbl.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 36));
        brandLbl.setForeground(RED); //red to match brand color
        nameBlock.add(brandLbl);

        //MODEL LABEL - large dark italic model name directly below the brand; reduced from 48 to 36
        JLabel modelLbl = new JLabel("<html><i>" + car.model + "</i></html>");
        modelLbl.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 36));
        modelLbl.setForeground(new Color(30, 30, 30)); //dark near-black for the model name
        nameBlock.add(modelLbl);

        panel.add(nameBlock, BorderLayout.NORTH); //pin the name block to the top of the left panel

        //CAR IMAGE - loads the real photo and scales it to fill the remaining space below the name
        BufferedImage img = loadImage(car.imagePath);
        if (img != null) {
            final BufferedImage finalImg = img; //must be effectively final for use in anonymous class
            JPanel imgPanel = new JPanel() { //custom panel paints the image scaled to fit
                { setOpaque(false); }
                @Override protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    int iw = finalImg.getWidth(), ih = finalImg.getHeight();
                    double scale = Math.min((double) getWidth() / iw, (double) getHeight() / ih); //uniform scale
                    int dw = (int)(iw * scale), dh = (int)(ih * scale);
                    int dx = (getWidth()  - dw) / 2; //center horizontally
                    int dy = (getHeight() - dh) / 2; //center vertically
                    g.drawImage(finalImg, dx, dy, dw, dh, this); //draw the scaled image centered
                }
            };
            panel.add(imgPanel, BorderLayout.CENTER); //image fills all remaining space below the name
        } else {
            //FALLBACK - no image found, draw the grey silhouette shape instead
            JPanel sil = buildSilhouette();
            panel.add(sil, BorderLayout.CENTER);
        }

        return panel;
    }

    //BUILD DETAIL RIGHT - creates the right half with all text content, star rating, price, and Book Now
    private static JPanel buildDetailRight(UserDashboard.Car car, String userName,
                                            UserDashboard dashboard, JPanel detailPage, String bookingKey) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS)); //stack all elements vertically
        panel.setBackground(WHITE);
        panel.setBorder(new EmptyBorder(20, 24, 20, 24)); //padding around all content

        String key    = car.brand + " " + car.model; //map lookup key for this car
        String[] info = CAR_INFO.get(key); //retrieve the info array for this specific car

        if (info != null) {
            //KEY HIGHLIGHTS TITLE - bold section heading at the top of the right panel
            JLabel hlTitle = new JLabel("<html><b>" + info[0] + "</b></html>");
            hlTitle.setFont(new Font("SansSerif", Font.BOLD, 13));
            hlTitle.setForeground(new Color(30, 30, 30));
            hlTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
            panel.add(hlTitle);
            panel.add(Box.createVerticalStrut(4));

            //HIGHLIGHT BULLETS - each entry before the "|" separator is shown as a bullet point
            int sepIdx = 1; //tracks the index of the "|" separator in the info array
            for (int i = 1; i < info.length; i++) {
                if (info[i].equals("|")) { sepIdx = i; break; } //stop when separator is found
                panel.add(makeBullet(info[i])); //add each highlight as a bullet label
                panel.add(Box.createVerticalStrut(2)); //small gap between each bullet
            }

            panel.add(Box.createVerticalStrut(8));

            //BODY PARAGRAPH - descriptive text about the car shown after the highlights
            //uses JLabel with HTML so text wraps naturally at the panel boundary instead of clipping
            if (sepIdx + 1 < info.length) {
                JLabel bodyText = new JLabel(
                    "<html><div style='width:100%;font-size:10pt;'>"
                    + info[sepIdx + 1] + "</div></html>");
                bodyText.setFont(new Font("SansSerif", Font.PLAIN, 11));
                bodyText.setForeground(new Color(30, 30, 30));
                bodyText.setAlignmentX(Component.LEFT_ALIGNMENT);
                bodyText.setMaximumSize(new Dimension(Integer.MAX_VALUE, Short.MAX_VALUE));
                panel.add(bodyText);
                panel.add(Box.createVerticalStrut(8));
            }

            //SEATING TITLE AND BULLETS - heading and bullets for the seating details section
            if (sepIdx + 2 < info.length) {
                JLabel seatTitle = new JLabel("<html><b>" + info[sepIdx + 2] + "</b></html>");
                seatTitle.setFont(new Font("SansSerif", Font.BOLD, 12));
                seatTitle.setForeground(new Color(30, 30, 30));
                seatTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
                panel.add(seatTitle);
                panel.add(Box.createVerticalStrut(3));
                for (int i = sepIdx + 3; i < info.length; i++) {
                    panel.add(makeBullet(info[i])); //add each seating detail as a bullet point
                    panel.add(Box.createVerticalStrut(2));
                }
            }
        }

        panel.add(Box.createVerticalStrut(12));

        //DIVIDER LINE - thin grey separator before the rating and price section
        JSeparator sep = new JSeparator();
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        sep.setForeground(new Color(200, 200, 200)); //light grey divider color
        sep.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(sep);
        panel.add(Box.createVerticalStrut(10));

        //RATING LABEL - plain text label above the star characters
        JLabel ratingLabel = new JLabel("Rating:");
        ratingLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        ratingLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(ratingLabel);
        panel.add(Box.createVerticalStrut(2));

        //STAR RATING - red filled and empty stars followed by the numeric rating value
        JLabel stars = new JLabel(buildStarString(car.rating) + "  " + car.rating);
        stars.setFont(new Font("SansSerif", Font.BOLD, 18));
        stars.setForeground(RED); //red to match brand color
        stars.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(stars);
        panel.add(Box.createVerticalStrut(6));

        //PRICE LABEL - large bold daily rate in Philippine Pesos
        int rate = getDailyRate(car); //look up the configured daily rate for this car
        JLabel priceLbl = new JLabel("\u20B1" + String.format("%,d", rate) + "/day"); //₱ sign with formatted number
        priceLbl.setFont(new Font("SansSerif", Font.BOLD, 24));
        priceLbl.setForeground(new Color(30, 30, 30));
        priceLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(priceLbl);
        panel.add(Box.createVerticalStrut(12));

        //BOOK NOW BUTTON - navigates to the booking form page inside the same window
        JButton bookBtn = makeRedButton("Book Now");
        bookBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        bookBtn.addActionListener(e -> {
            //BUILD AND INJECT BOOKING PAGE into the dashboard's root panel under a unique key
            JPanel bookingPage = buildBookingPage(car, userName, dashboard, detailPage, bookingKey);
            dashboard.root.add(bookingPage, bookingKey); //inject the booking page into the card layout
            dashboard.cards.show(dashboard.root, bookingKey); //navigate to the booking page
        });
        panel.add(bookBtn);
        panel.add(Box.createVerticalStrut(16));

        return panel;
    }

    //BUILD BOOKING PAGE - creates the full booking details form page as a panel inside the dashboard
    //shown after Book Now is clicked; no new window opens, it replaces the view in the same frame
    private static JPanel buildBookingPage(UserDashboard.Car car, String userName,
                                            UserDashboard dashboard, JPanel detailPage, String bookingKey) {
        JPanel page = new JPanel(new BorderLayout());
        page.setBackground(WHITE);

        //RED HEADER BANNER - full-width red bar at the top with the BOOKING DETAILS title
        JPanel header = new JPanel(new GridBagLayout());
        header.setBackground(RED);
        header.setPreferredSize(new Dimension(0, 68)); //fixed height for the banner
        JLabel titleLbl = new JLabel("BOOKING DETAILS");
        titleLbl.setFont(new Font("SansSerif", Font.BOLD, 30));
        titleLbl.setForeground(WHITE); //white text on red background
        header.add(titleLbl);
        page.add(header, BorderLayout.NORTH);

        //BODY - left panel has the renter form, right panel has the car details and submit button
        JPanel body = new JPanel(new GridLayout(1, 2, 40, 0));
        body.setBackground(WHITE);
        body.setBorder(new EmptyBorder(30, 50, 30, 50)); //padding around both panels

        //LEFT FORM PANEL - stacks the title and all input fields vertically
        JPanel leftForm = new JPanel();
        leftForm.setLayout(new BoxLayout(leftForm, BoxLayout.Y_AXIS));
        leftForm.setBackground(WHITE);

        //FORM TITLE - red bold label above the input fields
        JLabel renterTitle = new JLabel("Enter Renter Details:");
        renterTitle.setFont(new Font("SansSerif", Font.BOLD, 15));
        renterTitle.setForeground(RED); //red to match brand color
        renterTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        leftForm.add(renterTitle);
        leftForm.add(Box.createVerticalStrut(14)); //spacing between title and first field

        //FORM FIELDS - each field uses a plain String placeholder; no pre-filled date text
        JTextField fullNameField  = makeFormField("Full Name");
        JTextField licenseField   = makeFormField("Driver's License #");
        JTextField contactField   = makeFormField("Contact Number");
        JTextField startDateField = makeFormField("Start Date (YYYY-MM-DD)");
        JTextField endDateField   = makeFormField("End Date (YYYY-MM-DD)");
        JTextField paymentField   = makeFormField("Payment Method");

        //PRE-FILL FROM DATABASE - load any previously saved renter details for this user
        //so returning users do not have to re-enter their name, license, and contact every time
        String[] profile = fetchUserProfile(userName); //returns {legal_name, drivers_license, phone_number}
        if (!profile[0].isEmpty()) { fullNameField.setText(profile[0]); fullNameField.setForeground(new Color(30,30,30)); } //pre-fill full name if saved
        if (!profile[1].isEmpty()) { licenseField.setText(profile[1]);  licenseField.setForeground(new Color(30,30,30));  } //pre-fill license if saved
        if (!profile[2].isEmpty()) { contactField.setText(profile[2]);  contactField.setForeground(new Color(30,30,30));  } //pre-fill contact if saved

        //add each field to the left form with consistent vertical spacing
        for (JTextField f : new JTextField[]{fullNameField, licenseField,
                contactField, startDateField, endDateField, paymentField}) {
            f.setAlignmentX(Component.LEFT_ALIGNMENT);
            f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40)); //full width, fixed height
            leftForm.add(f);
            leftForm.add(Box.createVerticalStrut(10)); //gap between each field
        }

        //BACK LINK - small clickable label at the bottom of the form to return to the car detail page
        JLabel backLink = new JLabel("<html><u>\u2190 Back to Car Detail</u></html>"); //← arrow
        backLink.setFont(new Font("SansSerif", Font.PLAIN, 13));
        backLink.setForeground(RED); //red underline link style
        backLink.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        backLink.setAlignmentX(Component.LEFT_ALIGNMENT);
        backLink.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                dashboard.cards.show(dashboard.root, "DETAIL_" + car.id); //go back to the detail page
            }
        });
        leftForm.add(Box.createVerticalStrut(6));
        leftForm.add(backLink);

        body.add(leftForm);

        //RIGHT DETAIL PANEL - car name, static info, thumbnail, total dues label, and submit button
        JPanel rightDetail = new JPanel();
        rightDetail.setLayout(new BoxLayout(rightDetail, BoxLayout.Y_AXIS));
        rightDetail.setBackground(WHITE);

        //CAR DETAILS TITLE - red bold label above the car info block
        JLabel carDetailTitle = new JLabel("Car Details:");
        carDetailTitle.setFont(new Font("SansSerif", Font.BOLD, 15));
        carDetailTitle.setForeground(RED); //red to match brand color
        carDetailTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        rightDetail.add(carDetailTitle);
        rightDetail.add(Box.createVerticalStrut(8));

        //CAR NAME - brand in red italic and model in dark italic using HTML formatting
        JLabel carNameLbl = new JLabel(
                "<html><span style='color:rgb(204,41,34);font-size:20pt;'><i><b>"
                + car.brand + " </b></i></span>"
                + "<span style='color:rgb(30,30,30);font-size:20pt;'><i><b>"
                + car.model + "</b></i></span></html>");
        carNameLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        rightDetail.add(carNameLbl);
        rightDetail.add(Box.createVerticalStrut(10));

        //STATIC CAR DETAILS - plate number, condition, status, and daily rent price
        String key      = car.brand + " " + car.model; //map lookup key for this car
        String[] statics = CAR_STATIC.getOrDefault(key, new String[]{"N/A", "N/A", "Available"}); //fallback if not found
        int dailyRate   = getDailyRate(car); //look up the rental price per day

        //add each static detail line with small gaps between them
        for (JLabel l : new JLabel[]{
                makeDetailLine("Plate Number: " + statics[0]),
                makeDetailLine("Condition: "    + statics[1]),
                makeDetailLine("Status: "       + statics[2]),
                makeDetailLine("Rent Price (/day): " + String.format("%,d", dailyRate))}) {
            l.setAlignmentX(Component.LEFT_ALIGNMENT);
            rightDetail.add(l);
            rightDetail.add(Box.createVerticalStrut(3));
        }

        rightDetail.add(Box.createVerticalStrut(10));

        //CAR THUMBNAIL - small scaled photo of the car shown on the right side of the form
        BufferedImage img = loadImage(car.imagePath);
        if (img != null) {
            JLabel thumb = new JLabel(new ImageIcon(
                    img.getScaledInstance(210, 130, Image.SCALE_SMOOTH))); //scale to thumbnail size
            thumb.setAlignmentX(Component.LEFT_ALIGNMENT);
            rightDetail.add(thumb);
        }

        rightDetail.add(Box.createVerticalStrut(12));

        //TOTAL DUES TITLE - red bold label above the calculated total amount
        JLabel totalTitle = new JLabel("Total Dues:");
        totalTitle.setFont(new Font("SansSerif", Font.BOLD, 15));
        totalTitle.setForeground(RED); //red to match brand color
        totalTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        rightDetail.add(totalTitle);
        rightDetail.add(Box.createVerticalStrut(4));

        //TOTAL AMOUNT LABEL - large bold label; starts at ₱0 and updates live as dates are typed
        JLabel totalAmt = new JLabel("\u20B10"); //₱0 shown until the user types valid dates
        totalAmt.setFont(new Font("SansSerif", Font.BOLD, 28));
        totalAmt.setForeground(new Color(30, 30, 30));
        totalAmt.setAlignmentX(Component.LEFT_ALIGNMENT);
        rightDetail.add(totalAmt);
        rightDetail.add(Box.createVerticalStrut(16));

        //SUBMIT BOOKING BUTTON - validates the form and saves the booking record to the database
        JButton submitBtn = makeRedButton("Submit Booking");
        submitBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        rightDetail.add(submitBtn);

        body.add(rightDetail);
        page.add(body, BorderLayout.CENTER);

        //RED FOOTER STRIP - thin decorative bar at the bottom matching the rest of the dashboard
        JPanel strip = new JPanel();
        strip.setBackground(RED);
        strip.setPreferredSize(new Dimension(0, 6)); //6px tall accent strip
        page.add(strip, BorderLayout.SOUTH);

        //LIVE TOTAL UPDATE - key listener attached to both date fields recalculates total on each keystroke
        //uses DocumentListener instead of KeyListener so paste and delete also trigger the update
        javax.swing.event.DocumentListener liveUpdate = new javax.swing.event.DocumentListener() {
            @Override public void insertUpdate(javax.swing.event.DocumentEvent e)  { updateTotal(startDateField, endDateField, dailyRate, totalAmt); }
            @Override public void removeUpdate(javax.swing.event.DocumentEvent e)  { updateTotal(startDateField, endDateField, dailyRate, totalAmt); }
            @Override public void changedUpdate(javax.swing.event.DocumentEvent e) { updateTotal(startDateField, endDateField, dailyRate, totalAmt); }
        };
        startDateField.getDocument().addDocumentListener(liveUpdate); //attach to start date field document
        endDateField.getDocument().addDocumentListener(liveUpdate);   //attach to end date field document

        //SUBMIT ACTION - validates all fields, creates a Booking object, and saves it to the database
        submitBtn.addActionListener(e -> {
            //retrieve and trim whitespace from every form field value
            String fullName = fullNameField.getText().trim();
            String license  = licenseField.getText().trim();
            String contact  = contactField.getText().trim();
            String startStr = startDateField.getText().trim();
            String endStr   = endDateField.getText().trim();
            String payment  = paymentField.getText().trim();

            //PLACEHOLDER CHECK - treat fields that still show their placeholder text as empty
            if (fullName.equals("Full Name") || fullName.isEmpty() ||
                license.equals("Driver's License #") || license.isEmpty() ||
                contact.equals("Contact Number") || contact.isEmpty() ||
                startStr.equals("Start Date (YYYY-MM-DD)") || startStr.isEmpty() ||
                endStr.equals("End Date (YYYY-MM-DD)") || endStr.isEmpty() ||
                payment.equals("Payment Method") || payment.isEmpty()) {
                JOptionPane.showMessageDialog(page,
                        "Please fill in all fields.", "Incomplete", JOptionPane.WARNING_MESSAGE);
                return;
            }

            //DATE PARSING - parse both date strings and catch any invalid format errors
            LocalDate start, end;
            try {
                start = LocalDate.parse(startStr); //throws DateTimeParseException if format is wrong
                end   = LocalDate.parse(endStr);
            } catch (DateTimeParseException ex) {
                JOptionPane.showMessageDialog(page,
                        "Dates must be in YYYY-MM-DD format.", "Invalid Date", JOptionPane.ERROR_MESSAGE);
                return;
            }

            //DATE RANGE CHECK - end date must be strictly after the start date
            if (!end.isAfter(start)) {
                JOptionPane.showMessageDialog(page,
                        "End date must be after start date.", "Invalid Range", JOptionPane.ERROR_MESSAGE);
                return;
            }

            //CALCULATE TOTAL - number of days multiplied by the configured daily rate
            long days    = ChronoUnit.DAYS.between(start, end);
            double total = days * dailyRate;

            //BUILD BOOKING OBJECT - populate all UML fields before writing to the database
            Booking booking = new Booking();
            booking.setCar(car);                                          //set the booked car object
            booking.setUser(userName);                                    //set the logged-in username
            booking.setCarID(car.id);                                     //set the car's database primary key
            booking.setStartDate(java.sql.Date.valueOf(start));           //convert LocalDate to java.util.Date
            booking.setEndDate(java.sql.Date.valueOf(end));               //convert LocalDate to java.util.Date
            booking.setRentalDays((int) days);                            //store the computed rental days
            booking.setTotalAmount(total);                                //store the computed total cost
            booking.setBookingDate(new java.util.Date());                 //timestamp the booking now

            //SAVE TO DATABASE - insert booking row and update the user's profile details
            try {
                saveBookingToDB(booking, fullName, license, contact, payment);
                JOptionPane.showMessageDialog(page,
                        "Booking confirmed!\n"
                        + car.brand + " " + car.model + "\n"
                        + startStr + " \u2192 " + endStr + "\n" //→ arrow between dates
                        + "Total: \u20B1" + String.format("%,.0f", total), //₱ sign before total
                        "Booking Successful", JOptionPane.INFORMATION_MESSAGE);
                //NAVIGATE BACK TO BROWSE - remove both injected cards and return to the browse page
                dashboard.root.remove(page); //remove the booking page from the card layout
                dashboard.root.remove(detailPage); //remove the detail page from the card layout
                dashboard.rebuildPages(); //rebuild home and browse so sidebar shows the new last booking
                dashboard.cards.show(dashboard.root, "BROWSE"); //go back to the browse page
            } catch (SQLException ex) {
                ex.printStackTrace(); //print database errors to the console for debugging
                JOptionPane.showMessageDialog(page,
                        "Database error: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        return page;
    }

    //DATABASE CONNECTION - creates a JDBC connection to the local MySQL car_rental database
    private static Connection connect() throws SQLException {
        return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/car_rental2", "root", "myPASSsql@54321");
    }

    //FETCH USER PROFILE - queries the users table for the saved renter details of the given username
    //returns a String array {legal_name, drivers_license, phone_number} with empty strings for nulls
    private static String[] fetchUserProfile(String username) {
        String sql = "SELECT legal_name, drivers_license, phone_number FROM users WHERE username = ?";
        try (Connection conn = connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username); //match the row by username
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                //replace null database values with empty strings so the fields can be checked safely
                String name    = rs.getString("legal_name")      != null ? rs.getString("legal_name")      : "";
                String license = rs.getString("drivers_license") != null ? rs.getString("drivers_license") : "";
                String phone   = rs.getString("phone_number")    != null ? rs.getString("phone_number")    : "";
                return new String[]{name, license, phone}; //return the three profile fields
            }
        } catch (SQLException ex) { ex.printStackTrace(); }
        return new String[]{"", "", ""}; //return empty strings if the query fails or finds no row
    }

    //SAVE BOOKING TO DATABASE - inserts a booking row and updates the user's renter profile
    //wrapped in a transaction so both operations succeed together or both are rolled back on failure
    private static void saveBookingToDB(Booking booking, String fullName,
                                        String license, String contact,
                                        String paymentMethod) throws SQLException {
        try (Connection conn = connect()) {
            conn.setAutoCommit(false); //start a transaction so both operations commit together

            //INSERT BOOKING - add a new row using the same schema as UserDashboard.insertBooking
            String insertSql =
                    "INSERT INTO bookings (username, car_id, start_date, end_date, legal_name, drivers_license, phone_number, payment_method) VALUES (?,?,?,?,?,?,?,?)";
            try (PreparedStatement ps = conn.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, booking.getUser());                 //associate booking with the logged-in user
                ps.setInt   (2, booking.getCarID());                //the database ID of the booked car
                ps.setString(3, booking.getStartDate().toString()); //start date in YYYY-MM-DD format
                ps.setString(4, booking.getEndDate().toString());   //end date in YYYY-MM-DD format
                ps.setString(5, fullName);                            //full legal name of the renter
                ps.setString(6, license);                             //driver's license number of the renter
                ps.setString(7, contact);                             //contact phone number of the renter
                ps.setString(8, paymentMethod);                       //payment method entered in the form
                ps.executeUpdate();
                ResultSet keys = ps.getGeneratedKeys(); //retrieve the auto-generated booking ID
                if (keys.next()) booking.setID(keys.getInt(1)); //store the generated ID on the object
            }

            //UPDATE USER PROFILE - save renter details from the form back into the users table
            String updateUser =
                    "UPDATE users SET legal_name=?, drivers_license=?, phone_number=? WHERE username=?";
            try (PreparedStatement ps = conn.prepareStatement(updateUser)) {
                ps.setString(1, fullName);           //full legal name entered in the form
                ps.setString(2, license);            //driver's license number entered in the form
                ps.setString(3, contact);            //contact phone number entered in the form
                ps.setString(4, booking.getUser());  //match the correct user row by username
                ps.executeUpdate();
            }

            conn.commit(); //commit both the booking insert and user update as one transaction
        }
    }

    //GET DAILY RATE - returns the rental price per day for the given car; defaults to 5000 if not found
    static int getDailyRate(UserDashboard.Car car) {
        if (car == null) return 0; //return zero if no car object is provided
        return DAILY_RATES.getOrDefault(car.brand + " " + car.model, 5000); //look up or use default
    }

    //UPDATE TOTAL - recalculates the total dues label live whenever the date fields change
    //triggered by a DocumentListener so paste, delete, and typing all update the label
    private static void updateTotal(JTextField startFld, JTextField endFld,
                                    int dailyRate, JLabel totalLbl) {
        try {
            String s = startFld.getText().trim();
            String e = endFld.getText().trim();
            //skip calculation if either field still shows its placeholder text
            if (s.equals("Start Date (YYYY-MM-DD)") || e.equals("End Date (YYYY-MM-DD)")) {
                totalLbl.setText("\u20B10"); return; //show ₱0 for placeholder text
            }
            LocalDate start = LocalDate.parse(s); //parse the start date field value
            LocalDate end   = LocalDate.parse(e); //parse the end date field value
            if (end.isAfter(start)) {
                long days  = ChronoUnit.DAYS.between(start, end); //calculate number of rental days
                double tot = days * dailyRate; //multiply days by the daily rate
                totalLbl.setText("\u20B1" + String.format("%,.0f", tot)); //show formatted ₱ total
            } else {
                totalLbl.setText("\u20B10"); //show zero if end is not strictly after start
            }
        } catch (DateTimeParseException ex) {
            totalLbl.setText("\u20B10"); //show zero if either date field has an invalid value
        }
    }

    //LOAD IMAGE - loads a car photo from the /car_images/ classpath resource folder
    //returns null if the file does not exist so callers can fall back to the silhouette
    private static BufferedImage loadImage(String imagePath) {
        if (imagePath == null || imagePath.isBlank()) return null; //no path means no image to load
        try {
            InputStream is = Booking.class.getResourceAsStream("/car_images/" + imagePath);
            return (is != null) ? ImageIO.read(is) : null; //decode and return, or null if not found
        } catch (Exception e) { return null; } //return null on any IO or decode error
    }

    //BUILD SILHOUETTE - draws a simple grey car shape as a fallback when no image file is available
    private static JPanel buildSilhouette() {
        return new JPanel() {
            { setOpaque(false); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int w = getWidth(), h = getHeight();
                g2.setColor(new Color(180, 185, 190)); //grey fill for the car body shape
                int bx = w/10, by = h/2, bw = w*4/5, bh = h/4;
                g2.fillRoundRect(bx, by, bw, bh, 20, 20); //lower body rectangle
                g2.fillRoundRect(bx + bw/5, by - bh/2, bw*3/5, bh/2 + 10, 12, 12); //upper roof section
                g2.setColor(new Color(60, 60, 60)); //dark grey for the wheel circles
                int wr = bh/2;
                g2.fillOval(bx + bw/5 - wr, by + bh - wr, wr*2, wr*2); //front wheel
                g2.fillOval(bx + bw*4/5 - wr, by + bh - wr, wr*2, wr*2); //rear wheel
                g2.dispose(); //release the graphics context
            }
        };
    }

    //MAKE BULLET - creates a bullet-point JLabel for the highlights and seating details sections
    //uses HTML div so long text wraps within the panel width instead of clipping past the edge
    private static JLabel makeBullet(String text) {
        JLabel lbl = new JLabel(
            "<html><div style='font-size:10pt;'>\u2022&nbsp;" + text + "</div></html>"); //• bullet with wrapping div
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lbl.setForeground(new Color(30, 30, 30)); //dark near-black for readability
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        lbl.setMaximumSize(new Dimension(Integer.MAX_VALUE, Short.MAX_VALUE)); //allow vertical growth for wrapped lines
        return lbl;
    }

    //MAKE DETAIL LINE - creates a red-colored info label for the booking details panel
    private static JLabel makeDetailLine(String text) {
        JLabel lbl = new JLabel("<html><span style='color:rgb(204,41,34);'>" + text + "</span></html>");
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 13));
        return lbl;
    }

    //MAKE FORM FIELD - creates a red-bordered text field with placeholder text behavior
    //placeholder disappears on focus and reappears if the field is left blank when focus is lost
    private static JTextField makeFormField(String placeholder) {
        JTextField field = new JTextField(placeholder);
        field.setFont(new Font("SansSerif", Font.PLAIN, 13));
        field.setForeground(RED); //red placeholder text to match brand color
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(RED, 1), //red 1px outer border
                BorderFactory.createEmptyBorder(6, 10, 6, 10))); //inner padding
        field.setBackground(WHITE);
        //PLACEHOLDER BEHAVIOR - clear on focus, restore if left blank
        field.addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent e) {
                if (field.getText().equals(placeholder)) { field.setText(""); field.setForeground(new Color(30,30,30)); } //clear placeholder
            }
            @Override public void focusLost(FocusEvent e) {
                if (field.getText().isBlank()) { field.setText(placeholder); field.setForeground(RED); } //restore placeholder
            }
        });
        return field;
    }

    //MAKE RED BUTTON - creates a rounded red button with white label and hover darkening effect
    private static JButton makeRedButton(String label) {
        JButton btn = new JButton(label) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? DARK_RED : RED); //darken on hover
                g2.fillRoundRect(0, 0, getWidth()-1, getHeight()-1, 8, 8); //rounded corners
                g2.dispose();
                super.paintComponent(g); //draw the label text on top
            }
        };
        btn.setFont(new Font("SansSerif", Font.BOLD, 14));
        btn.setForeground(WHITE); //white text on red background
        btn.setOpaque(false); //transparent so paintComponent handles the background
        btn.setContentAreaFilled(false); //prevent Swing default fill from overriding paintComponent
        btn.setBorderPainted(false); //remove default border so rounded corners look clean
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); //hand cursor on hover
        btn.setPreferredSize(new Dimension(160, 42)); //fixed button size
        btn.setMaximumSize(new Dimension(200, 42)); //cap maximum width in BoxLayout
        return btn;
    }

    //BUILD STAR STRING - builds a string of filled and empty star characters for the rating display
    private static String buildStarString(double rating) {
        StringBuilder sb = new StringBuilder();
        int full  = (int) rating; //filled stars equal the integer part of the rating
        int empty = 5 - full;    //remaining stars out of five shown as empty outlines
        for (int i = 0; i < full;  i++) sb.append("\u2605"); //★ filled star
        for (int i = 0; i < empty; i++) sb.append("\u2606"); //☆ empty star
        return sb.toString();
    }
}