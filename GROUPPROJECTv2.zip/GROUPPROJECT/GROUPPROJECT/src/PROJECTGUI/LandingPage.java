//package
package PROJECTGUI;

//imports
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.InputStream;
import java.sql.*;

//main class - entry point and window manager for DriveDash, handles login/signup flow
public class LandingPage extends JFrame {

    //card layout allows switching between landing, login, and signup panels without new windows
    private CardLayout cardLayout = new CardLayout();
    //main container holds all the card panels managed by cardLayout
    private JPanel mainContainer = new JPanel(cardLayout);
    //brand red color used consistently across all UI elements
    private final Color DASH_RED = new Color(204, 41, 34);

    //secret code required during signup to register as an admin
    private final String ADMIN_CODE = "DRIVEDASHadminCODE2026";

    //buttons declared at class level so they can be referenced across methods
    private JButton loginBtn  = new JButton("Log-In");
    private JButton signupBtn = new JButton("SignUp");

    //JFRAME INITIAL COMPONENTS - constructor sets up the window and adds all three card panels

    public LandingPage() {
        setTitle("DriveDash Car Rental System by Group 8"); //window title bar text
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //terminate the app when window closes
        setSize(1400, 800); //initial window dimensions in pixels

        //add each page panel to the card layout container with a string key identifier
        mainContainer.add(createLandingFrame(), "LANDING PAGE"); //home/welcome screen
        mainContainer.add(createAuthView(true),  "LOGIN PAGE");  //login form
        mainContainer.add(createAuthView(false), "SIGNUP PAGE"); //signup/registration form

        add(mainContainer); //attach the card container to the JFrame
        setLocationRelativeTo(null); //center the window on the screen
        setVisible(true); //make the window visible to the user
    }


    //FRAME 1: Landing Page - shows background image with login and signup buttons

    private JPanel createLandingFrame() {
        //ImagePanel is a custom JPanel that paints a background image loaded from the classpath
        ImagePanel panel = new ImagePanel("/1.png");
        panel.setLayout(new GridBagLayout()); //GridBagLayout lets us position buttons precisely
        GridBagConstraints gbc = new GridBagConstraints();

        //first cell fills the left half of the panel with empty space (pushes buttons to the right)
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.5;
        gbc.fill = GridBagConstraints.BOTH;
        panel.add(Box.createGlue(), gbc); //invisible spacer that stretches to fill space

        //button container stacks login and signup buttons vertically with a 20px gap
        JPanel buttonContainer = new JPanel(new GridLayout(2, 1, 0, 20));
        buttonContainer.setOpaque(false); //transparent so the background image shows through

        //shared button dimensions and font for visual consistency
        Dimension btnSize = new Dimension(250, 70);
        Font      btnFont = new Font("SansSerif", Font.BOLD, 22);

        //LOGIN BUTTON - white background with red text, navigates to the login card
        loginBtn.setPreferredSize(btnSize);
        loginBtn.setFont(btnFont);
        loginBtn.setForeground(DASH_RED); //red text on white button
        loginBtn.setBackground(Color.WHITE);
        loginBtn.setFocusPainted(false); //removes the dotted focus ring
        loginBtn.addActionListener(e -> cardLayout.show(mainContainer, "LOGIN PAGE")); //switch to login card

        //SIGNUP BUTTON - transparent outline style with white text and border
        signupBtn.setPreferredSize(btnSize);
        signupBtn.setFont(btnFont);
        signupBtn.setForeground(Color.WHITE); //white text on transparent button
        signupBtn.setContentAreaFilled(false); //no fill so background image shows through
        signupBtn.setOpaque(false);
        signupBtn.setBorder(BorderFactory.createLineBorder(Color.WHITE, 3)); //white outline border
        signupBtn.setFocusPainted(false); //removes the dotted focus ring
        signupBtn.addActionListener(e -> cardLayout.show(mainContainer, "SIGNUP PAGE")); //switch to signup card

        //add both buttons to the stacked container
        buttonContainer.add(loginBtn);
        buttonContainer.add(signupBtn);

        //place the button container in the right half of the panel with top and left insets
        gbc.gridx = 1; gbc.weightx = 0.5;
        gbc.insets  = new Insets(300, 200, 0, 0); //push buttons 300px from top, 200px from left
        gbc.anchor  = GridBagConstraints.CENTER;
        gbc.fill    = GridBagConstraints.NONE; //do not stretch the button container
        panel.add(buttonContainer, gbc);

        return panel;
    }


    //FRAME 2: Login or SignUp - split panel with branding on the left and form fields on the right
    //isLogin=true builds the login form, isLogin=false builds the signup/registration form

    private JPanel createAuthView(boolean isLogin) {
        //split panel divides the screen into two equal halves side by side
        JPanel splitPanel = new JPanel(new GridLayout(1, 2));

        //LEFT PANEL - white background with back button, large title, and terms/robot checkbox
        JPanel left = new JPanel(new GridBagLayout());
        left.setBackground(Color.WHITE);
        GridBagConstraints lGbc = new GridBagConstraints();
        lGbc.gridx   = 0;
        lGbc.weightx = 1.0;
        lGbc.fill    = GridBagConstraints.NONE;
        int allowance = 50; //left padding in pixels applied to all elements in the left panel

        //BACK TO LANDING PAGE BUTTON - styled as a text link, returns to the welcome screen
        JButton backBtn = new JButton("← Back");
        backBtn.setFont(new Font("SansSerif", Font.BOLD, 16));
        backBtn.setForeground(DASH_RED); //red text to match brand color
        backBtn.setContentAreaFilled(false); //no button fill so it looks like a plain text link
        backBtn.setBorderPainted(false); //no border for a clean link appearance
        backBtn.setFocusPainted(false); //no dotted focus outline
        backBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); //hand cursor on hover
        backBtn.addActionListener(e -> cardLayout.show(mainContainer, "LANDING PAGE")); //return to landing screen

        //position the back button at the top-left corner of the left panel
        lGbc.gridy  = 0; lGbc.weighty = 0.0;
        lGbc.anchor = GridBagConstraints.NORTHWEST;
        lGbc.insets = new Insets(20, allowance, 0, 0);
        left.add(backBtn, lGbc);

        //TITLE - large bold heading that reads "Log-in" for login page or "Sign-Up" for registration
        JLabel title = new JLabel(isLogin ? "Log-in" : "Sign-Up");
        title.setFont(new Font("SansSerif", Font.BOLD, 80)); //very large font for visual impact
        lGbc.gridy  = 1; lGbc.weighty = 0.1;
        lGbc.anchor = GridBagConstraints.WEST;
        lGbc.insets = new Insets(10, allowance, 0, 0);
        left.add(title, lGbc);

        //CHECKBOX FOR VERIFICATION - changes label depending on whether login or signup view
        JPanel verificationPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        verificationPanel.setBackground(Color.WHITE);
        Font verificationFont = new Font("SansSerif", Font.PLAIN, 20);

        //checkbox label is "I am not a robot" for login, or "I agree to the" for signup
        JCheckBox authCheck = new JCheckBox(isLogin ? "I am not a robot" : "I agree to the ");
        authCheck.setBackground(Color.WHITE);
        authCheck.setFont(verificationFont);
        verificationPanel.add(authCheck);

        //only show the Terms and Conditions clickable link on the signup page
        if (!isLogin) {
            //underlined red label that opens the terms popup when clicked
            JLabel termsLink = new JLabel("<html><u>Terms and Conditions</u></html>");
            termsLink.setForeground(DASH_RED); //red color to indicate it is a clickable link
            termsLink.setFont(verificationFont);
            termsLink.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); //hand cursor on hover
            termsLink.addMouseListener(new MouseAdapter() {
                @Override public void mouseClicked(MouseEvent e) { showTermsPopup(); } //open terms popup dialog
            });
            verificationPanel.add(termsLink);
        }

        //position the verification panel at the bottom-left of the left panel
        lGbc.gridy  = 2; lGbc.weighty = 1.0;
        lGbc.anchor = GridBagConstraints.SOUTHWEST;
        lGbc.insets = new Insets(0, allowance, 40, 0);
        left.add(verificationPanel, lGbc);

        //RIGHT PANEL - red background containing all input fields and the submit action button
        JPanel right = new JPanel(new GridBagLayout());
        right.setBackground(DASH_RED); //brand red background for the form side
        GridBagConstraints rGbc = new GridBagConstraints();
        rGbc.fill  = GridBagConstraints.HORIZONTAL; //stretch all fields to fill available width
        rGbc.gridx = 0;

        //HEADER - "Enter your Details:" label at the top of the form
        JLabel detailsHeader = new JLabel("Enter your Details:");
        detailsHeader.setForeground(Color.WHITE); //white text on red background
        detailsHeader.setFont(new Font("SansSerif", Font.BOLD, 24));
        rGbc.gridy  = 0;
        rGbc.insets = new Insets(20, 50, 20, 50); //padding around the header label
        right.add(detailsHeader, rGbc);

        //shared field dimensions and font applied to all text input fields in the form
        Dimension fieldSize = new Dimension(400, 50);
        Font      fieldFont = new Font("SansSerif", Font.PLAIN, 18);

        //USERNAME FIELD - text field with placeholder hint for entering the account username
        JTextField userF = new JTextField("Username");
        styleField(userF, fieldSize, fieldFont); //apply shared size, font, and inner padding
        rGbc.gridy = 1; rGbc.insets = new Insets(10, 50, 10, 50);
        right.add(userF, rGbc);

        //PASSWORD LABEL - small descriptive label shown directly above the password input field
        JLabel passLabel = new JLabel("<html><font color='white'>Password:</font></html>");
        passLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        rGbc.gridy = 2; right.add(passLabel, rGbc);

        //PASSWORD FIELD - masked input that hides characters as the user types
        JPasswordField passF = new JPasswordField();
        styleField(passF, fieldSize, fieldFont); //apply shared field styling
        rGbc.gridy = 3; right.add(passF, rGbc);

        //SUBMIT BUTTON DIMENSIONS AND FONT - shared by both login and signup buttons
        Dimension authBtnSize = new Dimension(180, 50);
        Font      authBtnFont = new Font("SansSerif", Font.BOLD, 18);

        if (!isLogin) {
            //SIGNUP EXTRA FIELDS - additional personal information required for account creation
            JTextField emailF   = new JTextField("Email");
            JTextField nameF    = new JTextField("Legal Name");
            JTextField licenseF = new JTextField("Driver's License");
            JTextField phoneF   = new JTextField("Phone Number");

            //loop through the extra fields and add each one to consecutive grid rows
            JTextField[] fields = {emailF, nameF, licenseF, phoneF};
            int gridStart = 4; //begin placing extra fields from row 4 downward
            for (JTextField f : fields) {
                styleField(f, fieldSize, fieldFont); //apply shared field style to each field
                rGbc.gridy = gridStart++;
                right.add(f, rGbc);
            }

            //SIGNUP BUTTON - validates checkbox is checked then triggers the registration logic
            JButton regBtn = new JButton("SIGNUP NOW");
            regBtn.setPreferredSize(authBtnSize);
            regBtn.setFont(authBtnFont);
            rGbc.gridy = gridStart; rGbc.fill = GridBagConstraints.NONE; rGbc.anchor = GridBagConstraints.EAST;
            right.add(regBtn, rGbc);
            regBtn.addActionListener(e -> {
                //block registration if terms checkbox is not ticked
                if (!authCheck.isSelected()) JOptionPane.showMessageDialog(this, "Agree to the Terms & Conditions first!");
                else handleSignup(userF.getText(), new String(passF.getPassword()),
                        emailF.getText(), nameF.getText(), licenseF.getText(), phoneF.getText()); //pass all field values to signup handler
            });

        } else {
            //LOGIN BUTTON - validates robot checkbox then calls the login authentication logic
            JButton logBtn = new JButton("Log-In");
            logBtn.setPreferredSize(authBtnSize);
            logBtn.setFont(authBtnFont);
            rGbc.gridy = 4; rGbc.fill = GridBagConstraints.NONE; rGbc.anchor = GridBagConstraints.EAST;
            right.add(logBtn, rGbc);
            logBtn.addActionListener(e -> {
                //block login if the "I am not a robot" checkbox is not ticked
                if (!authCheck.isSelected()) JOptionPane.showMessageDialog(this, "Check 'I am not a robot'");
                else handleLogin(userF.getText(), new String(passF.getPassword())); //attempt database login
            });
        }

        //assemble the full split view by combining the white left and red right panels
        splitPanel.add(left);
        splitPanel.add(right);
        return splitPanel;
    }

    //STYLE FIELD HELPER - applies consistent size, font, and inner padding to any text field
    private void styleField(JTextField field, Dimension size, Font font) {
        field.setPreferredSize(size); //set preferred width and height of the input field
        field.setFont(font); //apply shared font style
        //compound border: keeps the default border and adds 5px vertical, 10px horizontal inner padding
        field.setBorder(BorderFactory.createCompoundBorder(
                field.getBorder(), BorderFactory.createEmptyBorder(5, 10, 5, 10)));
    }

    //TERMS AND CONDITIONS POP-UP - shows a scrollable read-only dialog with the rental agreement
    private void showTermsPopup() {
        //multi-line terms text displayed in a non-editable scrollable area
        String termsText = "DRIVEDASH TERMS AND CONDITIONS\n\n"
                + "1. Booking and Payment\n- Valid license and ID required.\n\n"
                + "2. Usage\n- No illegal activities or racing.\n\n"
                + "3. Liability\n- Renter is responsible for damage.\n\n"
                + "4. Fees\n- Renter pays all traffic fines.\n\n"
                + "5. Fuel\n- Return with same fuel level.";
        JTextArea ta = new JTextArea(termsText);
        ta.setEditable(false); //user can read but not modify the terms text
        ta.setLineWrap(true); //wrap long lines so they stay within the visible area
        JScrollPane sp = new JScrollPane(ta);
        sp.setPreferredSize(new Dimension(400, 300)); //set popup content dimensions
        JOptionPane.showMessageDialog(this, sp, "Terms & Conditions", JOptionPane.INFORMATION_MESSAGE);
    }

    //DATABASE CONNECTION (ECLIPSE to MySQL) - creates and returns a JDBC connection to the car_rental database
    private Connection connect() throws SQLException {
        //JDBC URL format: jdbc:mysql://host:port/database, followed by the MySQL username and password
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/car_rental2", "root", "myPASSsql@54321");
    }

    //LOGIN VALIDATIONS - queries the users table to verify the entered credentials
    private void handleLogin(String u, String p) {
        try (Connection conn = connect()) {
            //parameterized query uses ? placeholders to safely bind user input and prevent SQL injection
            String sql = "SELECT role FROM users WHERE USERNAME=? AND password=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, u); //bind the entered username
            pstmt.setString(2, p); //bind the entered password
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                //credentials matched - read the user's role to pass to the dashboard
                String role = rs.getString("role"); //retrieve "ADMIN" or "USER" from the database
                new UserDashboard(u, role); //open the main dashboard and pass username and role
                dispose(); //close the LandingPage window after navigating to the dashboard
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Credentials"); //credentials did not match
            }
        } catch (SQLException ex) { ex.printStackTrace(); } //log any database errors to the console
    }

    //REGISTERING THE ROLE (ADMIN OR USER)? - inserts a new account into the users table
    private void handleSignup(String u, String p, String email, String name, String lic, String ph) {
        //prompt the user to choose between registering as a regular user or an admin
        int res = JOptionPane.showConfirmDialog(this, "Register as Admin?", "Role", JOptionPane.YES_NO_OPTION);
        String role = "USER", empId = null; //default to USER role with no employee ID
        if (res == JOptionPane.YES_OPTION) {
            //require a secret admin code to authorize admin account creation
            String code = JOptionPane.showInputDialog("Admin Code:");
            if (ADMIN_CODE.equals(code)) {
                role  = "ADMIN"; //promote to ADMIN role if correct code is provided
                empId = JOptionPane.showInputDialog("Employee ID:"); //collect employee ID for admins
            }
        }
        try (Connection conn = connect()) {
            //insert the full set of new user details into the users table
            String sql = "INSERT INTO users (USERNAME,EMAIL,password,legal_name,drivers_license,phone_number,role,EMPLOYEE_ID) VALUES (?,?,?,?,?,?,?,?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, u);     //account username
            pstmt.setString(2, email); //email address
            pstmt.setString(3, p);     //account password
            pstmt.setString(4, name);  //full legal name
            pstmt.setString(5, lic);   //driver's license number
            pstmt.setString(6, ph);    //contact phone number
            pstmt.setString(7, role);  //assigned role (USER or ADMIN)
            pstmt.setString(8, empId); //employee ID (null for regular users)
            pstmt.executeUpdate(); //run the insert statement against the database
            JOptionPane.showMessageDialog(this, "Success!"); //notify user that signup was successful
            cardLayout.show(mainContainer, "LOGIN PAGE"); //redirect to login page after registration
        } catch (SQLException ex) { ex.printStackTrace(); } //log any database errors to the console
    }

    //BACKGROUND IMAGE DIMENSIONS FOR LANDING PAGE AND PAINT COMPONENT FOR THE DIFFERENT CARDLAYOUT
    //ImagePanel - custom JPanel subclass that stretches a loaded image to fill the entire panel
    class ImagePanel extends JPanel {
        private BufferedImage img; //stores the decoded image read from the resource path

        //constructor loads and decodes the image resource at the given classpath location
        public ImagePanel(String path) {
            try {
                InputStream is = getClass().getResourceAsStream(path); //locate image in classpath
                if (is != null) img = ImageIO.read(is); //decode the stream into a BufferedImage
            } catch (Exception e) { e.printStackTrace(); } //print any IO or decoding errors
        }

        //paintComponent is called by Swing whenever the panel needs to be redrawn
        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g); //call parent to paint the default background first
            if (img != null) g.drawImage(img, 0, 0, getWidth(), getHeight(), this); //stretch image to fill panel
        }
    }

    //MAIN METHOD - launches the LandingPage window on the Swing Event Dispatch Thread
    public static void main(String[] args) { SwingUtilities.invokeLater(LandingPage::new); }
}